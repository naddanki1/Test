
function changeStore(value) {
	storeStatus = value;
	$.ajax({
		headers : {
			'Accept' : 'application/json',
			'Content-Type' : 'application/json'
		},
		type : "get",
		url : ctx + "/seller/store?status=" + value,
		success : function(result) {
			if (result.status == "SUCCESS") {
					
			} else {
				alert("Failed to update ")
			}
		},

	});

};
function changeStatus(value) { 
	$('#hidStoreStatus').val(value);
	$('#confirmationPopup').modal('show');
}
