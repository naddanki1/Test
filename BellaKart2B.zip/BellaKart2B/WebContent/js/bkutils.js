! function(e) {
    e.fn.serializeObject = function() {
        var r = this,
            t = {},
            a = {},
            n = {
                validate: /^[a-zA-Z][a-zA-Z0-9_]*(?:\[(?:\d*|[a-zA-Z0-9_]+)\])*$/,
                key: /[a-zA-Z0-9_]+|(?=\[\])/g,
                push: /^$/,
                fixed: /^\d+$/,
                named: /^[a-zA-Z0-9_]+$/
            };
        return this.build = function(e, r, t) {
            return e[r] = t, e
        }, this.push_counter = function(e) {
            return void 0 === a[e] && (a[e] = 0), a[e]++
        }, e.each(e(this).serializeArray(), function() {
            if (n.validate.test(this.name)) {
                for (var a, o = this.name.match(n.key), i = this.value, s = this.name; void 0 !== (a = o.pop());) s = s.replace(new RegExp("\\[" + a + "\\]$"), ""), a.match(n.push) ? i = r.build([], r.push_counter(s), i) : a.match(n.fixed) ? i = r.build([], a, i) : a.match(n.named) && (i = r.build({}, a, i));
                t = e.extend(!0, t, i)
            }
        }), t
    }
    
}(jQuery);

function showPopUp(e,r)
	{
		$("#errorHeader").html("");
		$("#errorHeader").append(e+" ! ");
		$("#errorMessage").html("");
		$("#errorMessage").append(r);
		$("#errorPopup").modal("show");
	}
function showProgressBar(text)
{
	$("#progressBarText").empty();
	$("#progressBarText").text(text);
	$("#progressBarModal").modal("show");
}

function hideProgressBar()
{
	$("#progressBarText").empty();
	$("#progressBarModal").modal("hide");
}
