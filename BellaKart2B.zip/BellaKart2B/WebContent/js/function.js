// JavaScript Document

$('.toggle-slide').toggles({
		clicker:$('.clickme')
	});


	$('.dropdown').on('show.bs.dropdown', function(e){
    $(this).find('.dropdown-menu').first().stop(true, true).slideDown();
});

 // ADD SLIDEUP ANIMATION TO DROPDOWN //
$('.dropdown').on('hide.bs.dropdown', function(e){
    $(this).find('.dropdown-menu').first().stop(true, true).slideUp();
});
  
function toggleChevron(e) {
    $(e.target)
        .prev('.panel-heading')
        .find("i.indicator")
        .toggleClass('glyphicon-menu-up glyphicon-menu-down');
}
$('#accordion').on('hidden.bs.collapse', toggleChevron);
$('#accordion').on('shown.bs.collapse', toggleChevron);

$(document).ready(function(e) {
	
	$(".itemName").click(function(e) {

        $(this).closest(".itemBox").find(".prodDetail").stop().slideToggle("300");
    });
	
  if($("body").height() < $(window).height()){
		$("footer").css("position","absolute");	
	}
	else{
		$("footer").css("position","static");
	}
	
	$(function () {
	  $('[data-toggle="tooltip"]').tooltip()
	});
	

	
	
	
	
	
	
	
});


$(window).resize(function(e) {
    if($("body").height() < $(window).height()){
		$("footer").css("position","absolute");	
	}
	else{
		$("footer").css("position","static");
	}
});