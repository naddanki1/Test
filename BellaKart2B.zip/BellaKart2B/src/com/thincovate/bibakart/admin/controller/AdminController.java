package com.thincovate.bibakart.admin.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.thincovate.bibakart.admin.model.Brand;
import com.thincovate.bibakart.admin.model.BrandsModel;
import com.thincovate.bibakart.admin.model.Category;
import com.thincovate.bibakart.admin.model.LgFee;
import com.thincovate.bibakart.admin.model.StatusModel;
import com.thincovate.bibakart.admin.services.BrandsService;
import com.thincovate.bibakart.admin.services.CategoriesService;
import com.thincovate.bibakart.catalog.services.LogisticFeeService;
import com.thincovate.bibakart.catalog.services.MarketingChargesService;
import com.thincovate.bibakart.catalog.services.ProductsViewService;
import com.thincovate.bibakart.catalog.services.SellerProductsService;
import com.thincovate.bibakart.common.model.BrandResponseWrapper;
import com.thincovate.bibakart.common.model.ResponseWrapper;
import com.thincovate.bibakart.common.utils.BibakartConstants;
import com.thincovate.bibakart.common.utils.Responses;
import com.thincovate.bibakart.images.service.ImagesService;
import com.thincovate.bibakart.sessionmgnt.model.Seller;

@RestController
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private SellerProductsService sellerProductsService;
	
	@Autowired
	private CategoriesService categoriesService;
	
	@Autowired
	private BrandsService brandsService;
	
	@Autowired
	private LogisticFeeService logisticFeeService;
	
	@Autowired
	private MarketingChargesService marketingChargesService;
	
	@Autowired
	private ImagesService imagesService;
	
	@Autowired
	private ProductsViewService productsViewService;

	static Logger log = Logger.getLogger(AdminController.class);

	/**
	 * updates Approval Status
	 * Admin is the actor
	 * @param sellerProductId
	 * @param approvalStatus
	 * @return
	 */
	@RequestMapping(value = "/sellerProducts", method = RequestMethod.PUT)
	public ResponseWrapper updateSellerProductApprovalStatus(@RequestBody StatusModel status) {
		try {
			ResponseWrapper returnModel = null;
			returnModel = sellerProductsService.updateSellerProductApprovalStatus(status);
			return returnModel;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}

	/**
	 * returns SellerProducts using Approval Status
	 * 
	 * @param status
	 * @return
	 */
	@RequestMapping(value = "/sellerProducts", method = RequestMethod.GET)
	public ResponseWrapper getSellerProdcutsUsingApprovalStatus(@RequestParam(value = "status") String status) {

		try {
			String column = BibakartConstants.APPROVAL_STATUS2;
			return sellerProductsService.getSellerProductsUsingStatus(column, status);
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}
	
	@RequestMapping(value="/products/search", method=RequestMethod.GET)
	public ResponseWrapper searchProducts(@RequestParam(value = "keyword") String keyword){
		
		return productsViewService.searchSellerProducts(keyword);
	}

	/**
	 * Adds a new Category
	 * Admin and Product Manager are the actors
	 * @param category
	 * @param bindingResult
	 * @return
	 */
	@RequestMapping(value = "/categories", method = RequestMethod.POST)
	public ResponseWrapper addCategory(@RequestBody @Valid Category category, BindingResult bindingResult) {
		log.info(category.toString());
		try {
			List<String> errors = new ArrayList<String>();
			if (bindingResult.hasFieldErrors()) {
				log.debug("invalid Data");
				for (FieldError e : bindingResult.getFieldErrors()) {
					log.info(Responses.FIELD_NAME + e.getField() + Responses.FIELD_ERROR + e.getDefaultMessage());
					errors.add(Responses.FIELD_NAME + e.getField() + Responses.FIELD_ERROR + e.getDefaultMessage());
					return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG,
							errors);
				}
			}
			return categoriesService.addCategory(category);
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}

	/**
	 * returns all the active Catagories
	 * 
	 * @return
	 */
	@RequestMapping(value = "/categories/topLevel", method = RequestMethod.GET)
	public ResponseWrapper getAllCategories() {

		try {
			return categoriesService.getAllCategories();
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}

	/**
	 * get all sub Categories of a Category
	 * 
	 * @param categoryId
	 * @return
	 */
	@RequestMapping(value = "/subCategories", method = RequestMethod.GET)
	public ResponseWrapper getAllSubCategories(@RequestParam(value = "categoryId") String categoryId) {

		try {
			return categoriesService.getAllSubCategories(categoryId);
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}

	/**
	 * return all the active Catagories in Tree Structure
	 * 
	 * @return
	 */
	@RequestMapping(value = "/categories", method = RequestMethod.GET)
	public ResponseWrapper getAllCategoriesInTreeStructure() {

		try {
			return categoriesService.getAllCategoriesInTreeStructure();
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}

	/**
	 * adds a new Brand
	 * 
	 * @param brand
	 * @param bindingResult
	 * @return
	 */
	@RequestMapping(value = "/brands", method = RequestMethod.POST)
	public ResponseWrapper addBrand(@RequestBody @Valid Brand brand, BindingResult bindingResult) {
		List<String> errors = new ArrayList<String>();
		try {
			if (bindingResult.hasFieldErrors()) {
				log.debug("invalid Data");
				for (FieldError e : bindingResult.getFieldErrors()) {
					log.info(Responses.FIELD_NAME + e.getField() + Responses.FIELD_ERROR + e.getDefaultMessage());
					errors.add(Responses.FIELD_NAME + e.getField() + Responses.FIELD_ERROR + e.getDefaultMessage());
				}
				return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG,
						errors);
			}
			return brandsService.addNewBrand(brand);
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}

	/**
	 * return All the Brands
	 * 
	 * @return
	 */
	@RequestMapping(value = "/brands", method = RequestMethod.GET)
	public ResponseWrapper getAllBrands() {

		try {
			return brandsService.getAllBrands();
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}
	
	/**
	 * return All the Brands
	 * 
	 * @return
	 */
	@RequestMapping(value = "/brandList", method = RequestMethod.GET)
	public List<BrandsModel> getAllBrandList() {

		try {
			return ((BrandResponseWrapper)brandsService.getAllBrands()).getBrands();
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * adds a new LogisticFee Entry
	 * 
	 * @param logisticFees
	 * @param bindingResult
	 * @return
	 */
	@RequestMapping(value = "/logisticFees", method = RequestMethod.POST)
	public ResponseWrapper addLogisticFee(@RequestBody @Valid LgFee lgFee, BindingResult bindingResult) {
		List<String> errors = new ArrayList<String>();
		try {
			if (bindingResult.hasFieldErrors()) {
				log.debug("invalid Data");
				for (FieldError e : bindingResult.getFieldErrors()) {
					log.info(Responses.FIELD_NAME + e.getField() + Responses.FIELD_ERROR + e.getDefaultMessage());
					errors.add(Responses.FIELD_NAME + e.getField() + Responses.FIELD_ERROR + e.getDefaultMessage());
				}
				return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG,	errors);
			}
			return logisticFeeService.addLogisticFee(lgFee);
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}

	/**
	 * Updates MarketingCharges Details
	 * 
	 * @param mkChargesId
	 * @param mkPercentage
	 * @param taxOnMf
	 * @return
	 */
	@RequestMapping(value = "/mktCharges", method = RequestMethod.PUT)
	public ResponseWrapper updateMarketingCharges(@RequestParam(value = "mkChargesId") String mkChargesId,
			@RequestParam(value = "mkPercentage") String mkPercentage,
			@RequestParam(value = "taxOnMf") String taxOnMf) {

		try {
			return marketingChargesService.updateMarketingCharges(mkChargesId, mkPercentage, taxOnMf);
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}

	}

	@RequestMapping(value = "docs/images", method = RequestMethod.POST)
	public ResponseWrapper saveDocument(@RequestParam(required = false) String sellerId,MultipartHttpServletRequest request) {
		HttpSession session = request.getSession();
		Seller seller = (Seller) session.getAttribute("seller");
		if (sellerId == null)
			sellerId = seller.getSellerId();
		Iterator<String> it = request.getFileNames();
		String fileName = it.next();
		String docName = BibakartConstants.DOC_NAME.get(fileName) == null ? ""	: BibakartConstants.DOC_NAME.get(fileName);
		return imagesService.saveDocImage(sellerId, docName, request.getFile(fileName));
	}

	@RequestMapping(value = "docs/image", method = RequestMethod.POST)
	public String saveDocuments(MultipartHttpServletRequest request) {

		HttpSession session = request.getSession();
		Seller seller = (Seller) session.getAttribute("seller");
		String sellerId = seller.getSellerId();
		Iterator<String> it = request.getFileNames();

		while (it.hasNext()) {
			String docName = BibakartConstants.DOC_NAME.get(it.next());
			log.info(docName);
			if (docName != null) {
				imagesService.saveDocImage(sellerId, docName, request.getFile(docName));
			}
		}
		return null;
	}

	@RequestMapping(value = "/docs/images", method = RequestMethod.GET, produces = { "image/jpg" })
	public byte[] findDocument(@RequestParam(required = false) String sellerId,	@RequestParam(value = "docName") String docName, HttpSession session,HttpServletRequest request) {
		Seller seller = (Seller) session.getAttribute("seller");
		if (sellerId == null)
			sellerId = seller.getSellerId();
		docName = BibakartConstants.DOC_NAME.get(docName) == null ? "" : BibakartConstants.DOC_NAME.get(docName);
		return imagesService.findDocImage(sellerId, docName);
	}

	@RequestMapping(value = "/images", method = RequestMethod.POST)
	public ResponseWrapper saveImage(MultipartHttpServletRequest request) {
		Iterator<String> itr = request.getFileNames();
		MultipartFile mpf = request.getFile(itr.next());
		log.info(request.getParameter("id") + "-" + request.getParameter("name"));
		try {
			if (imagesService.saveSkuImage(request.getParameter("sellerId"), request.getParameter("id"), mpf.getInputStream(),1))
				return new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS, Responses.SUCCESS_MSG);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, "fail");
	}

	@RequestMapping(value = "/images/{id}", method = RequestMethod.GET, produces = { "image/jpg" })
	public byte[] findmage(@PathVariable("id") String sellerId, @RequestParam(value = "skuId") String skuId,@RequestParam(value = "size", required = false, defaultValue = "100x122") String size,HttpServletRequest request) {

		return imagesService.findSkuImage(sellerId, skuId, size);

	}

}
