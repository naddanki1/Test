package com.thincovate.bibakart.admin.controller;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Iterator;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.thincovate.bibakart.admin.services.DownloadService;
import com.thincovate.bibakart.common.PropertyReader;
import com.thincovate.bibakart.common.model.ResponseWrapper;
import com.thincovate.bibakart.common.utils.BibakartConstants;
import com.thincovate.bibakart.common.utils.Responses;
import com.thincovate.bibakart.entitymodels.OrdersMaster;
import com.thincovate.bibakart.orders.dao.OrdersMasterDAO;
import com.thincovate.bibakart.sessionmgnt.model.Seller;

@Controller
public class DownloadController {

	@Autowired
	private DownloadService downloadService;
	
	@Autowired
	private OrdersMasterDAO ordersMasterDAO;
	
	static Logger log = Logger.getLogger(DownloadController.class);

	/**
	 * @param name
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping(value = "/sellers/help/documents", method = RequestMethod.GET)
	public void downloadPDF(@RequestParam(value = "name") String name, HttpServletResponse response) throws IOException {
		try {
			response.setContentType("application/pdf");
			response.setHeader("Content-disposition", "attachment; filename=" + name + ".pdf");
			String path = null;
			//String rootFolder = environment.getProperty("loc.files.pdfLocation");			
			String rootFolder = PropertyReader.getInstance().getProperty("loc.files.pdfLocation");
			if (name.equalsIgnoreCase("order_process"))
				path = rootFolder + "/" + "order_process.pdf";
			else if (name.equalsIgnoreCase("order_guide"))
				path = rootFolder + "/" + "order_guide.pdf";
			else if (name.equalsIgnoreCase("catalog_upload"))
				path = rootFolder + "/" + "catalog_upload.pdf";
			else if (name.equalsIgnoreCase("catalog_bulkupload"))
				path = rootFolder + "/" + "catalog_bulkupload.pdf";
			else if (name.equalsIgnoreCase("catalog_search"))
				path = rootFolder + "/" + "catalog_search.pdf";
			else if (name.equalsIgnoreCase("payment"))
				path = rootFolder + "/" + "payment.pdf";
			else if (name.equalsIgnoreCase("returns_guide"))
				path = rootFolder + "/" + "returns_guide.pdf";
			else if (name.equalsIgnoreCase("tc"))
				path = rootFolder + "/" + "tc.pdf";
			else if (name.equalsIgnoreCase("misc_information"))
				path = rootFolder + "/" + "misc_information.pdf";			
			else if (name.equalsIgnoreCase("return_policy"))
				path = rootFolder+"/"+"return_policy.pdf";
			
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			baos = downloadService.convertPDFToByteArrayOutputStream(path);
			OutputStream os = response.getOutputStream();
			baos.writeTo(os);
			os.flush();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}
	@RequestMapping(value = "sellers/orders/documents", method = RequestMethod.POST)
	public @ResponseBody ResponseWrapper uploadDoc(MultipartHttpServletRequest request) {
		try{
			HttpSession session = request.getSession();
			Long orderId = Long.parseLong(request.getParameter("orderId"));
			Seller seller = (Seller) session.getAttribute("seller");
			String sellerId = request.getParameter("sellerId");
			if (sellerId == null)
				sellerId = seller.getSellerId();
			Iterator<String> it = request.getFileNames();
			int i= 0;
			while(it.hasNext()){
					String name = it.next();
					log.info("Uploading "+name+" for order "+orderId+"of Seller "+sellerId);
				if(downloadService.uploadDoc(sellerId, name,orderId, request.getFile(name),request))
						i++;
			}
			if(i==2){
			return new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS, Responses.SUCCESS_MSG);
			}
		}catch(Exception e){
			// TODO 
			e.printStackTrace();
		}
		 return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.FAILURE_MSG);
	}
	@RequestMapping(value = "sellers/orders/documents/{name}", method = RequestMethod.POST)
	public @ResponseBody ResponseWrapper uploadDocument(@PathVariable("name") String name,MultipartHttpServletRequest request) {
		try{
			HttpSession session = request.getSession();
			Long orderId = Long.parseLong(request.getParameter("orderId"));
			Seller seller = (Seller) session.getAttribute("seller");
			String sellerId = request.getParameter("sellerId");
			if (sellerId == null)
				sellerId = seller.getSellerId();
			Iterator<String> itr = request.getFileNames();
			MultipartFile mpf = request.getFile(itr.next());
				log.info("Uploading "+name+" for order "+orderId+" of Seller "+sellerId);
				if(downloadService.uploadDocument(sellerId, "manifest_updated",orderId, mpf,request)){
				return new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS, Responses.SUCCESS_MSG);
				}
		}catch(Exception e){
			// TODO 
			e.printStackTrace();
		}
		 return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.FAILURE_MSG);
	}

	@RequestMapping(value = "/sellers/{sellerId}/orders/{orderId}/documents", method = RequestMethod.GET)
	public void dowloadDoc(@PathVariable("sellerId") String sellerId,@PathVariable("orderId") String orderId,@RequestParam(value = "type") String type, HttpServletResponse response){
		try {
			response.setContentType("application/pdf");
			response.setHeader("Content-disposition", "attachment; filename=" + type + ".pdf");
			String path = null;		
			String rootFolder = PropertyReader.getInstance().getProperty("loc.images.rootLocation");
			String docLocation = rootFolder + File.separator +"Profiles"+ File.separator + sellerId + File.separator +"Orders"+ File.separator + orderId+File.separator ;
			OrdersMaster order= ordersMasterDAO.findOne(Long.parseLong(orderId));
			if (type.equalsIgnoreCase(BibakartConstants.DOC_SHIPPING_LABEL)){
				path = docLocation + BibakartConstants.DOC_SHIPPING_LABEL+".pdf";
				order.setShippingLableStatus(BibakartConstants.DOWNLOADED_BY_SELLER);
			}
			else if (type.equalsIgnoreCase(BibakartConstants.DOC_MANIFEST)){
				path = docLocation+ BibakartConstants.DOC_MANIFEST+".pdf";
				order.setManifestStatus(BibakartConstants.DOWNLOADED_BY_SELLER);
			}
			ordersMasterDAO.saveOrupdate(order);
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			baos = downloadService.convertPDFToByteArrayOutputStream(path);
			OutputStream os = response.getOutputStream();
			baos.writeTo(os);
			os.flush();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}
}