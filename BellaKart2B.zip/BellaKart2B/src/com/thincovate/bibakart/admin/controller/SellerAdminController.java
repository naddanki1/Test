package com.thincovate.bibakart.admin.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.thincovate.bibakart.admin.model.SellerDetails;
import com.thincovate.bibakart.admin.model.StatusModel;
import com.thincovate.bibakart.admin.services.SellerDetailsService;
import com.thincovate.bibakart.common.model.ResponseWrapper;
import com.thincovate.bibakart.common.utils.Responses;
import com.thincovate.bibakart.sessionmgnt.model.Seller;

@RestController
@RequestMapping("/")
public class SellerAdminController {

	@Autowired
	private SellerDetailsService sellerDetailsService;

	/**
	 * returns all Sellers Information
	 * 
	 * @return
	 */
	@RequestMapping(value = "/sellers", method = RequestMethod.GET)
	public ResponseWrapper getAllSellers() {

		try {
			return sellerDetailsService.getAllSellers();
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}

	/**
	 * returns Seller Info using Id
	 * 
	 * @param sellerId
	 * @return
	 */
	@RequestMapping(value = "/seller/{id}", method = RequestMethod.GET)
	public List<SellerDetails> getSellerDetails(@PathVariable("id") String sellerId) {

		try {
			return sellerDetailsService.getSellerUsingId(sellerId);
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * updates seller deails
	 * 
	 * @param sellerDetails 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/seller", method = RequestMethod.PUT)
	public ResponseWrapper updateSellerDetails(@RequestBody SellerDetails sellerDetails,HttpServletRequest request) {

		try {
			HttpSession session = request.getSession();
			Seller seller = (Seller) session.getAttribute("seller");
			if(seller != null){
				String sellerID = seller.getSellerId();
				sellerDetails.setSellerId(Long.parseLong(sellerID));
				System.out.println(sellerDetails.toString());
				return sellerDetailsService.updateSellerDetails(sellerDetails,request);
			}else{
				return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, "Invalid Request");
			}			
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}

	}
	/**
	 * changes seller store status
	 * 
	 * @param sellerId
	 * @param status
	 * @return
	 */
	@RequestMapping(value = "/seller/store", method = RequestMethod.GET)
	public ResponseWrapper changeStoreStatus(@RequestParam(value="status") String status,@RequestParam(value="id",required=false) String sellerId,HttpServletRequest request) {

		try {
			if(sellerId ==null){
			HttpSession session = request.getSession();
			Seller seller =(Seller)session.getAttribute("seller");
			sellerId= seller.getSellerId();
		/*	seller.setStoreStatus(status);
			session.setAttribute("seller", seller);*/	
			}
			return sellerDetailsService.changeStoreStatus(sellerId, status,request);
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}	

	/**
	 * verifies seller Documents
	 * 
	 * @param sellerId
	 * @param docName
	 * @param status
	 * @return
	 */
	@RequestMapping(value = "/seller/{id}/docs/verify", method = RequestMethod.POST)
	public ResponseWrapper verifySellerDocs(@PathVariable(value = "id") String sellerId,@RequestParam(value = "docName") String docName, @RequestParam(value = "status") Long status) {

		try {
			return sellerDetailsService.verifySellerDocs(sellerId, docName, status);
			
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}

	@RequestMapping(value = "/seller/verify", method = RequestMethod.PUT)
	public ResponseWrapper verify(@RequestBody StatusModel status) {

		if (sellerDetailsService.verifySeller(status.getSellerId(),status))
			return new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS, Responses.SUCCESS_MSG);
		else
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
	}
	
	@RequestMapping(value = "/sellers/search", method = RequestMethod.GET)
	public ResponseWrapper searchSellers(@RequestParam(value = "k") String keyword) {

		try {
			return  sellerDetailsService.searchSellers(keyword);
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}
}
