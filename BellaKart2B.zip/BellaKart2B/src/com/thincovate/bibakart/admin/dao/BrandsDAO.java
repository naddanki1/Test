package com.thincovate.bibakart.admin.dao;

import org.springframework.stereotype.Repository;

import com.thincovate.bibakart.dao.AbstractHibernateDAO;
import com.thincovate.bibakart.entitymodels.Brands;

@Repository
public class BrandsDAO extends AbstractHibernateDAO<Brands> {

	public BrandsDAO() {
		setClazz(Brands.class);
	}
}
