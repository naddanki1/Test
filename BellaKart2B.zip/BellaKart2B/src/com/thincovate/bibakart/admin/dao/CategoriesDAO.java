package com.thincovate.bibakart.admin.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.thincovate.bibakart.dao.AbstractHibernateDAO;
import com.thincovate.bibakart.entitymodels.Categories;

@Repository
public class CategoriesDAO extends AbstractHibernateDAO<Categories> {

	public CategoriesDAO() {
		setClazz(Categories.class);
	}

	public List<Categories> getList() {
		return findAll();
	}

	public List<Categories> getTopCategoryList() {

		return findAllByColumn("parentCategoryId", Long.parseLong("1"));
	}

	public List<Categories> getActiveList() {

		return findAllByColumn("status", new Integer(1));

	}

}
