package com.thincovate.bibakart.admin.model;

import org.hibernate.validator.constraints.NotEmpty;

public class Brand {

	@NotEmpty(message="Brand Name can't be Empty")
	private String brandName;
	private String brandDesc;
	private String status;

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public String getBrandDesc() {
		return brandDesc;
	}

	public void setBrandDesc(String brandDesc) {
		this.brandDesc = brandDesc;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
