package com.thincovate.bibakart.admin.model;

import java.util.ArrayList;
import java.util.List;

public class CategoriesModel {

	private Long categoryId;
	private String categoryName;
	private String categoryDesc;
	private Boolean isMainCategory;
	private String status;
	private String mkPercentage;
	private String taxOnMf;
	List<CategoriesModel> subCategories=new ArrayList<CategoriesModel>();

	public List<CategoriesModel> getSubCategories() {
		return subCategories;
	}

	public void setSubCategories(List<CategoriesModel> subCategories) {
		this.subCategories = subCategories;
	}

	public String getMkPercentage() {
		return mkPercentage;
	}

	public void setMkPercentage(String mkPercentage) {
		this.mkPercentage = mkPercentage;
	}

	public String getTaxOnMf() {
		return taxOnMf;
	}

	public void setTaxOnMf(String taxOnMf) {
		this.taxOnMf = taxOnMf;
	}

	public Long getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Long categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public String getCategoryDesc() {
		return categoryDesc;
	}

	public void setCategoryDesc(String categoryDesc) {
		this.categoryDesc = categoryDesc;
	}

	
	public Boolean getIsMainCategory() {
		return isMainCategory;
	}

	public void setIsMainCategory(Boolean isMainCategory) {
		this.isMainCategory = isMainCategory;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
