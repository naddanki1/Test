package com.thincovate.bibakart.admin.model;

import org.hibernate.validator.constraints.NotEmpty;

public class Category {

	@NotEmpty(message="categoty Name can't be Empty")
	private String categoryName;
	private String categoryDesc;
	private String parentCategoryId;
	private String isMainCategory;
	private String status;
	private String mkPercentage;
	private String taxOnMf;

	public String getTaxOnMf() {
		return taxOnMf;
	}

	public void setTaxOnMf(String taxOnMf) {
		this.taxOnMf = taxOnMf;
	}

	public String getMkPercentage() {
		return mkPercentage;
	}

	public void setMkPercentage(String mkPercentage) {
		this.mkPercentage = mkPercentage;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public String getCategoryDesc() {
		return categoryDesc;
	}

	public void setCategoryDesc(String categoryDesc) {
		this.categoryDesc = categoryDesc;
	}

	public String getParentCategoryId() {
		return parentCategoryId;
	}

	public void setParentCategoryId(String parentCategoryId) {
		this.parentCategoryId = parentCategoryId;
	}

	public String getIsMainCategory() {
		return isMainCategory;
	}

	public void setIsMainCategory(String isMainCategory) {
		this.isMainCategory = isMainCategory;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Category [categoryName=" + categoryName + ", categoryDesc=" + categoryDesc + ", parentCategoryId="
				+ parentCategoryId + ", isMainCategory=" + isMainCategory + ", status=" + status + ", mkPercentage="
				+ mkPercentage + ", taxOnMf=" + taxOnMf + "]";
	}

}
