package com.thincovate.bibakart.admin.model;

import javax.validation.constraints.NotNull;

public class LgFee {

	@NotNull(message="Limit should be entered")
	private String lowerLimit;
	private String upperLimit;
	private String fee;
	private String taxOnLogisticFee;

	public String getLowerLimit() {
		return lowerLimit;
	}

	public void setLowerLimit(String lowerLimit) {
		this.lowerLimit = lowerLimit;
	}

	public String getUpperLimit() {
		return upperLimit;
	}

	public void setUpperLimit(String upperLimit) {
		this.upperLimit = upperLimit;
	}

	public String getFee() {
		return fee;
	}

	public void setFee(String fee) {
		this.fee = fee;
	}

	public String getTaxOnLogisticFee() {
		return taxOnLogisticFee;
	}

	public void setTaxOnLogisticFee(String taxOnLogisticFee) {
		this.taxOnLogisticFee = taxOnLogisticFee;
	}

}
