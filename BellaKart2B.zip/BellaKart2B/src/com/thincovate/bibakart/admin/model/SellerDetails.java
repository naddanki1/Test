package com.thincovate.bibakart.admin.model;

public class SellerDetails {

	private Long sellerId;
	private String sellerStatus;
	private String businessName;
	private String storeDisplayName;
	private String storeStatus;
	private String description;
	private String pickupAddr;
	private int pickupPin;
	private String primaryContactName;
	private String emailAddr;
	private Long mobile;

	// Bank Details
	private String bankNm;
	private String accName;
	private Long accNo;
	private String ifsc;
	private String city;
	private Long accVerified;
	private String cancelledChequeProof;

	// Seller Docs
	private String tinNo;
	private String tinProof;
	private Long tinVerified;
	private String panNo;
	private String panProof;
	private Long panVerified;
	private String tanNo;
	private String tanProof;
	private Long tanVerified;
	private String kycDocsAddrProof;
	private String addressProofVerified;
	private String kycDocsIdProof;
	private String idProofVerified;
	private String dateCreated;
	private Long contactDeatilsVerified;

	public Long getContactDeatilsVerified() {
		return contactDeatilsVerified;
	}

	public void setContactDeatilsVerified(Long contactDeatilsVerified) {
		this.contactDeatilsVerified = contactDeatilsVerified;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Long getSellerId() {
		return sellerId;
	}

	public void setSellerId(Long sellerId) {
		this.sellerId = sellerId;
	}

	public String getSellerStatus() {
		return sellerStatus;
	}

	public void setSellerStatus(String sellerStatus) {
		this.sellerStatus = sellerStatus;
	}

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public String getStoreDisplayName() {
		return storeDisplayName;
	}

	public void setStoreDisplayName(String storeDisplayName) {
		this.storeDisplayName = storeDisplayName;
	}

	public String getStoreStatus() {
		return storeStatus;
	}

	public void setStoreStatus(String storeStatus) {
		this.storeStatus = storeStatus;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPickupAddr() {
		return pickupAddr;
	}

	public void setPickupAddr(String pickupAddr) {
		this.pickupAddr = pickupAddr;
	}

	public int getPickupPin() {
		return pickupPin;
	}

	public void setPickupPin(int pickupPin) {
		this.pickupPin = pickupPin;
	}

	public String getPrimaryContactName() {
		return primaryContactName;
	}

	public void setPrimaryContactName(String primaryContactName) {
		this.primaryContactName = primaryContactName;
	}

	public String getEmailAddr() {
		return emailAddr;
	}

	public void setEmailAddr(String emailAddr) {
		this.emailAddr = emailAddr;
	}

	public Long getMobile() {
		return mobile;
	}

	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}

	public String getBankNm() {
		return bankNm;
	}

	public void setBankNm(String bankNm) {
		this.bankNm = bankNm;
	}

	public String getAccName() {
		return accName;
	}

	public void setAccName(String accName) {
		this.accName = accName;
	}

	public Long getAccNo() {
		return accNo;
	}

	public void setAccNo(Long accNo) {
		this.accNo = accNo;
	}

	public String getIfsc() {
		return ifsc;
	}

	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}

	public Long getAccVerified() {
		return accVerified;
	}

	public void setAccVerified(Long accVerified) {
		this.accVerified = accVerified;
	}

	public String getCancelledChequeProof() {
		return cancelledChequeProof;
	}

	public void setCancelledChequeProof(String cancelledChequeProof) {
		this.cancelledChequeProof = cancelledChequeProof;
	}

	public String getTinNo() {
		return tinNo;
	}

	public void setTinNo(String tinNo) {
		this.tinNo = tinNo;
	}

	public String getTinProof() {
		return tinProof;
	}

	public void setTinProof(String tinProof) {
		this.tinProof = tinProof;
	}

	public Long getTinVerified() {
		return tinVerified;
	}

	public void setTinVerified(Long tinVerified) {
		this.tinVerified = tinVerified;
	}

	public String getPanNo() {
		return panNo;
	}

	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}

	public String getPanProof() {
		return panProof;
	}

	public void setPanProof(String panProof) {
		this.panProof = panProof;
	}

	public Long getPanVerified() {
		return panVerified;
	}

	public void setPanVerified(Long panVerified) {
		this.panVerified = panVerified;
	}

	public String getTanNo() {
		return tanNo;
	}

	public void setTanNo(String tanNo) {
		this.tanNo = tanNo;
	}

	public String getTanProof() {
		return tanProof;
	}

	public void setTanProof(String tanProof) {
		this.tanProof = tanProof;
	}

	public Long getTanVerified() {
		return tanVerified;
	}

	public void setTanVerified(Long tanVerified) {
		this.tanVerified = tanVerified;
	}

	public String getKycDocsAddrProof() {
		return kycDocsAddrProof;
	}

	public void setKycDocsAddrProof(String kycDocsAddrProof) {
		this.kycDocsAddrProof = kycDocsAddrProof;
	}

	public String getAddressProofVerified() {
		return addressProofVerified;
	}

	public void setAddressProofVerified(String addressProofVerified) {
		this.addressProofVerified = addressProofVerified;
	}

	public String getKycDocsIdProof() {
		return kycDocsIdProof;
	}

	public void setKycDocsIdProof(String kycDocsIdProof) {
		this.kycDocsIdProof = kycDocsIdProof;
	}

	public String getIdProofVerified() {
		return idProofVerified;
	}

	public void setIdProofVerified(String idProofVerified) {
		this.idProofVerified = idProofVerified;
	}

	public String getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(String dateCreated) {
		this.dateCreated = dateCreated;
	}

	@Override
	public String toString() {
		return "SellerDetails [sellerId=" + sellerId + ", sellerStatus=" + sellerStatus + ", businessName="
				+ businessName + ", storeDisplayName=" + storeDisplayName + ", storeStatus=" + storeStatus
				+ ", description=" + description + ", pickupAddr=" + pickupAddr + ", pickupPin=" + pickupPin
				+ ", primaryContactName=" + primaryContactName + ", emailAddr=" + emailAddr + ", mobile=" + mobile
				+ ", bankNm=" + bankNm + ", accName=" + accName + ", accNo=" + accNo + ", ifsc=" + ifsc
				+ ", accVerified=" + accVerified + ", cancelledChequeProof=" + cancelledChequeProof + ", tinNo=" + tinNo
				+ ", tinProof=" + tinProof + ", tinVerified=" + tinVerified + ", panNo=" + panNo + ", panProof="
				+ panProof + ", panVerified=" + panVerified + ", tanNo=" + tanNo + ", tanProof=" + tanProof
				+ ", tanVerified=" + tanVerified + ", kycDocsAddrProof=" + kycDocsAddrProof + ", addressProofVerified="
				+ addressProofVerified + ", kycDocsIdProof=" + kycDocsIdProof + ", idProofVerified=" + idProofVerified
				+ ", dateCreated=" + dateCreated + "]";
	}

}
