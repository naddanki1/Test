package com.thincovate.bibakart.admin.services;

import com.thincovate.bibakart.admin.model.Brand;
import com.thincovate.bibakart.common.model.ResponseWrapper;

public interface BrandsService {

	ResponseWrapper addNewBrand(Brand brands);

	ResponseWrapper getAllBrands();
}
