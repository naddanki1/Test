package com.thincovate.bibakart.admin.services;

import java.util.List;

import com.thincovate.bibakart.admin.model.CategoriesModel;
import com.thincovate.bibakart.admin.model.Category;
import com.thincovate.bibakart.common.model.ResponseWrapper;
import com.thincovate.bibakart.entitymodels.Categories;

public interface CategoriesService {

	ResponseWrapper getAllCategories();

	ResponseWrapper addCategory(Category c);

	ResponseWrapper getAllSubCategories(String categoryId);

	ResponseWrapper getAllCategoriesInTreeStructure();

	Categories findById(Long id);
	
	Categories findOneByColumn(String column1, String value);

	List<CategoriesModel> getCategoriesModelList(List<Categories> categories);

}
