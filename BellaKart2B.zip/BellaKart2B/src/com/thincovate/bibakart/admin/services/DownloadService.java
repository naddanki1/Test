package com.thincovate.bibakart.admin.services;

import java.io.ByteArrayOutputStream;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.multipart.MultipartFile;

public interface DownloadService {

	ByteArrayOutputStream convertPDFToByteArrayOutputStream(String fileName);

	boolean uploadDoc(String sellerId, String docName,Long orderId, MultipartFile file,HttpServletRequest request);

	boolean uploadDocument(String sellerId, String docName, Long orderId, MultipartFile file,HttpServletRequest request);

}
