package com.thincovate.bibakart.admin.services;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.thincovate.bibakart.admin.model.SellerDetails;
import com.thincovate.bibakart.admin.model.StatusModel;
import com.thincovate.bibakart.common.model.ResponseWrapper;

public interface SellerDetailsService {

	ResponseWrapper getAllSellers();

	List<SellerDetails> getSellerUsingId(String sellerId);

	ResponseWrapper updateSellerDetails(SellerDetails sellerDetails, HttpServletRequest request);

	ResponseWrapper verifySellerDocs(String sellerId, String docName, Long status);

	ResponseWrapper changeStoreStatus(String sellerId, String status, HttpServletRequest request);

	boolean verifySeller(String sellerId, StatusModel status);

	ResponseWrapper searchSellers(String keyword);

}
