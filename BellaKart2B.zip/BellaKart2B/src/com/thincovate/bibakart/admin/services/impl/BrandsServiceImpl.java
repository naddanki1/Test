package com.thincovate.bibakart.admin.services.impl;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.thincovate.bibakart.admin.dao.BrandsDAO;
import com.thincovate.bibakart.admin.model.Brand;
import com.thincovate.bibakart.admin.model.BrandsModel;
import com.thincovate.bibakart.admin.services.BrandsService;
import com.thincovate.bibakart.catalog.services.impl.ProductsServiceImpl;
import com.thincovate.bibakart.common.model.BrandResponseWrapper;
import com.thincovate.bibakart.common.model.ResponseWrapper;
import com.thincovate.bibakart.common.utils.BibakartConstants;
import com.thincovate.bibakart.common.utils.DateUtils;
import com.thincovate.bibakart.common.utils.Responses;
import com.thincovate.bibakart.entitymodels.Brands;

@Service
@Transactional
public class BrandsServiceImpl implements BrandsService {

	@Autowired
	private BrandsDAO brandsDAO;

	static Logger log = Logger.getLogger(ProductsServiceImpl.class);

	@Override
	public ResponseWrapper addNewBrand(Brand brand) {
		ResponseWrapper returnModel = null;
		try {
			Brands b = new Brands();
			b.setBrandDesc(brand.getBrandDesc());
			b.setBrandName(brand.getBrandName());
			b.setStatus(brand.getStatus());
			b.setCreatedBy(BibakartConstants.USER_NAME);// TODO
			b.setCreatedDate(DateUtils.getCurrentDate());

			brandsDAO.save(b);

			return new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS, "Brand Added Successfully");
		} catch (Exception e) {
			e.printStackTrace();
		}
		returnModel = new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, "failed while adding Brand.Please Try again ");
		return returnModel;
	}

	@Override
	public ResponseWrapper getAllBrands() {
		try{
		ResponseWrapper returnModel = null;
		List<Brands> brands = brandsDAO.findAllByColumn(BibakartConstants.STATUS, new Integer(1));
		List<BrandsModel> brandModels = new ArrayList<BrandsModel>();
		for (Brands b : brands) {
			BrandsModel bm = new BrandsModel();
			bm.setBrandDesc(b.getBrandDesc());
			bm.setBrandId(b.getBrandId());
			bm.setBrandName(b.getBrandName());
			bm.setStatus(b.getStatus().toString());

			brandModels.add(bm);
		}
		returnModel = new BrandResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_MSG,	Responses.SUCCESS_STATUS, brandModels);
		return returnModel;
		}catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}

}
