package com.thincovate.bibakart.admin.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.thincovate.bibakart.admin.dao.CategoriesDAO;
import com.thincovate.bibakart.admin.model.CategoriesModel;
import com.thincovate.bibakart.admin.model.Category;
import com.thincovate.bibakart.admin.services.CategoriesService;
import com.thincovate.bibakart.catalog.dao.MarketingChargesDAO;
import com.thincovate.bibakart.common.model.CategoryResponseWrapper;
import com.thincovate.bibakart.common.model.ResponseWrapper;
import com.thincovate.bibakart.common.utils.BibakartConstants;
import com.thincovate.bibakart.common.utils.DateUtils;
import com.thincovate.bibakart.common.utils.Responses;
import com.thincovate.bibakart.entitymodels.Categories;
import com.thincovate.bibakart.entitymodels.MarketingCharges;

@Service
public class CategoriesServiceImpl implements CategoriesService {

	@Autowired
	private MarketingChargesDAO marketingChargesDAO;

	@Autowired
	private CategoriesDAO categoriesDAO;

	static Logger log = Logger.getLogger(CategoriesServiceImpl.class);

	@Override
	@Transactional
	public ResponseWrapper addCategory(Category category) {
		ResponseWrapper returnModel = null;
		try {
			Categories c = new Categories();
			c.setCategoryName(category.getCategoryName());
			c.setCategoryDesc(category.getCategoryDesc());
			c.setIsMainCategory(Boolean.parseBoolean(category.getIsMainCategory()));
			c.setParentCategoryId(Long.parseLong(category.getParentCategoryId()));
			c.setStatus(category.getStatus());
			c.setCreatedBy(BibakartConstants.USER_NAME);// TODO
			c.setCreatedDate(DateUtils.getCurrentDate());

			categoriesDAO.save(c);

			MarketingCharges m = new MarketingCharges();
			m.setCategories(c);
			m.setTaxOnMf(Float.parseFloat(category.getTaxOnMf()));
			m.setMkPercentage(Float.parseFloat(category.getMkPercentage()));
			m.setCreatedBy(BibakartConstants.USER_NAME); // TODO
			m.setCreatedDt(DateUtils.getCurrentDate());

			marketingChargesDAO.save(m);
			return new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS,"Category Added Successfully");
		} catch (Exception e) {
			returnModel = new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS,"failed while adding Category.Please Try again ");
			e.printStackTrace();
		}

		return returnModel;
	}

	@Override
	@Transactional
	public ResponseWrapper getAllCategories() {
		try {
			ResponseWrapper returnModel = null;
			List<Categories> categories = categoriesDAO.getTopCategoryList();
			List<CategoriesModel> categoryModels = getCategoriesModelList(categories);
			returnModel = new CategoryResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_MSG,	Responses.SUCCESS_STATUS, categoryModels);
			return returnModel;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}

	@Override
	public List<CategoriesModel> getCategoriesModelList(List<Categories> categories) {

		try {
			List<CategoriesModel> categoryModels = new ArrayList<CategoriesModel>();
			for (Categories c : categories) {
				CategoriesModel cm = new CategoriesModel();

				cm.setCategoryDesc(c.getCategoryDesc());
				cm.setCategoryName(c.getCategoryName());
				cm.setCategoryId(c.getCategoryId());
				cm.setIsMainCategory(c.getIsMainCategory());
				cm.setStatus(c.getStatus());

				MarketingCharges mCharges = c.getMarketingCharges();
				if (mCharges != null) {
					cm.setMkPercentage(mCharges.getMkPercentage().toString());
					cm.setTaxOnMf(mCharges.getTaxOnMf().toString());
				}
				categoryModels.add(cm);
			}
			return categoryModels;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public ResponseWrapper getAllSubCategories(String categoryId) {
		try {
			ResponseWrapper returnModel = null;
			List<Categories> categories = categoriesDAO.findAllByColumn(BibakartConstants.PARENT_CATEGORY_ID,
					Long.parseLong(categoryId));
			List<CategoriesModel> categoryModels = getCategoriesModelList(categories);
			returnModel = new CategoryResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_MSG,	Responses.SUCCESS_STATUS, categoryModels);
			return returnModel;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}

	@Override
	@Transactional
	public ResponseWrapper getAllCategoriesInTreeStructure() {
		try {
			ResponseWrapper returnModel = null;
			List<Categories> categories = categoriesDAO.getTopCategoryList();
			List<CategoriesModel> categoryModels = getCategoriesModelsList(categories);
			returnModel = new CategoryResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_MSG,	Responses.SUCCESS_STATUS, categoryModels);
			return returnModel;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}

	public List<CategoriesModel> getCategoriesModelsList(List<Categories> categories) {

		try {
			List<CategoriesModel> categoryModels = new ArrayList<CategoriesModel>();
			for (Categories c : categories) {
				CategoriesModel cm = new CategoriesModel();

				cm.setCategoryDesc(c.getCategoryDesc());
				cm.setCategoryName(c.getCategoryName());
				cm.setCategoryId(c.getCategoryId());
				cm.setIsMainCategory(c.getIsMainCategory());
				cm.setStatus(c.getStatus());

				MarketingCharges m = c.getMarketingCharges();

				if(m != null){
					cm.setMkPercentage(m.getMkPercentage().toString());
					cm.setTaxOnMf(m.getTaxOnMf().toString());
				}
				cm.setSubCategories(getCategoriesModelsList(categoriesDAO.findAllByColumn(BibakartConstants.PARENT_CATEGORY_ID, c.getCategoryId())));
				categoryModels.add(cm);
			}
			return categoryModels;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return null;
		}
	}


	@Override
	public Categories findById(Long id) {

		try {
			return categoriesDAO.findOne(id);
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public Categories findOneByColumn(String column1, String value) {
		try {
			return categoriesDAO.findOneByColumn(column1, value);
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return null;
		}
	}
	
}
