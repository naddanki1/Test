package com.thincovate.bibakart.admin.services.impl;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.itextpdf.text.Document;
import com.itextpdf.text.Image;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfWriter;
import com.thincovate.bibakart.admin.services.DownloadService;
import com.thincovate.bibakart.common.PropertyReader;
import com.thincovate.bibakart.common.utils.BibakartConstants;
import com.thincovate.bibakart.common.utils.FileUtils;
import com.thincovate.bibakart.entitymodels.OrdersMaster;
import com.thincovate.bibakart.orders.dao.OrdersMasterDAO;
import com.thincovate.bibakart.sessionmgnt.model.Seller;

@Service
public class DownloadServiceImpl implements DownloadService {
	Logger log = Logger.getLogger(DownloadServiceImpl.class);
	
	@Autowired
	private OrdersMasterDAO ordersMasterDAO;
	
	@Override
	public ByteArrayOutputStream convertPDFToByteArrayOutputStream(String fileName) {


		InputStream inputStream = null;
		ByteArrayOutputStream baos = null;
		try {

			inputStream = new FileInputStream(fileName);
			byte[] buffer = new byte[4096];
			baos = new ByteArrayOutputStream();

			int bytesRead;
			while ((bytesRead = inputStream.read(buffer)) != -1) {
				baos.write(buffer, 0, bytesRead);
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return baos;
	}
	@Override
	@Transactional
	public boolean uploadDoc(String sellerId, String docName,Long orderId, MultipartFile file,HttpServletRequest request) {

		InputStream inputStream = null;
		OutputStream outputStream = null;
		String fileName = null;
		String extension = null;
		List<String> errors = new ArrayList<String>();
		try {
			extension =file.getOriginalFilename().split("\\.")[1];
			log.info("Extension"+extension);
			inputStream = file.getInputStream();
			String ext =".pdf";
			if (extension.equalsIgnoreCase("pdf")||extension.equalsIgnoreCase("jpg")||extension.equalsIgnoreCase("png")||extension.equalsIgnoreCase("jpeg")) {
				//fileName = docName + ext;
				fileName = docName + "."+extension;
				String rootFolder = PropertyReader.getInstance().getProperty("loc.images.rootLocation");
				if (rootFolder == null) {
					errors.add("root directory is missing");
					log.debug("root directory is missing");
					//return new ResponseWrapper(Responses.FAILURE_STATUS, Responses.ERROR_MSG, errors);
					return false;
				}
				String docLocation = rootFolder + File.separator +"Profiles"+ File.separator + sellerId + File.separator +"Orders"+ File.separator + orderId+File.separator ;
				if (FileUtils.createDirector(docLocation)) {
					File newFile = new File(docLocation + File.separator + fileName);
					outputStream = new FileOutputStream(newFile);
					int readBytes = 0;
					byte[] buffer = new byte[8192];
					while ((readBytes = inputStream.read(buffer, 0, 8192)) != -1) {
						outputStream.write(buffer, 0, readBytes);
					}
					outputStream.close();
					inputStream.close();
						if(!extension.equalsIgnoreCase("pdf")){ // Convert to Pdf
							BufferedImage bimg = ImageIO.read(newFile);
							int width = bimg.getWidth();
							int height = bimg.getHeight();
							log.info(width + "-" + height);
							Rectangle pageSize = new Rectangle(width+1f, height+1f);
							Document document = new Document(pageSize);
						    String input = docLocation + File.separator + fileName; // .gif and .jpg are ok too!
						    String output = docLocation + File.separator + docName+".pdf";
						    try {
						      FileOutputStream fos = new FileOutputStream(output);
						      PdfWriter writer = PdfWriter.getInstance(document, fos);
						      writer.open();
						      document.open();
						      document.add(Image.getInstance(input));
						      document.close();
						      writer.close();
						      newFile.delete();
						    }
						    catch (Exception e) {
						      e.printStackTrace();
						    }
						    
						}
					
					OrdersMaster order= ordersMasterDAO.findOne(orderId);
					Seller seller = (Seller) request.getSession().getAttribute("seller");
					if(seller!=null){
						if (docName.equalsIgnoreCase(BibakartConstants.DOC_SHIPPING_LABEL))
							order.setShippingLableStatus(BibakartConstants.UPLOADED_BY_SELLER);
						else if (docName.equalsIgnoreCase(BibakartConstants.DOC_MANIFEST))
							order.setManifestStatus(BibakartConstants.UPLOADED_BY_SELLER);
					}else{
						if (docName.equalsIgnoreCase(BibakartConstants.DOC_SHIPPING_LABEL))
							order.setShippingLableStatus(BibakartConstants.UPLOADED_BY_ADMIN);
						else if (docName.equalsIgnoreCase(BibakartConstants.DOC_MANIFEST))
							order.setManifestStatus(BibakartConstants.UPLOADED_BY_ADMIN);
					}
					if((order.getShippingLableStatus()!=null && order.getManifestStatus()!=null))
							order.setStatus(BibakartConstants.STATUS_TO_SHIP);
					return true;
				}
			} else {
				errors.add("Unsupported File Type");
				//return new ResponseWrapper(Responses.FAILURE_STATUS, Responses.ERROR_MSG, errors);
				return false;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		//return new ResponseWrapper(Responses.FAILURE_CODE, Responses.ERROR_STATUS,	"Exception occured while saving image");
		return false;
	}
	
	@Override
	@Transactional
	public boolean uploadDocument(String sellerId, String docName,Long orderId, MultipartFile file,HttpServletRequest request) {

		InputStream inputStream = null;
		OutputStream outputStream = null;
		String fileName = null;
		String extension = null;
		List<String> errors = new ArrayList<String>();
		try {
			extension =file.getOriginalFilename().split("\\.")[1];
			log.info("Extension"+extension);
			inputStream = file.getInputStream();
			String ext =".pdf";
			if (extension.equalsIgnoreCase("pdf")||extension.equalsIgnoreCase("jpg")||extension.equalsIgnoreCase("png")||extension.equalsIgnoreCase("jpeg")) {
				//fileName = docName + ext;
				fileName = docName + "."+extension;
				String rootFolder = PropertyReader.getInstance().getProperty("loc.images.rootLocation");
				if (rootFolder == null) {
					errors.add("root directory is missing");
					log.debug("root directory is missing");
					//return new ResponseWrapper(Responses.FAILURE_STATUS, Responses.ERROR_MSG, errors);
					return false;
				}
				String docLocation = rootFolder + File.separator +"Profiles"+ File.separator + sellerId + File.separator +"Orders"+ File.separator + orderId+File.separator ;
				if (FileUtils.createDirector(docLocation)) {
					log.info("Extension "+docLocation);
					File newFile = new File(docLocation + File.separator + fileName);
					outputStream = new FileOutputStream(newFile);
					int readBytes = 0;
					byte[] buffer = new byte[8192];
					while ((readBytes = inputStream.read(buffer, 0, 8192)) != -1) {
						outputStream.write(buffer, 0, readBytes);
					}
					outputStream.close();
					inputStream.close();
					if(!extension.equalsIgnoreCase("pdf")){ // Convert to Pdf
						BufferedImage bimg = ImageIO.read(newFile);
						int width = bimg.getWidth();
						int height = bimg.getHeight();
						log.info(width + "-" + height);
						Rectangle pageSize = new Rectangle(width+1f, height+1f);
						Document document = new Document(pageSize);
					    String input = docLocation + File.separator + fileName; // .gif and .jpg are ok too!
					    String output = docLocation + File.separator + docName+".pdf";
					    try {
					      FileOutputStream fos = new FileOutputStream(output);
					      PdfWriter writer = PdfWriter.getInstance(document, fos);
					      writer.open();
					      document.open();
					      document.add(Image.getInstance(input));
					      document.close();
					      writer.close();
					      newFile.delete();
					    }
					    catch (Exception e) {
					      e.printStackTrace();
					    }
					    
					}
					OrdersMaster order= ordersMasterDAO.findOne(orderId);
						order.setStatus(BibakartConstants.STATUS_SHIPPED);
					return true;
				}
			} else {
				errors.add("Unsupported File Type");
				//return new ResponseWrapper(Responses.FAILURE_STATUS, Responses.ERROR_MSG, errors);
				return false;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		//return new ResponseWrapper(Responses.FAILURE_CODE, Responses.ERROR_STATUS,	"Exception occured while saving image");
		return false;
	}
}
