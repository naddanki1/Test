package com.thincovate.bibakart.admin.services.impl;

import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.thincovate.bibakart.admin.model.SellerDetails;
import com.thincovate.bibakart.admin.model.StatusModel;
import com.thincovate.bibakart.admin.services.SellerDetailsService;
import com.thincovate.bibakart.common.model.ResponseWrapper;
import com.thincovate.bibakart.common.model.SellerResponseWrapper;
import com.thincovate.bibakart.common.utils.BibakartConstants;
import com.thincovate.bibakart.common.utils.DateUtils;
import com.thincovate.bibakart.common.utils.Responses;
import com.thincovate.bibakart.entitymodels.SellerDocs;
import com.thincovate.bibakart.entitymodels.SellerMaster;
import com.thincovate.bibakart.registration.dao.SellerDocsDAO;
import com.thincovate.bibakart.registration.dao.SellerMasterDAO;
import com.thincovate.bibakart.sessionmgnt.model.Seller;

@Service
@Transactional
public class SellerDetailsServiceImpl implements SellerDetailsService {

	@Autowired
	private SellerMasterDAO sellerMasterDAO;
	
	@Autowired
	private SellerDocsDAO sellerDocsDAO;

	private static Logger log = Logger.getLogger(SellerDetailsServiceImpl.class);

	@Override
	public List<SellerDetails> getSellerUsingId(String sellerId) {
		try {
			SellerMaster sellerMaster = sellerMasterDAO.findOne(Long.parseLong(sellerId));
			List<SellerMaster> sm = new ArrayList<SellerMaster>();
			sm.add(sellerMaster);
			List<SellerDetails> sellerDetails = getSellerDetailsList(sm);
			return sellerDetails;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return null;
		}
	}

	public List<SellerDetails> getSellerDetailsList(List<SellerMaster> sm) {
		try {

			List<SellerDetails> sellerDetails = new ArrayList<SellerDetails>();
			
			for (SellerMaster sellerMaster : sm) {
				
				SellerDetails seller = new SellerDetails();
				SellerDocs sellerDocs = sellerDocsDAO.findOneByColumn("seller_id", sellerMaster.getSellerId().toString());
				if(sellerDocs !=null){
					// Bank Details
					seller.setAccName(sellerDocs.getAccName());
					seller.setBankNm(sellerDocs.getBankNm());
					seller.setAccNo(sellerDocs.getAccNo());
					seller.setCancelledChequeProof(sellerDocs.getCancelledChequeProof());
					seller.setIfsc(sellerDocs.getIfsc());
					seller.setCity(sellerDocs.getCity());
					
					// Seller Details
					seller.setSellerId(sellerMaster.getSellerId());
					seller.setEmailAddr(sellerMaster.getEmailAddr());
					seller.setMobile(sellerMaster.getMobile());
					seller.setBusinessName(sellerMaster.getBusinessName());
					seller.setDescription(sellerMaster.getDescription());
					seller.setPickupAddr(sellerMaster.getPickupAddr());
					seller.setPickupPin(sellerMaster.getPickupPin());
					seller.setPrimaryContactName(sellerMaster.getPrimaryContactName());
					seller.setSellerStatus(sellerMaster.getSellerStatus());
					seller.setStoreDisplayName(URLDecoder.decode(sellerMaster.getStoreDisplayName(),"UTF-8"));
					seller.setStoreStatus(sellerMaster.getStoreStatus());
					seller.setDateCreated(DateUtils.format(sellerMaster.getCreatedDate()));
					seller.setPanNo(sellerDocs.getPanNo());
					seller.setPanProof(sellerDocs.getPanProof());
					seller.setTanNo(sellerDocs.getTanNo());
					seller.setTanProof(sellerDocs.getTanProof());
					seller.setTinNo(sellerDocs.getTinNo());
					seller.setTinProof(sellerDocs.getTinProof());
					seller.setKycDocsAddrProof(sellerDocs.getKycDocsAddrProof());
					seller.setKycDocsIdProof(sellerDocs.getKycDocsIdProof());
							
					// Verification Status
					seller.setAccVerified(sellerDocs.getAccVerified());
					seller.setAddressProofVerified(sellerDocs.getAddressProofVerified());
					seller.setTinVerified(sellerDocs.getTinVerified());
					seller.setTanVerified(sellerDocs.getTanVerified());
					seller.setPanVerified(sellerDocs.getPanVerified());
					seller.setIdProofVerified(sellerDocs.getIdProofVerified());
					seller.setContactDeatilsVerified(sellerMaster.getContactDetailsVerified().longValue());
					sellerDetails.add(seller);
				}
				
			}

			return sellerDetails;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public ResponseWrapper verifySellerDocs(String sellerId, String docName, Long status) {

		try {
			SellerDocs sellerDocs = sellerDocsDAO.findAllByColumn("sellerMaster", sellerId).get(0);
			if(status == 1 || status == 0){
				if (docName.equalsIgnoreCase(BibakartConstants.TAN))
					sellerDocs.setTanVerified(status);
				else if (docName.equalsIgnoreCase(BibakartConstants.PAN))
					sellerDocs.setPanVerified(status);
				else if (docName.equalsIgnoreCase(BibakartConstants.TIN))
					sellerDocs.setTinVerified(status);
				else if (docName.equalsIgnoreCase(BibakartConstants.CANCELLED_CHEQUE))
					sellerDocs.setAccVerified(status);
				else if (docName.equalsIgnoreCase(BibakartConstants.KYC_ADDRESS))
					sellerDocs.setAddressProofVerified(status.toString());
				else if (docName.equalsIgnoreCase(BibakartConstants.KYC_ID))
					sellerDocs.setIdProofVerified(status.toString());
				else if(docName.equalsIgnoreCase(BibakartConstants.CONTACT_DETAILS))
					sellerDocs.getSellerMaster().setContactDetailsVerified(status.intValue());
				else {
					log.debug("invalid Doc name");
					return new ResponseWrapper(Responses.FAILURE_CODE, Responses.ERROR_STATUS, "invalid Doc name");
				}
				
				sellerDocs.setModifyBy(BibakartConstants.USER_NAME); // TODO
				sellerDocs.setModifyDate(DateUtils.getCurrentDate());
				if (sellerDocs.getTanVerified() == 1 && sellerDocs.getTinVerified() == 1
						&& sellerDocs.getPanVerified() == 1 && sellerDocs.getAccVerified() == 1
						&& sellerDocs.getAddressProofVerified().equals("1")
						&& sellerDocs.getIdProofVerified().equals("1") && sellerDocs.getSellerMaster().getContactDetailsVerified().equals(1)){
					sellerDocs.getSellerMaster().setSellerStatus(BibakartConstants.APPROVAL_STATUS.get("approved"));
					sellerDocs.getSellerMaster().setStoreStatus(BibakartConstants.ONLINE);
				}
				return new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS, Responses.SUCCESS_MSG);
			}else{
				return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS,"Invalid input for status");
			}
			
		} catch (Exception e) {
			log.debug("Error occured while updating,please try again");
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS,"Error occured while updating,please try again");
		}

	}

	@Override
	public ResponseWrapper getAllSellers() {
		try {
			ResponseWrapper returnModel = null;
			List<SellerMaster> sellerList = sellerMasterDAO.findAll();
			List<SellerDetails> sellerDetails = getSellerDetailsList(sellerList);

			returnModel = new SellerResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_MSG,Responses.SUCCESS_STATUS, sellerDetails);
			return returnModel;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}
	
	@Override
	public ResponseWrapper searchSellers(String keyword){	
		try {
			ResponseWrapper returnModel = null;
			List<SellerMaster> sellerList = sellerMasterDAO.searchSellers(BibakartConstants.SELLER_ID, keyword, BibakartConstants.MOBILE, keyword, BibakartConstants.STORE_DISPLAY_NAME, keyword, BibakartConstants.EMAIL_ADDRESS, keyword, "or");
			List<SellerDetails> sellerDetails = getSellerDetailsList(sellerList);

			returnModel = new SellerResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_MSG,Responses.SUCCESS_STATUS, sellerDetails);
			return returnModel;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}

	@Override
	public ResponseWrapper changeStoreStatus(String sellerId, String status,HttpServletRequest request) {

		try {
			SellerMaster sellerMaster = sellerMasterDAO.findOne(Long.parseLong(sellerId));
			sellerMaster.setStoreStatus(status);
			HttpSession session = request.getSession();
			Seller seller =(Seller) session.getAttribute("seller");
			if(seller!=null){
				seller.setStoreStatus(status);
				session.setAttribute("seller", seller);
			}		
			return new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_MSG, Responses.SUCCESS_STATUS);

		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}

	}

	

	@Override
	public ResponseWrapper updateSellerDetails(SellerDetails sellerDetails,HttpServletRequest request) {
		try{
			SellerMaster sellerMaster = sellerMasterDAO.findOne(sellerDetails.getSellerId());
			if(sellerMaster != null){
				sellerMaster.setDescription(sellerDetails.getDescription());
				sellerMaster.setBusinessName(sellerDetails.getBusinessName());
				sellerMaster.setStoreDisplayName(sellerDetails.getStoreDisplayName());
				sellerMaster.setPickupAddr(sellerDetails.getPickupAddr());
				sellerMaster.setPrimaryContactName(sellerDetails.getPrimaryContactName());
				SellerDocs sellerDocs=	sellerMaster.getSellerDocs().iterator().next();
				sellerDocs.setTanNo(sellerDetails.getTanNo());
				sellerDocs.setTinNo(sellerDetails.getTinNo());
				sellerDocs.setPanNo(sellerDetails.getPanNo());
				sellerDocs.setAccName(sellerDetails.getAccName());
				sellerDocs.setAccNo(sellerDetails.getAccNo());
				sellerDocs.setBankNm(sellerDetails.getBankNm());
				sellerDocs.setIfsc(sellerDetails.getIfsc());
				sellerDocs.setCity(sellerDetails.getCity());
				sellerMasterDAO.saveOrupdate(sellerMaster);	
				Seller seller = (Seller) request.getSession().getAttribute("seller");
				seller.setBusinessName(sellerDetails.getBusinessName());
				seller.setDescription(sellerDetails.getDescription());
				//seller.setEmailAddr(sellerDetails.getEmailAddr());
				//seller.setMobile(sellerDetails.getMobile().toString());
				seller.setPickupAddr(sellerDetails.getPickupAddr());
				seller.setPickupPin(sellerDetails.getPickupPin());
				seller.setPrimaryContactName(sellerDetails.getPrimaryContactName());
				seller.setStoreDisplayName(sellerDetails.getStoreDisplayName());

				HttpSession session = request.getSession();
				session.setAttribute("seller", seller);
				//updateSellerDetails(sellerDetails, request); // update session
				return new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_MSG, Responses.SUCCESS_STATUS);			
			}else {
				return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
			}
			
		}catch(Exception e){
			// TODO 
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
		
	}
	@Override
	public boolean verifySeller(String sellerId, StatusModel status) {
		try {
			List<SellerMaster> sellers = sellerMasterDAO.findAllByColumn("seller_id", Long.parseLong(sellerId));
			if (sellers != null && !sellers.isEmpty()) {
				SellerMaster seller = sellers.get(0);
				seller.setSellerStatus(status.getStatus());
				if(status.getStatus().equalsIgnoreCase("suspended") || status.getStatus().equalsIgnoreCase("approved")){
					seller.setReason(status.getReason());
					String comments = seller.getComments();
					if (comments != null)
						comments = comments + "\n" + DateUtils.getCurrentStringTime() + "-" + status.getComments();
					else
						comments = status.getComments();
					seller.setComments(comments);
					sellerMasterDAO.saveOrupdate(seller);
				}
				return true;
			}
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
		}
		return false;
	}

}
