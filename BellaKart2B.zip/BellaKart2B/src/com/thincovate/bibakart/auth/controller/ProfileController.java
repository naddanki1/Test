/**
 * 
 */
package com.thincovate.bibakart.auth.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.thincovate.bibakart.auth.model.AuthModel;
import com.thincovate.bibakart.common.model.ResponseWrapper;
import com.thincovate.bibakart.common.utils.BibakartRoles;
import com.thincovate.bibakart.common.utils.PathConstants;
import com.thincovate.bibakart.common.utils.Responses;
import com.thincovate.bibakart.sessionmgnt.services.SessionMngtService;

/**
 * @author Sandeep
 *
 */
@Controller
public class ProfileController {

	private static Logger log = Logger.getLogger(ProfileController.class);

	@Autowired
	private SessionMngtService sessionMgmtService;

	/**
	 * @param authModel
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/auth", method = RequestMethod.POST)
	public @ResponseBody ResponseWrapper autherizeUser(@RequestBody AuthModel authModel, HttpServletRequest request,	HttpServletResponse response) {
	
		if (authModel != null && authModel.getType() != null){
			if (authModel.getType().equalsIgnoreCase(BibakartRoles.VENDOR)) {
				
				return sessionMgmtService.authorizeVendor(authModel.getUserName(), authModel.getPassword(), request,response);
				
			} else if (authModel.getType().equalsIgnoreCase(BibakartRoles.USER))
				return sessionMgmtService.authorizeUser(authModel.getUserName(), authModel.getPassword(), request,response);
		}
		return new ResponseWrapper(Responses.FAILURE_CODE, Responses.ERROR_MSG, Responses.FAILURE_STATUS);
	}

	/**
	 * @param authModel
	 * @param redirectAttributes
	 * @param request
	 * @param hresponse
	 * @return
	 */
	@RequestMapping(value = "/logout", method = RequestMethod.POST)
	public String logout(@RequestParam(value="userName") String userName, RedirectAttributes redirectAttributes,	HttpServletRequest request, HttpServletResponse hresponse) {

		try {
			
			if (sessionMgmtService.isValidSession(request)) {
				HttpSession session = request.getSession();
				String role = (String) session.getAttribute("roles");
				
				if (role.contains(BibakartRoles.VENDOR)) {
					if (sessionMgmtService.logoutVendor(userName, sessionMgmtService.getToken(request), request,hresponse)) {

						redirectAttributes.addFlashAttribute("message", "Successfully Logged out");
						log.info("Successfully Logged out");
						return "redirect:/" + PathConstants.LOGIN;
					}
					return "error";

				} else if (role.contains(BibakartRoles.USER)) {
					
					if (sessionMgmtService.logoutUser(userName, sessionMgmtService.getToken(request), request,	hresponse)) {
						
						redirectAttributes.addFlashAttribute("message", "Successfully Logged out");
						log.info("Successfully Logged out");
						return "redirect:/" + PathConstants.ADMIN_LOGIN;

					}
							return "error";

				}

			} else {
				redirectAttributes.addFlashAttribute("message", "Invalid Session");
				return "redirect:/" + PathConstants.LOGIN;
			}
		} catch (Exception e) {

			e.printStackTrace();
			redirectAttributes.addFlashAttribute("message", "Problem Occured while processing");
			return "redirect:/" + PathConstants.LOGIN;
		}
		return "error";

	}
	
	@RequestMapping(value = "forgotpwd", method = RequestMethod.GET)
	public @ResponseBody ResponseWrapper forgotPassword(@RequestParam(value = "email") String email, HttpServletRequest request, HttpServletResponse hresponse) {

		return sessionMgmtService.forgotPassword(email, request);
	}
	
	@RequestMapping(value = "resetpwd", method = RequestMethod.GET)
	public String resetPassword(HttpServletRequest request, HttpServletResponse hresponse,RedirectAttributes redirectAttributes) {
		
		String reqCode = request.getParameter("i");
		if (reqCode == null){
			redirectAttributes.addFlashAttribute("pwdmsg", "Problem with the link,please try again resetting your Password");
			return "redirect:/login";
		}
		if (sessionMgmtService.checkCode(reqCode, request,redirectAttributes)) {
		
			return "redirect:/resetpswd";
		}
		return "redirect:/login";

	}

	@RequestMapping(value = "resetpwd", method = RequestMethod.POST)
	public @ResponseBody String setNewPassword(@Valid @RequestBody AuthModel auth,HttpServletRequest request) {
		HttpSession session = request.getSession();
		String userName = (String) session.getAttribute("userName");
		if (sessionMgmtService.resetPwd(userName, auth.getPassword())) {
			return "success";
		} else
			return "fail";

	}
	


}
