package com.thincovate.bibakart.auth.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.thincovate.bibakart.auth.services.SellerAuthenticationService;
import com.thincovate.bibakart.registration.services.ProspectiveSellersService;
import com.thincovate.bibakart.registration.services.SellerMasterService;

@Controller
public class SellerAuthenticationController {

	@Autowired
	SellerMasterService sellerMasterService;

	@Autowired
	ProspectiveSellersService prospectiveSellersService;

	@Autowired
	SellerAuthenticationService authService;

	//private static final Logger log = Logger.getLogger(SellerAuthenticationController.class);

	/*@RequestMapping(value = PathConstants.LOGINSUBMIT)
	public String getLoginSubmit(HttpServletRequest request, HttpSession session, Model model) {
		String loginName = request.getParameter("loginEmail");
		String loginPwd = request.getParameter("loginPwd");
		
		// look for account in seller master
		List<SellerMaster> list = sellerMasterService.findAllByColumn("emailAddr", loginName, "pwd", loginPwd, "and");
		log.debug(list);
		// do following if no account in seller master
		if (list.size() > 0) {
			ProspectiveSellers ps = new ProspectiveSellers();
			ps.setEmailAddr(list.get(0).getEmailAddr());
			ps.setMobile(list.get(0).getMobile());
			// look in prospective sellers if registration is incomplete
			ProspectiveSellers psS = prospectiveSellersService.checkDetails(ps, CommonUtils.getIpAddress(request),
					"guest");

			log.debug("The status of " + psS.getEmailAddr() + " : " + psS.getMobile() + " is " + psS.getStatus());

			// do the needful based on registration status
			if (CommonUtils.goStatus(psS.getStatus()).equals(PathConstants.GO_DASHBOARD)) {
				SellerSessions sld = new SellerSessions(list.get(0), DateUtils.getCurrentDate(), null,
						CommonUtils.getIpAddress((request)), null);
				log.debug(sld.getSellerMaster().getSellerId());
				authService.save(sld);
				session.invalidate();
				session = request.getSession(true);
				String key = CommonUtils
						.encryptText(CommonUtils.getIpAddress((request)) + session.getId() + sld.getSellerLoginId());
				sld.setMacAddr(key);
				authService.saveOrupdate(sld);
				session.setAttribute("masterKey", key);

				session.setAttribute(SessionProperties.SELLER_LOGIN_ID, sld.getSellerLoginId());

				CommonUtils.setLoginSessionValues(list.get(0), session);

			} else {
				CommonUtils.setLoginSessionValues(list.get(0), session);
			}
			return "redirect:" + CommonUtils.goStatus(psS.getStatus());

		} else {
			model.addAttribute("errorLoginMessage", "username/password is wrong");
			model.addAttribute("formData", new ProspectiveSellers());
			return "login";
		}
	}*/

}
