package com.thincovate.bibakart.auth.dao;

import org.springframework.stereotype.Repository;

import com.thincovate.bibakart.dao.AbstractHibernateDAO;
import com.thincovate.bibakart.entitymodels.Verification;

@Repository
public class VerificationDAO extends AbstractHibernateDAO<Verification> {

	public VerificationDAO() {
		setClazz(Verification.class);
	}
}
