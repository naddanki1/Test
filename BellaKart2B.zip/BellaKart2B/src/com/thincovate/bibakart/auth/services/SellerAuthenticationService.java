package com.thincovate.bibakart.auth.services;

import com.thincovate.bibakart.entitymodels.SellerSessions;

public interface SellerAuthenticationService {
	
	void save(SellerSessions sld);

	SellerSessions findOne(long attribute);

	void saveOrupdate(SellerSessions sld);

}
