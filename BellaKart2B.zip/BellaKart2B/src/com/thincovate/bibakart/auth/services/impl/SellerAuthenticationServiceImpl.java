package com.thincovate.bibakart.auth.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.thincovate.bibakart.auth.dao.SellerAuthenticationDAO;
import com.thincovate.bibakart.auth.services.SellerAuthenticationService;
import com.thincovate.bibakart.entitymodels.SellerSessions;

@Service
@Transactional
public class SellerAuthenticationServiceImpl implements SellerAuthenticationService {

	@Autowired
	private SellerAuthenticationDAO sellerAuthenticationDAO;

	//private static final Logger log = Logger.getLogger(SellerAuthenticationController.class);

	@Override
	public void save(SellerSessions sld) {
		sellerAuthenticationDAO.save(sld);

	}

	@Override
	public SellerSessions findOne(long attribute) {
		SellerSessions sld = sellerAuthenticationDAO.findOne(attribute);
		return sld;
	}

	@Override
	public void saveOrupdate(SellerSessions sld) {
		sellerAuthenticationDAO.saveOrupdate(sld);

	}
}
