package com.thincovate.bibakart.catalog.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.thincovate.bibakart.catalog.model.AttributesModel;
import com.thincovate.bibakart.catalog.model.Catalog;
import com.thincovate.bibakart.catalog.model.CatalogUpdate;
import com.thincovate.bibakart.catalog.model.Product;
import com.thincovate.bibakart.catalog.model.SellerProductsModel;
import com.thincovate.bibakart.catalog.services.ProductsService;
import com.thincovate.bibakart.catalog.services.ProductsViewService;
import com.thincovate.bibakart.catalog.services.SellerProductsService;
import com.thincovate.bibakart.common.model.ResponseWrapper;
import com.thincovate.bibakart.common.model.SellerProductResponseWrapper;
import com.thincovate.bibakart.common.utils.BibakartConstants;
import com.thincovate.bibakart.common.utils.BibakartRoles;
import com.thincovate.bibakart.common.utils.CommonUtils;
import com.thincovate.bibakart.common.utils.Responses;
import com.thincovate.bibakart.entitymodels.BulkUploadModel;
import com.thincovate.bibakart.orders.model.DummyOrder;
import com.thincovate.bibakart.sessionmgnt.model.Seller;
import com.thincovate.bibakart.sessionmgnt.services.SessionMngtService;

@RestController
public class CatalogController {

	@Autowired
	private ProductsService productsService;
	@Autowired
	private SellerProductsService sellerProductsService;
	@Autowired
	private ProductsViewService productsViewService;
	@Autowired
	private SessionMngtService sessionMngtService;


	static Logger log = Logger.getLogger(CatalogController.class);

	
	/**
	 * METADATA (ADMIN) RELATED SERVICES
	 */
	
	/**
	 * adds a new Product
	 * 
	 * @param product
	 * @param bindingResult
	 * @return
	 */
	@RequestMapping(value = { "/metadata/products" }, method = RequestMethod.POST)
	public ResponseWrapper addProduct(MultipartHttpServletRequest request, HttpServletResponse res) {

		try {
			Iterator<String> itr = request.getFileNames();
			MultipartFile mpf = request.getFile(itr.next());
			AttributesModel[] attributesModels = new AttributesModel[8];
			attributesModels[0] = new AttributesModel(BibakartConstants.SKIN_TYPE,	request.getParameter(BibakartConstants.SKIN_TYPE));
			attributesModels[1] = new AttributesModel(BibakartConstants.COMPOSITION_TYPE,	request.getParameter(BibakartConstants.COMPOSITION_TYPE));
			attributesModels[2] = new AttributesModel(BibakartConstants.APPLICATION_FREQUENCY,	request.getParameter(BibakartConstants.APPLICATION_FREQUENCY));
			attributesModels[3] = new AttributesModel(BibakartConstants.VIDEO_URL,	request.getParameter(BibakartConstants.VIDEO_URL));
			attributesModels[4] = new AttributesModel(BibakartConstants.TREATMENT_KIT,	request.getParameter(BibakartConstants.TREATMENT_KIT));
			attributesModels[5] = new AttributesModel(BibakartConstants.TREATMENT_PERIOD,request.getParameter(BibakartConstants.TREATMENT_PERIOD));
			attributesModels[6] = new AttributesModel(BibakartConstants.IS_ORGANIC,request.getParameter(BibakartConstants.IS_ORGANIC));
			attributesModels[7] = new AttributesModel(BibakartConstants.COMPOSITION,	request.getParameter(BibakartConstants.COMPOSITION));

			Product product = new Product(request.getParameter(BibakartConstants.PRODUCT_TITLE),request.getParameter(BibakartConstants.PRODUCT_DESC),
					request.getParameter(BibakartConstants.CATEGORY_ID),request.getParameter(BibakartConstants.BRAND_ID), mpf.getOriginalFilename(),
					request.getParameter(BibakartConstants.STATUS), attributesModels, mpf);

			log.info(product.toString());

			return productsService.addProduct(product);
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}

	/**
	 * returns the List of all Products
	 * 
	 * @return
	 */
	@RequestMapping(value = "/metadata/products", method = RequestMethod.GET)
	public ResponseWrapper getProducts() {
		
		log.info("get products - starts");
		ResponseWrapper response = null;
		response = productsService.getProducts();
		log.info("get products - end");
		return response;

	}

	/**
	 * get Product Details Using ProductId
	 * 
	 * @param productId
	 * @return
	 */
	@RequestMapping(value = "/metadata/products/{id}", method = RequestMethod.GET)
	public ResponseWrapper getProductUsingId(@PathVariable("id") String productId) {
		
		log.info("get product with id "+productId+"- starts");
		ResponseWrapper response = null;
		response = productsService.getProduct(productId);
		log.info("get product with id "+productId+"- end");
		return response;
	}

	/**
	 * Update existing Product Details Using ProductId
	 * 
	 * @param productId
	 * @param status
	 * @return
	 */
	@RequestMapping(value = "/metadata/products", method = RequestMethod.PUT)
	public ResponseWrapper updateProduct(@RequestParam(value = "productId") String productId,
			@RequestParam(value = "status") String status) {

		try {
			return productsService.updateProduct(productId, status);
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}
	@RequestMapping(value ="/products/categories")
	public ResponseWrapper getCategories(){
		return productsService.getProductCategories();
	}
	@RequestMapping(value ="categories/{categoryId}/products")
	public ResponseWrapper getProducts(@PathVariable int categoryId){
		return productsService.getProducts(categoryId);
	}
	@RequestMapping(value ="products/{productId}/sellers")
	public List<DummyOrder> getSellers(@PathVariable int productId){
		return productsService.getSellersFromProducts(productId);
	}
	@RequestMapping(value ="sellers/{sellerId}/products/{productId}")
	public ResponseWrapper getSKUs(@PathVariable long sellerId,@PathVariable int productId){
		return sellerProductsService.getSellerProducts(productId, sellerId);
	}

	/**
	 * VENDOR RELATED SERVICES
	 */
	
	/**
	 * For adding a new SellerProduct
	 * 
	 * @param catalog
	 * @param bindingResult
	 * @param session
	 * @return
	 */
	@RequestMapping(value = { "/sellers/products" }, method = RequestMethod.POST)
	public ResponseWrapper addSellerProduct(MultipartHttpServletRequest request) {

		ResponseWrapper response = null;
		log.info("Save seller product - starts");
		response = productsService.addToSellerCatalog(request);
		log.info("Save seller product - end");
		return response;
	}

	/**
	 * For adding a new SellerProduct By using search
	 * 
	 * @param catalog
	 * @param bindingResult
	 * @param session
	 * @return
	 */
	@RequestMapping(value = { "sellers/products/search" }, method = RequestMethod.POST)
	public ResponseWrapper addSellerProductBySearch(@Valid @RequestBody Catalog catalog,BindingResult bindingResult,HttpServletRequest request) {

		ResponseWrapper response = null;
		log.info("Save seller product using search- starts");
		response = sellerProductsService.addSellerProduct(request, catalog);
		log.info("Save seller product using search- end");
		return response;
	}

	/**
	 * returns the List of all SellerProducts
	 * 
	 * @return
	 */
	/*@RequestMapping(value = "sellers/products", method = RequestMethod.GET)
	public ResponseWrapper getSellerProducts() {

		ResponseWrapper response = null;
		log.info("Get seller products - starts");
		response = sellerProductsService.getAllSellerProducts();
		log.info("Get seller products- end");
		return response;
	}*/
	
	@RequestMapping(value = "/sellers/products", method = RequestMethod.GET)
	public ResponseWrapper getSellerProducts(HttpServletRequest request) {
		ResponseWrapper response = null;
		String offset = request.getParameter("offset");
		String maxResults = request.getParameter("maxResults");
		offset = (String) (offset == null ? 0 : offset);  // set offset 
		maxResults = (String) (maxResults == null ? 50 : maxResults); // set maxResults
		log.info("Get seller products of "+request.getParameter("status")+"with offset = "+offset+" MaxResults ="+maxResults+" - starts");
		response = sellerProductsService.getAllSellerProducts(request.getParameter("status"),Integer.parseInt(offset),Integer.parseInt(maxResults));
		log.info("Get seller products of "+request.getParameter("status")+" with offset = "+offset+" MaxResults ="+maxResults+" - end");
		return response;	
	}
	
	/**
	 * search products 
	 * 
	 * @return
	 */
	@RequestMapping(value = "sellers/products/search", method = RequestMethod.GET)
	public ResponseWrapper searchSellerProducts(String keyword, HttpServletRequest request) {

		ResponseWrapper response = null;
		try {
			log.info("Search seller products - starts");
			HttpSession session = request.getSession();
			Seller seller = (Seller) session.getAttribute("seller");
			response = productsViewService.searchSellerProduct(keyword, seller.getSellerId());
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			response = new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
		log.info("Search seller products - starts");
		return response;
	}

	/**
	 * returns the List of all SellerProducts based on seller
	 * 
	 * @return
	 */
	@RequestMapping(value = "sellers/{sellerId}/products", method = RequestMethod.GET)
	public ResponseWrapper getSellerProducts(@PathVariable(value="sellerId")String sellerId) {

		ResponseWrapper response = null;
		
		response = sellerProductsService.getSellerProductsUsingSeller(sellerId);
		log.info("Get seller products of Seller: " + sellerId + " - end");
		return response;	
	}
	@RequestMapping(value = "pn/sellers/{sellerId}/products", method = RequestMethod.GET)
	public ResponseWrapper getSellerProductsPagination(@PathVariable(value="sellerId")String sellerId,HttpServletRequest request) {
		ResponseWrapper response = null;
		
		String offset = request.getParameter("offset");
		String maxResults = request.getParameter("maxResults");
		offset = (String) (offset == null ? 0 : offset);  // set offset 
		maxResults = (String) (maxResults == null ? 50 : maxResults); // set maxResults
		log.info("Get seller products of Seller: " + sellerId + "with status "+request.getParameter("status")+" offset = "+offset+" MaxResults ="+maxResults+" - starts");
		response = sellerProductsService.getSellerProductsUsingSeller(sellerId,request.getParameter("status"),request.getParameter("stock"),Integer.parseInt(offset),Integer.parseInt(maxResults));
		log.info("Get seller products of Seller: " + sellerId + "with status "+request.getParameter("status")+" offset = "+offset+" MaxResults ="+maxResults+" - end");
		
		return response;	
	}
    /**
	 * returns SellerProduct Details Using Id
	 * 
	 * @param sellerProductId
	 * @return
	 */
	@RequestMapping(value = "sellers/products/{productId}", method = RequestMethod.GET)
	public ResponseWrapper getSellerProduct(@PathVariable("productId") String sellerProductId) {

		ResponseWrapper response = null;
		log.info("Get seller product of Id: " + sellerProductId + " - starts");
		response = sellerProductsService.getSellerProductUsingId(sellerProductId);
		log.info("Get seller product of Id: " + sellerProductId + " - end");
		return response;
	}

	/**
	 * returns SellerProduct Details Using SKUid
	 * 
	 * @param skuId
	 * @return
	 */
	@RequestMapping(value = "/products/{skuId}", method = RequestMethod.GET)
	public ResponseWrapper getSellerProductUsingSkuId(@PathVariable("skuId") String skuId) {

		ResponseWrapper response = null;
		log.info("Get seller product of SKU id: " + skuId + " - starts");
		response = sellerProductsService.getSellerProductUsingskuId(skuId);
		log.info("Get seller product of SKU id: " + skuId + " - end");
		return response;
	}

	/**
	 * returns the all Active or Inactive SellerProducts
	 * 
	 * @param availableStatus
	 * @return
	 */
	//TODO value="/sellers/products/search"
	@RequestMapping(value = "/sellers/products/status/{availableStatus}", method = RequestMethod.GET)
	public ResponseWrapper getSellerProductUsingStatus(	@PathVariable(value = "availableStatus") String availableStatus) {

		ResponseWrapper response = null;
		String column = BibakartConstants.AVAILABLE_STATUS;
		log.info("Get seller products with Available status as : " + availableStatus + " - starts");
		response = sellerProductsService.getSellerProducts(column, availableStatus);
		log.info("Get seller products with Available status as :" + availableStatus + " - end");
		return response;
	}

	/**
	 * returns the all instock or outofstock SellerProducts
	 * 
	 * @param stock
	 * @return
	 */
	//TODO value="/sellers/products/search"
	@RequestMapping(value = "/sellers/products/stockStatus/{stockStatus}", method = RequestMethod.GET)
	public ResponseWrapper getSellerProductUsingStock(@RequestParam(value = "stockStatus") String stockStatus) {

		try {
			String column = BibakartConstants.UNITS;
			return sellerProductsService.getSellerProductsusingStock(column, stockStatus);
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}

	/**
	 * Update existing SellerProduct Details
	 * 
	 * @param sellerProductId
	 * @param availableStatus
	 * @param units
	 * @param sellingPrice
	 * @return
	 */
/*	@RequestMapping(value = "/sellers/products/store", method = RequestMethod.PUT)
	public ResponseWrapper updateSellerProduct(@RequestBody CatalogUpdate catalog) {

		try {
			
			return sellerProductsService.updateSellerProduct(CommonUtils.decryptText(catalog.getSellerProductId()), catalog.getAvailableStatus(),catalog.getSellingPrice(), catalog.getUnits());
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}*/
	
	@RequestMapping(value = "/sellers/products/status", method = RequestMethod.PUT)
	public ResponseWrapper updateStatus(@RequestBody CatalogUpdate catalog) {
		
		ResponseWrapper response = null;
		log.info("Update Product Status - starts");
		response = sellerProductsService.updateStatus(CommonUtils.decryptText(catalog.getSellerProductId()), catalog.getAvailableStatus());	
		log.info("Update Product Status - end");
		return response;
	}
	@RequestMapping(value = "/sellers/products/units", method = RequestMethod.PUT)
	public ResponseWrapper updateUnits(@RequestBody CatalogUpdate catalog) {
		
		ResponseWrapper response = null;
		log.info("Update Quantity - starts");
		response = sellerProductsService.updateUnits(CommonUtils.decryptText(catalog.getSellerProductId()),	catalog.getUnits());
		log.info("Update Quantity - end");
		return response;
	}
	@RequestMapping(value = "/sellers/products/price", method = RequestMethod.PUT)
	public ResponseWrapper updatePrice(@RequestBody CatalogUpdate catalog) {
		
		ResponseWrapper response = null;
		log.info("Update Selling Price - starts");
		response = sellerProductsService.updateSellingPrice(CommonUtils.decryptText(catalog.getSellerProductId()),catalog.getSellingPrice());
		log.info("Update Selling Price - end");
		return response;
	}
	
	@RequestMapping(value = "/sellers/products", method = RequestMethod.PUT)
	public ResponseWrapper updateSellerProduct(@RequestBody SellerProductsModel sellerProduct,HttpSession session) {
		log.info(sellerProduct.toString());
		ResponseWrapper response = null;
		log.info("Update SellerProduct - starts");
		response = sellerProductsService.updateSellerProduct(sellerProduct, session);
		log.info("Update SellerProduct - end");
		return response;
	}
	
	@RequestMapping(value = "/sellers/products", method = RequestMethod.DELETE)
	public ResponseWrapper deleteSellerProduct(@RequestBody CatalogUpdate catalog) {

		ResponseWrapper response = null;
		log.info("Delete SellerProduct - starts");
		response = sellerProductsService.deleteSellerProducts(CommonUtils.decryptText(catalog.getSellerProductId()));
		log.info("Delete SellerProduct - end");
		return response;
	}

	/**
	 * Search Products
	 * 
	 * @param keyword
	 * @return
	 */
	@RequestMapping(value = "search", method = RequestMethod.GET)
	public ResponseWrapper searchProduct(@RequestParam(value = "keyword") String keyword) {

		ResponseWrapper response = null;
		log.info("Search SellerProducts  - starts" + keyword);
		if (keyword.length() > 0)
			response = productsViewService.search(keyword);
		else {
			List<SellerProductsModel> list = new ArrayList<SellerProductsModel>();
			response = new SellerProductResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_MSG,Responses.FAILURE_STATUS, list);
		}

		log.info("Search SellerProducts  - end" + keyword);
		return response;
	}

	/**
	 * Validates the SkuId
	 * 
	 * @param skuId
	 * @return
	 */
	@RequestMapping(value = "validateSkuid", method = RequestMethod.GET)
	public ResponseWrapper validateSkuId(@RequestParam(value = "skuId") String skuId) {

		ResponseWrapper response = null;
		log.info("Verify SKU id - starts" + skuId);
		response = sellerProductsService.validateSkuId(skuId);
		log.info("Verify SKU id - end" + skuId);
		return response;
	}
	
	@RequestMapping(value = { "uploadBulk" }, method = RequestMethod.POST)
	public ResponseWrapper saveBulkCatalog(BulkUploadModel bulkModel, HttpServletRequest request) {
		HttpSession session = request.getSession();
		Seller seller = (Seller) session.getAttribute("seller");
		if (seller == null)
			return new ResponseWrapper(Responses.CUSTOM_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);

		if (sessionMngtService.isValidSession(request, true, seller.getEmailAddr(), BibakartRoles.VENDOR)) {
			String result = productsService.saveBulkCatalog(bulkModel, session, request);
			if (result.equals("success"))
				return new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS, Responses.SUCCESS_MSG);
			else
				return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		} else
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, "Invalid Session");

	}
}
