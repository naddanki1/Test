package com.thincovate.bibakart.catalog.dao;

import org.springframework.stereotype.Repository;

import com.thincovate.bibakart.dao.AbstractHibernateDAO;
import com.thincovate.bibakart.entitymodels.Attributes;

@Repository
public class AttributesDAO extends AbstractHibernateDAO<Attributes> {

	public AttributesDAO() {
		setClazz(Attributes.class);
	}
}
