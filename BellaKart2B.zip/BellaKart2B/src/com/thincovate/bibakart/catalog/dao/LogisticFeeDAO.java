package com.thincovate.bibakart.catalog.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.thincovate.bibakart.dao.AbstractHibernateDAO;
import com.thincovate.bibakart.entitymodels.LogisticFee;

@Repository
public class LogisticFeeDAO extends AbstractHibernateDAO<LogisticFee> {

	public LogisticFeeDAO() {
		setClazz(LogisticFee.class);
	}

	public List<LogisticFee> getLogisticFee(Integer weight) {
		String query = "lowerLimit <=" + weight + "AND upperLimit >=" + weight;
		List<LogisticFee> list = findAllByString(query);
		return list;
	}

	public List<LogisticFee> getMaxLogisticFee() {
		String queryString = "upperLimit=(select max(upperLimit) from LogisticFee)";
		List<LogisticFee> list = findAllByString(queryString);
		return list;
	}
}
