package com.thincovate.bibakart.catalog.dao;

import org.springframework.stereotype.Repository;

import com.thincovate.bibakart.dao.AbstractHibernateDAO;
import com.thincovate.bibakart.entitymodels.ProductAttributes;

@Repository
public class ProductAttributesDAO extends AbstractHibernateDAO<ProductAttributes> {

	public ProductAttributesDAO() {
		setClazz(ProductAttributes.class);
	}
}
