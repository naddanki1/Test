package com.thincovate.bibakart.catalog.dao;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.thincovate.bibakart.dao.AbstractHibernateDAO;
import com.thincovate.bibakart.entitymodels.Products;

@Repository
@Transactional
public class ProductsDAO extends AbstractHibernateDAO<Products> {

	public ProductsDAO() {
		setClazz(Products.class);
	}
	
}
