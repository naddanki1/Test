package com.thincovate.bibakart.catalog.dao;

import org.springframework.stereotype.Repository;

import com.thincovate.bibakart.dao.AbstractHibernateDAO;
import com.thincovate.bibakart.entitymodels.ProductsView;

@Repository
public class ProductsViewDAO extends AbstractHibernateDAO<ProductsView> {

	public ProductsViewDAO() {
		setClazz(ProductsView.class);
	}

}
