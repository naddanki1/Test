package com.thincovate.bibakart.catalog.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.thincovate.bibakart.dao.AbstractHibernateDAO;
import com.thincovate.bibakart.entitymodels.SellerProducts;

@Repository
public class SellerProductsDAO extends AbstractHibernateDAO<SellerProducts> {

	public SellerProductsDAO() {
		setClazz(SellerProducts.class);
	}


}
