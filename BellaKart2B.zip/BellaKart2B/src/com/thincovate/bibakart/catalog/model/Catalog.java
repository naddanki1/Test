package com.thincovate.bibakart.catalog.model;

import java.util.Arrays;

import javax.validation.constraints.NotNull;

import org.springframework.web.multipart.MultipartFile;

public class Catalog {

	private String sellerId;
	private String productId;
	private String categoryId;
	private String brandID;
	private String brandName;
	private String productDesc;
	private String imageLocation;
	private String CompositionType;
	private String isOrganic;
	private String skinType;
	private String treatmentPeriod;
	private String treatmentKit;
	private String applicationFrequency;
	private String videoUrl;
	private String productTitle;
	private AttributesModel[] attributesModels;

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	@NotNull(message = "SKU id must be entered")
	private String skuId;
	private String mrp;
	private String sellingPrice;
	private String units;
	private String isCodAllowed;
	private String hasFreeDelivery;
	private String weightForFright;
	private String shippingCharges;
	private String estimatedShippingDays;
	private String searchKeywords;
	private String warrantyType;
	private String warrantyServiceType;
	private String modeOfAddition;
	private String availableStatus;
	private MultipartFile file;
	private String baseSku;

	public String getBaseSku() {
		return baseSku;
	}

	public void setBaseSku(String baseSku) {
		this.baseSku = baseSku;
	}

	public MultipartFile getFile() {
		return file;
	}

	public void setFile(MultipartFile file) {
		this.file = file;
	}

	public Catalog() {
	}

	public Catalog(String productId, String categoryId, String brandName, String productDesc, String imageLocation,
			String productTitle, AttributesModel[] attributesModels, String skuId, String mrp, String sellingPrice,
			String units, String isCodAllowed, String hasFreeDelivery, String weightForFright, String shippingCharges,
			String estimatedShippingDays, String searchKeywords, String warrantyType, String warrantyServiceType,
			String modeOfAddition, String availableStatus, MultipartFile file) {
		super();
		this.productId = productId;
		this.categoryId = categoryId;
		this.brandName = brandName;
		this.productDesc = productDesc;
		this.imageLocation = imageLocation;
		this.productTitle = productTitle;
		this.attributesModels = attributesModels;
		this.skuId = skuId;
		this.mrp = mrp;
		this.sellingPrice = sellingPrice;
		this.units = units;
		this.isCodAllowed = isCodAllowed;
		this.hasFreeDelivery = hasFreeDelivery;
		this.weightForFright = weightForFright;
		this.shippingCharges = shippingCharges;
		this.estimatedShippingDays = estimatedShippingDays;
		this.searchKeywords = searchKeywords;
		this.warrantyType = warrantyType;
		this.warrantyServiceType = warrantyServiceType;
		this.modeOfAddition = modeOfAddition;
		this.availableStatus = availableStatus;
		this.file = file;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}

	public String getBrandID() {
		return brandID;
	}

	public void setBrandID(String brandID) {
		this.brandID = brandID;
	}

	public String getProductDesc() {
		return productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}

	public String getImageLocation() {
		return imageLocation;
	}

	public void setImageLocation(String imageLocation) {
		this.imageLocation = imageLocation;
	}

	public String getCompositionType() {
		return CompositionType;
	}

	public void setCompositionType(String compositionType) {
		CompositionType = compositionType;
	}

	public String getIsOrganic() {
		return isOrganic;
	}

	public void setIsOrganic(String isOrganic) {
		this.isOrganic = isOrganic;
	}

	public String getSkinType() {
		return skinType;
	}

	public void setSkinType(String skinType) {
		this.skinType = skinType;
	}

	public String getTreatmentPeriod() {
		return treatmentPeriod;
	}

	public void setTreatmentPeriod(String treatmentPeriod) {
		this.treatmentPeriod = treatmentPeriod;
	}

	public String getTreatmentKit() {
		return treatmentKit;
	}

	public void setTreatmentKit(String treatmentKit) {
		this.treatmentKit = treatmentKit;
	}

	public String getApplicationFrequency() {
		return applicationFrequency;
	}

	public void setApplicationFrequency(String applicationFrequency) {
		this.applicationFrequency = applicationFrequency;
	}

	public String getVideoUrl() {
		return videoUrl;
	}

	public void setVideoUrl(String videoUrl) {
		this.videoUrl = videoUrl;
	}

	public String getProductTitle() {
		return productTitle;
	}

	public void setProductTitle(String productTitle) {
		this.productTitle = productTitle;
	}

	public AttributesModel[] getAttributesModels() {
		return attributesModels;
	}

	public void setAttributesModels(AttributesModel[] attributesModels) {
		this.attributesModels = attributesModels;
	}

	public String getSkuId() {
		return skuId;
	}

	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}

	public String getMrp() {
		return mrp;
	}

	public void setMrp(String mrp) {
		this.mrp = mrp;
	}

	public String getSellingPrice() {
		return sellingPrice;
	}

	public void setSellingPrice(String sellingPrice) {
		this.sellingPrice = sellingPrice;
	}

	public String getUnits() {
		return units;
	}

	public void setUnits(String units) {
		this.units = units;
	}

	public String getIsCodAllowed() {
		return isCodAllowed;
	}

	public void setIsCodAllowed(String isCodAllowed) {
		this.isCodAllowed = isCodAllowed;
	}

	public String getHasFreeDelivery() {
		return hasFreeDelivery;
	}

	public void setHasFreeDelivery(String hasFreeDelivery) {
		this.hasFreeDelivery = hasFreeDelivery;
	}

	public String getWeightForFright() {
		return weightForFright;
	}

	public void setWeightForFright(String weightForFright) {
		this.weightForFright = weightForFright;
	}

	public String getShippingCharges() {
		return shippingCharges;
	}

	public void setShippingCharges(String shippingCharges) {
		this.shippingCharges = shippingCharges;
	}

	public String getEstimatedShippingDays() {
		return estimatedShippingDays;
	}

	public void setEstimatedShippingDays(String estimatedShippingDays) {
		this.estimatedShippingDays = estimatedShippingDays;
	}

	public String getSearchKeywords() {
		return searchKeywords;
	}

	public void setSearchKeywords(String searchKeywords) {
		this.searchKeywords = searchKeywords;
	}

	public String getWarrantyType() {
		return warrantyType;
	}

	public void setWarrantyType(String warrantyType) {
		this.warrantyType = warrantyType;
	}

	public String getWarrantyServiceType() {
		return warrantyServiceType;
	}

	public void setWarrantyServiceType(String warrantyServiceType) {
		this.warrantyServiceType = warrantyServiceType;
	}

	public String getModeOfAddition() {
		return modeOfAddition;
	}

	public void setModeOfAddition(String modeOfAddition) {
		this.modeOfAddition = modeOfAddition;
	}

	public String getAvailableStatus() {
		return availableStatus;
	}

	public void setAvailableStatus(String availableStatus) {
		this.availableStatus = availableStatus;
	}

	@Override
	public String toString() {
		return "Catalog [productId=" + productId + ", categoryId=" + categoryId + ", brandID=" + brandID
				+ ", productDesc=" + productDesc + ", imageLocation=" + imageLocation + ", CompositionType="
				+ CompositionType + ", isOrganic=" + isOrganic + ", skinType=" + skinType + ", treatmentPeriod="
				+ treatmentPeriod + ", treatmentKit=" + treatmentKit + ", applicationFrequency=" + applicationFrequency
				+ ", videoUrl=" + videoUrl + ", productTitle=" + productTitle + ", attributesModels="
				+ Arrays.toString(attributesModels) + ", skuId=" + skuId + ", mrp=" + mrp + ", sellingPrice="
				+ sellingPrice + ", units=" + units + ", isCodAllowed=" + isCodAllowed + ", hasFreeDelivery="
				+ hasFreeDelivery + ", weightForFright=" + weightForFright + ", shippingCharges=" + shippingCharges
				+ ", estimatedShippingDays=" + estimatedShippingDays + ", searchKeywords=" + searchKeywords
				+ ", warrantyType=" + warrantyType + ", warrantyServiceType=" + warrantyServiceType
				+ ", modeOfAddition=" + modeOfAddition + ", availableStatus=" + availableStatus + "]";
	}

	/**
	 * @return the sellerId
	 */
	public String getSellerId() {
		return sellerId;
	}

	/**
	 * @param sellerId
	 *            the sellerId to set
	 */
	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}

}
