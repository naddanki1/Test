package com.thincovate.bibakart.catalog.model;

public class CatalogUpdate {

	private String sellerProductId;
	private String availableStatus;
	private String sellingPrice;
	private String units;
	private boolean isCodAllowed;
	private boolean hasFreeDelivery;
	private String weightForFright;
	private Double shippingCharges;
	private Integer estimatedShippingDays;
	private String searchKeywords;

	public boolean isCodAllowed() {
		return isCodAllowed;
	}

	public void setCodAllowed(boolean isCodAllowed) {
		this.isCodAllowed = isCodAllowed;
	}

	public boolean isHasFreeDelivery() {
		return hasFreeDelivery;
	}

	public void setHasFreeDelivery(boolean hasFreeDelivery) {
		this.hasFreeDelivery = hasFreeDelivery;
	}

	public String getWeightForFright() {
		return weightForFright;
	}

	public void setWeightForFright(String weightForFright) {
		this.weightForFright = weightForFright;
	}

	public Double getShippingCharges() {
		return shippingCharges;
	}

	public void setShippingCharges(Double shippingCharges) {
		this.shippingCharges = shippingCharges;
	}

	public Integer getEstimatedShippingDays() {
		return estimatedShippingDays;
	}

	public void setEstimatedShippingDays(Integer estimatedShippingDays) {
		this.estimatedShippingDays = estimatedShippingDays;
	}

	public String getSearchKeywords() {
		return searchKeywords;
	}

	public void setSearchKeywords(String searchKeywords) {
		this.searchKeywords = searchKeywords;
	}

	public String getSellerProductId() {
		return sellerProductId;
	}

	public void setSellerProductId(String sellerProductId) {
		this.sellerProductId = sellerProductId;
	}

	public String getAvailableStatus() {
		return availableStatus;
	}

	public void setAvailableStatus(String availableStatus) {
		this.availableStatus = availableStatus;
	}

	public String getSellingPrice() {
		return sellingPrice;
	}

	public void setSellingPrice(String sellingPrice) {
		this.sellingPrice = sellingPrice;
	}

	public String getUnits() {
		return units;
	}

	public void setUnits(String units) {
		this.units = units;
	}

}
