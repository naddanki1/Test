package com.thincovate.bibakart.catalog.model;

import com.thincovate.bibakart.entitymodels.Brands;
import com.thincovate.bibakart.entitymodels.Categories;

@SuppressWarnings("serial")
public class ExcelProducts implements java.io.Serializable {

	private Long productId;
	private Brands brands;
	private Categories categories;
	private String productTitle;
	private String productDesc;
	private String imageLoc;
	private String status;
	private String skuId;
	private Double mrp;
	private Double sellingPrice;
	private int units;
	private String isCodAllowed;
	private int hasFreeDelivery;
	private String weightForFright;
	private Integer estimatedShippingDays;
	private Double shippingCharges;
	private String searchKeyWords;
	private double marketingFee;
	private double payableValue;
	private String warrantyType;
	private String warrantyServiceType;
	private String modeOfAddition;
	private String availableStatus;
	private String approvalStatus;
	private AttributesModel[] attributes;
	private String[] imageUrls;

	public String[] getImageUrls() {
		return imageUrls;
	}

	public void setImageUrls(String[] imageUrls) {
		this.imageUrls = imageUrls;
	}

	public String getSkuId() {
		return skuId;
	}

	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}

	public Double getMrp() {
		return mrp;
	}

	public void setMrp(Double mrp) {
		this.mrp = mrp;
	}

	public Double getSellingPrice() {
		return sellingPrice;
	}

	public void setSellingPrice(Double sellingPrice) {
		this.sellingPrice = sellingPrice;
	}

	public int getUnits() {
		return units;
	}

	public void setUnits(int units) {
		this.units = units;
	}
	public String getIsCodAllowed() {
		return isCodAllowed;
	}

	public void setIsCodAllowed(String isCodAllowed) {
		this.isCodAllowed = isCodAllowed;
	}

	public String getWeightForFright() {
		return weightForFright;
	}

	public void setWeightForFright(String weightForFright) {
		this.weightForFright = weightForFright;
	}

	public String getSearchKeyWords() {
		return searchKeyWords;
	}

	public void setSearchKeyWords(String searchKeyWords) {
		this.searchKeyWords = searchKeyWords;
	}

	public int getHasFreeDelivery() {
		return hasFreeDelivery;
	}

	public void setHasFreeDelivery(int hasFreeDelivery) {
		this.hasFreeDelivery = hasFreeDelivery;
	}

	public Double getShippingCharges() {
		return shippingCharges;
	}

	public void setShippingCharges(Double shippingCharges) {
		this.shippingCharges = shippingCharges;
	}

	public int getEstimatedShippingDays() {
		return estimatedShippingDays;
	}

	public void setEstimatedShippingDays(int estimatedShippingDays) {
		this.estimatedShippingDays = estimatedShippingDays;
	}

	public Long getProductId() {
		return this.productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public Brands getBrands() {
		return this.brands;
	}

	public void setBrands(Brands brands) {
		this.brands = brands;
	}

	public Categories getCategories() {
		return this.categories;
	}

	public void setCategories(Categories categories) {
		this.categories = categories;
	}

	public String getProductTitle() {
		return this.productTitle;
	}

	public void setProductTitle(String productTitle) {
		this.productTitle = productTitle;
	}

	public String getProductDesc() {
		return this.productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}

	public String getImageLoc() {
		return this.imageLoc;
	}

	public void setImageLoc(String imageLoc) {
		this.imageLoc = imageLoc;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the marketingFee
	 */
	public double getMarketingFee() {
		return marketingFee;
	}

	/**
	 * @param marketingFee
	 *            the marketingFee to set
	 */
	public void setMarketingFee(double marketingFee) {
		this.marketingFee = marketingFee;
	}

	/**
	 * @return the payableValue
	 */
	public double getPayableValue() {
		return payableValue;
	}

	/**
	 * @param payableValue
	 *            the payableValue to set
	 */
	public void setPayableValue(double payableValue) {
		this.payableValue = payableValue;
	}

	/**
	 * @return the warrantyType
	 */
	public String getWarrantyType() {
		return warrantyType;
	}

	/**
	 * @param warrantyType
	 *            the warrantyType to set
	 */
	public void setWarrantyType(String warrantyType) {
		this.warrantyType = warrantyType;
	}

	/**
	 * @return the warrantyServiceType
	 */
	public String getWarrantyServiceType() {
		return warrantyServiceType;
	}

	/**
	 * @param warrantyServiceType
	 *            the warrantyServiceType to set
	 */
	public void setWarrantyServiceType(String warrantyServiceType) {
		this.warrantyServiceType = warrantyServiceType;
	}

	/**
	 * @return the modeOfAddition
	 */
	public String getModeOfAddition() {
		return modeOfAddition;
	}

	/**
	 * @param modeOfAddition
	 *            the modeOfAddition to set
	 */
	public void setModeOfAddition(String modeOfAddition) {
		this.modeOfAddition = modeOfAddition;
	}

	/**
	 * @return the availableStatus
	 */
	public String getAvailableStatus() {
		return availableStatus;
	}

	/**
	 * @param availableStatus
	 *            the availableStatus to set
	 */
	public void setAvailableStatus(String availableStatus) {
		this.availableStatus = availableStatus;
	}

	/**
	 * @return the approvalStatus
	 */
	public String getApprovalStatus() {
		return approvalStatus;
	}

	/**
	 * @param approvalStatus
	 *            the approvalStatus to set
	 */
	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}

	/**
	 * @param estimatedShippingDays
	 *            the estimatedShippingDays to set
	 */
	public void setEstimatedShippingDays(Integer estimatedShippingDays) {
		this.estimatedShippingDays = estimatedShippingDays;
	}

	/**
	 * @return the attributes
	 */
	public AttributesModel[] getAttributes() {
		return attributes;
	}

	/**
	 * @param attributes
	 *            the attributes to set
	 */
	public void setAttributes(AttributesModel[] attributes) {
		this.attributes = attributes;
	}

}
