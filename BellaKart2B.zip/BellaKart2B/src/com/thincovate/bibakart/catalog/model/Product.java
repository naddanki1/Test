package com.thincovate.bibakart.catalog.model;

import java.util.Arrays;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.web.multipart.MultipartFile;

public class Product {

	@NotEmpty(message = "Title can't be Empty")
	private String productTitle;
	@NotEmpty(message = "Description can't be Empty")
	private String productDesc;
	private String categoryId;
	private String brandId;
	private String brandName;
	private String imageLocation;
	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	private String status;
	private AttributesModel[] attributesModels;
	private MultipartFile file;
	public MultipartFile getFile() {
		return file;
	}

	public void setFile(MultipartFile file) {
		this.file = file;
	}

	public Product() {
		super();
	}

	@Override
	public String toString() {
		return "Product [productTitle=" + productTitle + ", productDesc=" + productDesc + ", categoryId=" + categoryId
				+ ", brandId=" + brandId + ", imageLocation=" + imageLocation + ", status=" + status
				+ ", attributesModels=" + Arrays.toString(attributesModels) + "]";
	}



	public Product(String productTitle, String productDesc, String categoryId, String brandId, String imageLocation,
			String status, AttributesModel[] attributesModels, MultipartFile file) {
		super();
		this.productTitle = productTitle;
		this.productDesc = productDesc;
		this.categoryId = categoryId;
		this.brandId = brandId;
		this.imageLocation = imageLocation;
		this.status = status;
		this.attributesModels = attributesModels;
		this.file = file;
	}

	public String getProductTitle() {
		return productTitle;
	}

	public void setProductTitle(String productTitle) {
		this.productTitle = productTitle;
	}

	public String getProductDesc() {
		return productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}

	public String getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}

	public String getBrandId() {
		return brandId;
	}

	public void setBrandId(String brandId) {
		this.brandId = brandId;
	}

	public String getImageLocation() {
		return imageLocation;
	}

	public void setImageLocation(String imageLocation) {
		this.imageLocation = imageLocation;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public AttributesModel[] getAttributesModels() {
		return attributesModels;
	}

	public void setAttributesModels(AttributesModel[] attributesModels) {
		this.attributesModels = attributesModels;
	}

	
}
