package com.thincovate.bibakart.catalog.model;

import java.util.List;

public class ProductsModel {

	// Product Details
	private Long productId;
	private String productID;
	private String productTitle;
	private String productDesc;
	private String productStatus;

	// Brand Details
	private Integer brandId;
	private String brandName;
	private String brandDesc;

	// CategoryDetails
	private Long categoryId;
	private String categoryName;
	private String categoryDesc;
	private Long parentCategoryId;
	private Long mainCategoryId;
	private Boolean isMainCategory;
	//List<CategoriesModel> categories = new ArrayList<CategoriesModel>();

	public Long getMainCategoryId() {
		return mainCategoryId;
	}

	public void setMainCategoryId(Long mainCategoryId) {
		this.mainCategoryId = mainCategoryId;
	}

/*	public List<CategoriesModel> getCategories() {
		return categories;
	}

	public void setCategories(List<CategoriesModel> categories) {
		this.categories = categories;
	}
*/
	// Attributes
	private List<AttributesModel> attributesModels;

	public String getProductID() {
		return productID;
	}

	public void setProductID(String productID) {
		this.productID = productID;
	}

	public List<AttributesModel> getAttributesModels() {
		return attributesModels;
	}

	public void setAttributesModels(List<AttributesModel> attributesModels) {
		this.attributesModels = attributesModels;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public String getProductDesc() {
		return productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}

	public String getProductStatus() {
		return productStatus;
	}

	public void setProductStatus(String productStatus) {
		this.productStatus = productStatus;
	}

	public Integer getBrandId() {
		return brandId;
	}

	public void setBrandId(Integer brandId) {
		this.brandId = brandId;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public String getBrandDesc() {
		return brandDesc;
	}

	public void setBrandDesc(String brandDesc) {
		this.brandDesc = brandDesc;
	}

	public Long getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Long categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public String getCategoryDesc() {
		return categoryDesc;
	}

	public void setCategoryDesc(String categoryDesc) {
		this.categoryDesc = categoryDesc;
	}

	public Long getParentCategoryId() {
		return parentCategoryId;
	}

	public void setParentCategoryId(Long parentCategoryId) {
		this.parentCategoryId = parentCategoryId;
	}

	public Boolean getIsMainCategory() {
		return isMainCategory;
	}

	public void setIsMainCategory(Boolean isMainCategory) {
		this.isMainCategory = isMainCategory;
	}

	public String getProductTitle() {
		return productTitle;
	}

	public void setProductTitle(String productTitle) {
		this.productTitle = productTitle;
	}

}
