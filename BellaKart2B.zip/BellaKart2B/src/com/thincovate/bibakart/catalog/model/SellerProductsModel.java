package com.thincovate.bibakart.catalog.model;

public class SellerProductsModel extends ProductsModel {

	// SellerProduct Details
	private Long sellerProductId;
	private String sellerProductID;

	private String skuId;
	private Double mrp;
	private Double sellingPrice;
	private String searchKeywords;
	private String videoUrl;
	private Boolean isCodAllowed;
	private Boolean hasFreeDelivery;
	private int weightForFright;
	private Double shippingCharges;
	private Integer estimatedShippingDays;
	private Double payableValue;
	private String warrantyType;
	private String warrantyServiceType;
	private String availableStatus;
	private String approvalStatus;
	private Integer units;
	private String treatmentPeriod;
	private String treatmentKit;
	private String isOrganic;
	private String compositionType;
	private String applicationFrequency;
	private String skinType;
	private String composition;
	private String comments;

	// SellerMaster Details
	private String sellerId;
	private String businessName;
	private String storeDisplayName;
	private String pickupAddr;
	private Integer pickupPin;
	private String primaryContactName;
	private String emailAddr;
	private Long mobile;
	private String modeOfAddition;
	private String sellerStatus;
	private String storeStatus;
	private String dateCreated;

	public Long getSellerProductId() {
		return sellerProductId;
	}

	public void setSellerProductId(Long sellerProductId) {
		this.sellerProductId = sellerProductId;
	}

	public String getSellerProductID() {
		return sellerProductID;
	}

	public void setSellerProductID(String sellerProductID) {
		this.sellerProductID = sellerProductID;
	}

	public String getSkuId() {
		return skuId;
	}

	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}

	public Double getMrp() {
		return mrp;
	}

	public void setMrp(Double mrp) {
		this.mrp = mrp;
	}

	public Double getSellingPrice() {
		return sellingPrice;
	}

	public void setSellingPrice(Double sellingPrice) {
		this.sellingPrice = sellingPrice;
	}

	public String getSearchKeywords() {
		return searchKeywords;
	}

	public void setSearchKeywords(String searchKeywords) {
		this.searchKeywords = searchKeywords;
	}

	public String getVideoUrl() {
		return videoUrl;
	}

	public void setVideoUrl(String videoUrl) {
		this.videoUrl = videoUrl;
	}

	public Boolean getIsCodAllowed() {
		return isCodAllowed;
	}

	public void setIsCodAllowed(Boolean isCodAllowed) {
		this.isCodAllowed = isCodAllowed;
	}

	public Boolean getHasFreeDelivery() {
		return hasFreeDelivery;
	}

	public void setHasFreeDelivery(Boolean hasFreeDelivery) {
		this.hasFreeDelivery = hasFreeDelivery;
	}

	public int getWeightForFright() {
		return weightForFright;
	}

	public void setWeightForFright(int weightForFright) {
		this.weightForFright = weightForFright;
	}

	public Double getShippingCharges() {
		return shippingCharges;
	}

	public void setShippingCharges(Double shippingCharges) {
		this.shippingCharges = shippingCharges;
	}

	public Integer getEstimatedShippingDays() {
		return estimatedShippingDays;
	}

	public void setEstimatedShippingDays(Integer estimatedShippingDays) {
		this.estimatedShippingDays = estimatedShippingDays;
	}

	public Double getPayableValue() {
		return payableValue;
	}

	public void setPayableValue(Double payableValue) {
		this.payableValue = payableValue;
	}

	public String getWarrantyType() {
		return warrantyType;
	}

	public void setWarrantyType(String warrantyType) {
		this.warrantyType = warrantyType;
	}

	public String getWarrantyServiceType() {
		return warrantyServiceType;
	}

	public void setWarrantyServiceType(String warrantyServiceType) {
		this.warrantyServiceType = warrantyServiceType;
	}

	public String getAvailableStatus() {
		return availableStatus;
	}

	public void setAvailableStatus(String availableStatus) {
		this.availableStatus = availableStatus;
	}

	public String getApprovalStatus() {
		return approvalStatus;
	}

	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}

	public Integer getUnits() {
		return units;
	}

	public void setUnits(Integer units) {
		this.units = units;
	}

	public String getTreatmentPeriod() {
		return treatmentPeriod;
	}

	public void setTreatmentPeriod(String treatmentPeriod) {
		this.treatmentPeriod = treatmentPeriod;
	}

	public String getTreatmentKit() {
		return treatmentKit;
	}

	public void setTreatmentKit(String treatmentKit) {
		this.treatmentKit = treatmentKit;
	}

	public String getIsOrganic() {
		return isOrganic;
	}

	public void setIsOrganic(String isOrganic) {
		this.isOrganic = isOrganic;
	}

	public String getCompositionType() {
		return compositionType;
	}

	public void setCompositionType(String compositionType) {
		this.compositionType = compositionType;
	}

	public String getApplicationFrequency() {
		return applicationFrequency;
	}

	public void setApplicationFrequency(String applicationFrequency) {
		this.applicationFrequency = applicationFrequency;
	}

	public String getSkinType() {
		return skinType;
	}

	public void setSkinType(String skinType) {
		this.skinType = skinType;
	}

	public String getComposition() {
		return composition;
	}

	public void setComposition(String composition) {
		this.composition = composition;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getSellerId() {
		return sellerId;
	}

	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public String getStoreDisplayName() {
		return storeDisplayName;
	}

	public void setStoreDisplayName(String storeDisplayName) {
		this.storeDisplayName = storeDisplayName;
	}

	public String getPickupAddr() {
		return pickupAddr;
	}

	public void setPickupAddr(String pickupAddr) {
		this.pickupAddr = pickupAddr;
	}

	public Integer getPickupPin() {
		return pickupPin;
	}

	public void setPickupPin(Integer pickupPin) {
		this.pickupPin = pickupPin;
	}

	public String getPrimaryContactName() {
		return primaryContactName;
	}

	public void setPrimaryContactName(String primaryContactName) {
		this.primaryContactName = primaryContactName;
	}

	public String getEmailAddr() {
		return emailAddr;
	}

	public void setEmailAddr(String emailAddr) {
		this.emailAddr = emailAddr;
	}

	public Long getMobile() {
		return mobile;
	}

	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}

	public String getModeOfAddition() {
		return modeOfAddition;
	}

	public void setModeOfAddition(String modeOfAddition) {
		this.modeOfAddition = modeOfAddition;
	}

	public String getSellerStatus() {
		return sellerStatus;
	}

	public void setSellerStatus(String sellerStatus) {
		this.sellerStatus = sellerStatus;
	}

	public String getStoreStatus() {
		return storeStatus;
	}

	public void setStoreStatus(String storeStatus) {
		this.storeStatus = storeStatus;
	}

	public String getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(String dateCreated) {
		this.dateCreated = dateCreated;
	}

}
