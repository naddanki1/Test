package com.thincovate.bibakart.catalog.services;


public interface AttributesService {


}
