package com.thincovate.bibakart.catalog.services;

import com.thincovate.bibakart.admin.model.LgFee;
import com.thincovate.bibakart.common.model.ResponseWrapper;
import com.thincovate.bibakart.entitymodels.LogisticFee;

public interface LogisticFeeService {

	ResponseWrapper addLogisticFee(LgFee logisticFees);

	LogisticFee getLogisticFee(Integer weight);

	Double getMaxLogisticFee();
}
