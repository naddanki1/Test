package com.thincovate.bibakart.catalog.services;


import com.thincovate.bibakart.common.model.ResponseWrapper;

public interface MarketingChargesService {

	ResponseWrapper updateMarketingCharges(String mkChargesId,String mkPercentage,String taxOnMf);
}
