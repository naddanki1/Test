package com.thincovate.bibakart.catalog.services;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.thincovate.bibakart.catalog.model.Product;
import com.thincovate.bibakart.common.model.ResponseWrapper;
import com.thincovate.bibakart.entitymodels.BulkUploadModel;
import com.thincovate.bibakart.orders.model.DummyOrder;

public interface ProductsService {

	ResponseWrapper addProduct(Product product);

	ResponseWrapper updateProduct(String productId, String status);

	ResponseWrapper getProduct(String productId);

	ResponseWrapper getProducts();

	ResponseWrapper addToSellerCatalog(MultipartHttpServletRequest request);

	String saveProductFile(HttpSession session, HttpServletRequest request, String fileName, String folderName);

	String saveExcelFile(HttpServletRequest request, CommonsMultipartFile upl, String string, HttpSession session);

	String saveBulkCatalog(BulkUploadModel bulkModel, HttpSession session, HttpServletRequest request);

	ResponseWrapper getProductCategories();

	ResponseWrapper getProducts(int categoryId);

	List<DummyOrder> getSellersFromProducts(int productId);
	

};
