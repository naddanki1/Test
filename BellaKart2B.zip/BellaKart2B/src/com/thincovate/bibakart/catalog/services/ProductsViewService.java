package com.thincovate.bibakart.catalog.services;


import com.thincovate.bibakart.common.model.ResponseWrapper;

public interface ProductsViewService {

	ResponseWrapper search(String keyword);

	ResponseWrapper searchSellerProduct(String keywod, String sellerId);

	ResponseWrapper searchSellerProducts(String keyword);
}
