package com.thincovate.bibakart.catalog.services;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.thincovate.bibakart.admin.model.StatusModel;
import com.thincovate.bibakart.catalog.model.Catalog;
import com.thincovate.bibakart.catalog.model.SellerProductsModel;
import com.thincovate.bibakart.common.model.ResponseWrapper;

public interface SellerProductsService {

	ResponseWrapper addSellerProduct(HttpServletRequest request, Catalog cm);

	// ResponseWrapper updateSellerProduct(String sellerProductId, String
	// availableStatus, String sellingPrice, String units);

	ResponseWrapper getSellerProductUsingId(String sellerProductId);

	ResponseWrapper getAllSellerProducts();

	ResponseWrapper getAllSellerProducts(String status, int offset, int maxResults);

	ResponseWrapper getSellerProductsUsingStatus(String column, String approvalstatus);

	ResponseWrapper updateSellerProductApprovalStatus(StatusModel status);

	ResponseWrapper validateSkuId(String skuId);

	ResponseWrapper getSellerProducts(String column, String availableStatus);

	ResponseWrapper getSellerProductUsingskuId(String skuId);

	ResponseWrapper getSellerProductsusingStock(String column, String stock);

	ResponseWrapper deleteSellerProducts(String sellerProductId);

	ResponseWrapper getSellerProductsUsingSeller(String sellerId);

	ResponseWrapper updateSellerProductAvailableStatus(String sellerProductId, String approvalStatus);

	ResponseWrapper updateSellerProduct(SellerProductsModel sellerProduct, HttpSession session);

	ResponseWrapper updateSellingPrice(String sellerProductId, String sellingPrice);

	ResponseWrapper updateStatus(String sellerProductId, String status);

	ResponseWrapper updateUnits(String sellerProductId, String units);

	// ResponseWrapper getSellerProductsUsingSeller(String sellerId, int offset,
	// int maxResult);

	ResponseWrapper getSellerProductsUsingSeller(String sellerId, String status, String stock, int offset,
			int maxResults);

	ResponseWrapper getSellerProducts(int productId, long sellerId);

}
