package com.thincovate.bibakart.catalog.services.impl;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.thincovate.bibakart.catalog.services.AttributesService;

@Service
@Transactional
public class AttributesServiceImpl implements AttributesService {

}
