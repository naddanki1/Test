package com.thincovate.bibakart.catalog.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.thincovate.bibakart.admin.model.LgFee;
import com.thincovate.bibakart.catalog.dao.LogisticFeeDAO;
import com.thincovate.bibakart.catalog.services.LogisticFeeService;
import com.thincovate.bibakart.common.model.ResponseWrapper;
import com.thincovate.bibakart.common.utils.BibakartConstants;
import com.thincovate.bibakart.common.utils.DateUtils;
import com.thincovate.bibakart.common.utils.Responses;
import com.thincovate.bibakart.entitymodels.LogisticFee;

@Service
public class LogisticFeeServiceImpl implements LogisticFeeService {

	@Autowired
	private LogisticFeeDAO logisticFeeDAO;

	@Override
	@Transactional
	public LogisticFee getLogisticFee(Integer weight) {
		try{
		return logisticFeeDAO.getLogisticFee(weight).get(0);
		}catch (Exception e) {
			// TODO
			e.printStackTrace();
			return null;
		}
	}

	@Override
	@Transactional
	public Double getMaxLogisticFee() {
		try{
		List<LogisticFee> list = logisticFeeDAO.getMaxLogisticFee();
		return list.get(0).getFee();
		}catch (Exception e) {
			// TODO
			e.printStackTrace();
			return null;
		}
	}

	@Override
	@Transactional
	public ResponseWrapper addLogisticFee(LgFee lgfee) {
		ResponseWrapper returnModel = null;
		try {
			LogisticFee lf = new LogisticFee();
			lf.setLowerLimit(Integer.parseInt(lgfee.getLowerLimit()));
			lf.setUpperLimit(Integer.parseInt(lgfee.getUpperLimit()));
			lf.setFee(Double.parseDouble(lgfee.getFee()));
			lf.setTaxOnLogisticFee(Float.parseFloat(lgfee.getTaxOnLogisticFee()));
			lf.setCreatedBy(BibakartConstants.USER_NAME);// TODO
			lf.setCreatedDate(DateUtils.getCurrentDate());

			logisticFeeDAO.save(lf);
			returnModel = new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS,Responses.SUCCESS_MSG);
			return returnModel;
		} catch (Exception e) {
			// TODO
			returnModel = new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, "Failed while adding,please try again");
			e.printStackTrace();
		}
		return returnModel;
	}

}
