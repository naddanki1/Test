package com.thincovate.bibakart.catalog.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.thincovate.bibakart.catalog.dao.MarketingChargesDAO;
import com.thincovate.bibakart.catalog.services.MarketingChargesService;
import com.thincovate.bibakart.common.model.ResponseWrapper;
import com.thincovate.bibakart.common.utils.BibakartConstants;
import com.thincovate.bibakart.common.utils.DateUtils;
import com.thincovate.bibakart.common.utils.Responses;
import com.thincovate.bibakart.entitymodels.MarketingCharges;

@Service
public class MarketingChargesServiceImpl implements MarketingChargesService {
	@Autowired
	private MarketingChargesDAO marketingChargesDAO;

	@Override
	public ResponseWrapper updateMarketingCharges(String mkChargesId, String mkPercentage, String taxOnMf) {
		try {
			ResponseWrapper returnModel = null;
			MarketingCharges m = marketingChargesDAO.findOne(Long.parseLong(mkChargesId));
			if (m == null)
				return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, "Invalid Id");
			m.setMkPercentage(Float.parseFloat(mkPercentage));
			m.setTaxOnMf(Float.parseFloat(taxOnMf));
			m.setModifedBy(BibakartConstants.USER_NAME); // TODO
			m.setModifiedDate(DateUtils.getCurrentDate());
			try {
				marketingChargesDAO.saveOrupdate(m);
				returnModel = new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS,Responses.SUCCESS_MSG);
				return returnModel;
			} catch (Exception e) {
				returnModel = new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS,"Failed while updating marketing charges,please try again");
				e.printStackTrace();
			}
			return returnModel;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}

}
