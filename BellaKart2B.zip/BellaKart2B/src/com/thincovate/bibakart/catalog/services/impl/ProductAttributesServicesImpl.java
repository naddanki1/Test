package com.thincovate.bibakart.catalog.services.impl;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.thincovate.bibakart.catalog.services.ProductAttributesService;

@Service
@Transactional
public class ProductAttributesServicesImpl implements ProductAttributesService {

}
