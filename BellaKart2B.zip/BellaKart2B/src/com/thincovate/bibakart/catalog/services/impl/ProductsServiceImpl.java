package com.thincovate.bibakart.catalog.services.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;

import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.thincovate.bibakart.admin.dao.BrandsDAO;
import com.thincovate.bibakart.admin.dao.CategoriesDAO;
import com.thincovate.bibakart.admin.model.Brand;
import com.thincovate.bibakart.admin.model.CategoriesModel;
import com.thincovate.bibakart.admin.services.BrandsService;
import com.thincovate.bibakart.catalog.dao.AttributesDAO;
import com.thincovate.bibakart.catalog.dao.MarketingChargesDAO;
import com.thincovate.bibakart.catalog.dao.ProductAttributesDAO;
import com.thincovate.bibakart.catalog.dao.ProductsDAO;
import com.thincovate.bibakart.catalog.dao.SellerProductsDAO;
import com.thincovate.bibakart.catalog.model.AttributesModel;
import com.thincovate.bibakart.catalog.model.Catalog;
import com.thincovate.bibakart.catalog.model.ExcelProducts;
import com.thincovate.bibakart.catalog.model.Product;
import com.thincovate.bibakart.catalog.model.ProductsModel;
import com.thincovate.bibakart.catalog.services.LogisticFeeService;
import com.thincovate.bibakart.catalog.services.ProductsService;
import com.thincovate.bibakart.catalog.services.SellerProductsService;
import com.thincovate.bibakart.common.PropertyReader;
import com.thincovate.bibakart.common.model.CategoryResponseWrapper;
import com.thincovate.bibakart.common.model.NotificationModel;
import com.thincovate.bibakart.common.model.ProductResponseWrapper;
import com.thincovate.bibakart.common.model.ResponseWrapper;
import com.thincovate.bibakart.common.model.SellerProductResponseWrapper;
import com.thincovate.bibakart.common.utils.BibakartConstants;
import com.thincovate.bibakart.common.utils.CommonUtils;
import com.thincovate.bibakart.common.utils.DateUtils;
import com.thincovate.bibakart.common.utils.FileUtils;
import com.thincovate.bibakart.common.utils.Responses;
import com.thincovate.bibakart.common.utils.VirtualProxy;
import com.thincovate.bibakart.entitymodels.Attributes;
import com.thincovate.bibakart.entitymodels.Brands;
import com.thincovate.bibakart.entitymodels.BulkUploadModel;
import com.thincovate.bibakart.entitymodels.Categories;
import com.thincovate.bibakart.entitymodels.LogisticFee;
import com.thincovate.bibakart.entitymodels.MarketingCharges;
import com.thincovate.bibakart.entitymodels.ProductAttributes;
import com.thincovate.bibakart.entitymodels.Products;
import com.thincovate.bibakart.entitymodels.SellerMaster;
import com.thincovate.bibakart.entitymodels.SellerProducts;
import com.thincovate.bibakart.images.service.ImagesService;
import com.thincovate.bibakart.orders.model.DummyOrder;
import com.thincovate.bibakart.registration.dao.SellerMasterDAO;
import com.thincovate.bibakart.sessionmgnt.model.Seller;

@Service
@Transactional
public class ProductsServiceImpl implements ProductsService {

	@Autowired
	private CategoriesDAO categoriesDAO;

	@Autowired
	private BrandsDAO brandsDAO;

	@Autowired
	private BrandsService brandsService;
	
	@Autowired
	private AttributesDAO attributesDAO;

	@Autowired
	private ProductAttributesDAO productAttributesDAO;

	@Autowired
	private MarketingChargesDAO marketingChargesDAO;

	@Autowired
	private SellerProductsDAO sellerProductsDAO;

	@Autowired
	private SellerMasterDAO sellerMasterDAO;

	@Autowired
	private ProductsDAO productsDAO;

	@Autowired
	private ImagesService imagesService;

	@Autowired
	private LogisticFeeService logisticFeeService;
	
	@Autowired
	private SellerProductsService sellerProductsService;
	
	@Autowired
	private VirtualProxy vProxy;

	private static Logger log = Logger.getLogger(ProductsServiceImpl.class);

	@Override
	@Transactional
	public ResponseWrapper addProduct(Product product) {
		ResponseWrapper returnModel = null;

		try {
			Categories categories = categoriesDAO.findOne(Long.parseLong(product.getCategoryId()));
			if (categories == null)
				return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS,	"No Categories found for the given id");
			
			Brands brands = brandsDAO.findOne(Integer.parseInt(product.getBrandId()));
			if (brands == null)
				return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS,	"No Brand found for the given id");

			Products products = new Products();

			products.setBrands(brands);
			products.setCategories(categories);
			products.setProductDesc(product.getProductDesc());
			products.setProductTitle(product.getProductTitle());
			products.setStatus(product.getStatus());
			products.setCreatedBy(BibakartConstants.USER_NAME);// TODO
			products.setCreatedDate(DateUtils.getCurrentDate());

			productsDAO.save(products);
			String pid = products.getProductId().toString();
			returnModel = imagesService.saveImage(BibakartConstants.PRODUCTS, pid, product.getFile());
			if (returnModel.getCode() != 200) {
				log.info("Image Creation Failed");
			}
			AttributesModel[] attributesModels = product.getAttributesModels();
			for (AttributesModel a : attributesModels) {
				Attributes attributes = new Attributes();
				List<Attributes> list = attributesDAO.findAllByColumn(BibakartConstants.ATTRIBUTE_NAME,a.getAttributeName());
				if (list != null && list.size() > 0)
					attributes = list.get(0);
				else {
					attributes.setAttributeName(a.getAttributeName());
					attributes.setCreatedBy(BibakartConstants.USER_NAME);// TODO
					attributes.setCreatedDate(DateUtils.getCurrentDate());
					attributesDAO.save(attributes);
				}
				ProductAttributes productAttributes = new ProductAttributes();
				productAttributes.setAttributes(attributes);
				productAttributes.setCreatedBy(BibakartConstants.USER_NAME);// TODO
				productAttributes.setCreatedDate(DateUtils.getCurrentDate());
				productAttributes.setProducts(products);
				productAttributes.setValue(a.getAttributeValue());

				productAttributesDAO.save(productAttributes);
			}
			returnModel = new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS,Responses.SUCCESS_MSG);
			return returnModel;
		} catch (Exception e) {
			returnModel = new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS,"failed while adding Product.Please Try again");
			e.printStackTrace();
		}
		return returnModel;
	}

	@Override
	@Transactional
	public ResponseWrapper addToSellerCatalog(MultipartHttpServletRequest request) {
		
		try {
			ResponseWrapper returnModel = null;

			Iterator<String> itr = request.getFileNames();
			MultipartFile mpf = request.getFile(itr.next());

			AttributesModel[] attributesModels = new AttributesModel[8];
			attributesModels[0] = new AttributesModel(BibakartConstants.SKIN_TYPE,	request.getParameter(BibakartConstants.SKIN_TYPE));
			attributesModels[1] = new AttributesModel(BibakartConstants.COMPOSITION_TYPE,	request.getParameter(BibakartConstants.COMPOSITION_TYPE));
			attributesModels[2] = new AttributesModel(BibakartConstants.APPLICATION_FREQUENCY,	request.getParameter(BibakartConstants.APPLICATION_FREQUENCY));
			attributesModels[3] = new AttributesModel(BibakartConstants.VIDEO_URL,	request.getParameter(BibakartConstants.VIDEO_URL));
			attributesModels[4] = new AttributesModel(BibakartConstants.TREATMENT_KIT,	request.getParameter(BibakartConstants.TREATMENT_KIT));
			attributesModels[5] = new AttributesModel(BibakartConstants.TREATMENT_PERIOD,request.getParameter(BibakartConstants.TREATMENT_PERIOD));
			attributesModels[6] = new AttributesModel(BibakartConstants.IS_ORGANIC,request.getParameter(BibakartConstants.IS_ORGANIC));
			attributesModels[7] = new AttributesModel(BibakartConstants.COMPOSITION,	request.getParameter(BibakartConstants.COMPOSITION));

			Catalog catalog = new Catalog(request.getParameter(BibakartConstants.PRODUCT_ID),	request.getParameter(BibakartConstants.CATEGORY_ID),
					request.getParameter(BibakartConstants.BRAND_NAME),request.getParameter(BibakartConstants.PRODUCT_DESC),
					request.getParameter(BibakartConstants.IMAGE_LOCATION),request.getParameter(BibakartConstants.PRODUCT_TITLE), attributesModels,
					request.getParameter(BibakartConstants.SKU_ID), request.getParameter(BibakartConstants.MRP),request.getParameter(BibakartConstants.SELLING_PRICE),
					request.getParameter(BibakartConstants.UNITS),request.getParameter(BibakartConstants.IS_COD_ALLOWED),	request.getParameter(BibakartConstants.HAS_FREE_DELIVERY),
					request.getParameter(BibakartConstants.WEIGHT_FOR_FRIGHT),	request.getParameter(BibakartConstants.SHIPPING_CHARGES),
					request.getParameter(BibakartConstants.ESTIMATED_SHIPPING_DAYS),request.getParameter(BibakartConstants.SEARCH_KEYWORDS),	request.getParameter(BibakartConstants.WARRANTY_TYPE),
					request.getParameter(BibakartConstants.WARRANTY_SERVICE_TYPE),	request.getParameter(BibakartConstants.MODE_OF_ADDITION),request.getParameter(BibakartConstants.AVAILABLE_STATUS), mpf);

			log.info(catalog.toString());

			returnModel = addCatalog(request,catalog); // add 1 By 1
			return returnModel;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}
	
	@Transactional
	private ResponseWrapper addCatalog(HttpServletRequest request,Catalog catalog) {
		log.info("in add catalog");
		ResponseWrapper returnModel = null;
		try {
			// Get sellerrId from logged in user...
			// SellerMaster sellerMaster=sellerMasterDAO.findOne(sellerId);
			HttpSession session = request.getSession();
			Seller seller = (Seller) session.getAttribute("seller");

			SellerMaster sellerMaster = sellerMasterDAO.findOne(Long.parseLong(seller.getSellerId()));
			if (sellerMaster == null)
				return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, "Vendor Not Found");
			Categories categories = categoriesDAO.findOne(Long.parseLong(catalog.getCategoryId()));
			if (categories == null)
				return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS,"No Categories found for the given id");
			//Brands brands = brandsDAO.findOne(Integer.parseInt(catalog.getBrandID()));
				Brands  brands =brandsDAO.findOneByColumn("brandName", catalog.getBrandName());
			if (brands == null){
				if(!createBrand(catalog.getBrandName()))
				return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS,"problem occured while creating new brand");
				else{
					brands =brandsDAO.findOneByColumn("brandName", catalog.getBrandName());
				}
			}			
			// save Product Details
			Products products = saveProductInfo(brands, categories, catalog);
			
			// save SellerProduct Deatils
			if(! saveSellerProduct(catalog, products, sellerMaster))
				return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, "failed while adding Product.Please Try again");
				
			// save Image
			if(! saveProductImage(catalog, seller))
				return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, "failed while adding Product.Please Try again");
			
			returnModel = new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS,	Responses.SUCCESS_MSG);
			return returnModel;

		} catch (Exception e) {
			// TODO
			e.printStackTrace();
		}
		returnModel = new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS,	"failed while adding Product.Please Try again");
		return returnModel;
	}
	
	public Products saveProductInfo(Brands brands,Categories categories,Catalog catalog){
		try{
		Products products = new Products();
		products.setBrands(brands);
		products.setCategories(categories);
		products.setCreatedBy(BibakartConstants.USER_NAME);// TODO
		products.setCreatedDate(DateUtils.getCurrentDate());
		products.setProductDesc(catalog.getProductDesc());
		products.setProductTitle(catalog.getProductTitle());
		products.setStatus(BibakartConstants.PRODUCT_AVAILABLE);

		productsDAO.save(products);

		
		AttributesModel[] attributesModels = catalog.getAttributesModels();
		for (AttributesModel a : attributesModels) {
			Attributes attributes = new Attributes();
			List<Attributes> list = attributesDAO.findAllByColumn(BibakartConstants.ATTRIBUTE_NAME,a.getAttributeName());
			if (list != null && list.size() > 0) {
				attributes = list.get(0);
			} else {
				attributes.setAttributeName(a.getAttributeName());
				attributes.setCreatedBy(BibakartConstants.USER_NAME);// TODO
				attributes.setCreatedDate(DateUtils.getCurrentDate());
				attributesDAO.save(attributes);
			}
			// save Product Attributes
			ProductAttributes productAttributes = new ProductAttributes();
			productAttributes.setAttributes(attributes);
			productAttributes.setCreatedBy(BibakartConstants.USER_NAME);// TODO
			productAttributes.setCreatedDate(DateUtils.getCurrentDate());
			productAttributes.setProducts(products);
			productAttributes.setValue(a.getAttributeValue());
			productAttributesDAO.save(productAttributes);
		}
		return products;
		}catch(Exception e){
			// TODO 
			e.printStackTrace();
		}
		return null;	
	}
	
	public Boolean saveSellerProduct(Catalog catalog,Products products,SellerMaster sellerMaster){
		try{
			
			Double sellingPrice = Double.parseDouble(catalog.getSellingPrice());
			Double shippingCharges = catalog.getShippingCharges()==null ||  catalog.getShippingCharges().isEmpty()? 0 : Double.parseDouble(catalog.getShippingCharges());

			Boolean hasFreeDelivery = Boolean.parseBoolean(catalog.getHasFreeDelivery());
			SellerProducts sellerProducts = new SellerProducts();
			// SellerProduct details
			sellerProducts.setProducts(products);// Set Product
			sellerProducts.setSellerMaster(sellerMaster);// Set Seller
			sellerProducts.setEstimatedShippingDays(Integer.parseInt(catalog.getEstimatedShippingDays()));
			sellerProducts.setIsCodAllowed(Boolean.parseBoolean(catalog.getIsCodAllowed()));
			sellerProducts.setMrp(Double.parseDouble(catalog.getMrp()));
			sellerProducts.setSellingPrice(sellingPrice);
			sellerProducts.setSearchKeywords(catalog.getSearchKeywords());
			sellerProducts.setShippingCharges(shippingCharges);
			sellerProducts.setSkuId(catalog.getSkuId());
			sellerProducts.setUnits(Integer.parseInt(catalog.getUnits()));
			sellerProducts.setWarrantyServiceType(catalog.getWarrantyServiceType());
			sellerProducts.setWarrantyType(catalog.getWarrantyType());
			sellerProducts.setApprovalStatus(BibakartConstants.APPROVAL_STATUS.get("new"));
			sellerProducts.setAvailableStatus(catalog.getAvailableStatus());
			sellerProducts.setModeOfAddition(BibakartConstants.MODE_INDIVIDUAL);
			sellerProducts.setCreatedBy(BibakartConstants.USER_NAME); // TODO
			sellerProducts.setCreatedDt(DateUtils.getCurrentDate());
			sellerProducts.setWeightForFright(Integer.parseInt(catalog.getWeightForFright()));
			sellerProducts.setHasFreeDelivery(hasFreeDelivery);

			Long id = products.getCategories().getCategoryId();
			MarketingCharges marketingCharges = marketingChargesDAO.findOne(id);
			Float mkPercentage = marketingCharges.getMkPercentage();
			Float taxOnMf = marketingCharges.getTaxOnMf();
			Double mkFee = CommonUtils.getMkfee(sellingPrice, mkPercentage);
			sellerProducts.setMarketingFee(mkFee);
			Double tax = mkFee * (taxOnMf / 100.00);

			if (hasFreeDelivery) {
				sellerProducts.setShippingCharges(0.0);
				Double logisticFee = null;
				LogisticFee logisticFees = logisticFeeService.getLogisticFee(Integer.parseInt(catalog.getWeightForFright())); // get logistic fee
																														
				if (logisticFees != null)
					logisticFee = logisticFees.getFee();
				else
					logisticFee = logisticFeeService.getMaxLogisticFee();
				sellerProducts.setLogisticFee(logisticFee);
				Double payableValue = CommonUtils.getPayableValue(sellingPrice, mkFee, tax, logisticFee);
				sellerProducts.setPayableValue(payableValue);
			} else {
				sellerProducts.setLogisticFee(0.0);
				sellerProducts.setShippingCharges(shippingCharges);
				Double payableValue = CommonUtils.getPayableValue(sellingPrice, mkFee, tax, new Double(0));
				sellerProducts.setPayableValue(payableValue);
			}
			sellerProductsDAO.save(sellerProducts);
			return true;
						
		}catch(Exception e){
			// TODO
			e.printStackTrace();
			return false;
		}
		
	}
	
	public Boolean saveProductImage(Catalog catalog, Seller seller) {
		try {
			imagesService.saveSkuImage(seller.getSellerId(), catalog.getSkuId(), catalog.getFile().getInputStream(),1);
			return true;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return false;
		}
	}

	@Override
	@Transactional
	public ResponseWrapper getProducts() {
		try {
			ResponseWrapper returnModel = null;
			List<Products> products = productsDAO.findAll();
			List<ProductsModel> productsModels = getProductsModelList(products);
			returnModel = new ProductResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS,Responses.SUCCESS_MSG, productsModels);
			return returnModel;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}

	@Override
	@Transactional
	public ResponseWrapper getProduct(String productId) {
		try {
			ResponseWrapper returnModel = null;
			Products p = productsDAO.findOne(Long.parseLong(productId));
			if (p == null)
				return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS,"No Product Found for the give Id");
			List<Products> products = new ArrayList<Products>();
			products.add(p);
			List<ProductsModel> productsModels = getProductsModelList(products);
			returnModel = new ProductResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS,Responses.SUCCESS_MSG, productsModels);
			return returnModel;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}

	public List<ProductsModel> getProductsModelList(List<Products> products) {
		try {
			List<ProductsModel> productsModel = new ArrayList<ProductsModel>();
			for (Products p : products) {
				ProductsModel product = new ProductsModel();
				// Product Details
				product.setProductDesc(p.getProductDesc());
				product.setProductTitle(p.getProductTitle());
				product.setProductId(p.getProductId());
				product.setProductStatus(p.getStatus());
				// Brand Details
				Brands brand = new Brands();
				brand = p.getBrands();
				product.setBrandDesc(brand.getBrandDesc());
				product.setBrandId(brand.getBrandId());
				product.setBrandName(brand.getBrandName());
				// Category Details
				Categories categories = new Categories();
				categories = p.getCategories();
				product.setCategoryDesc(categories.getCategoryDesc());
				product.setCategoryId(categories.getCategoryId());
				product.setCategoryName(categories.getCategoryName());
				product.setIsMainCategory(categories.getIsMainCategory());
				product.setParentCategoryId(categories.getParentCategoryId());
				// Attributes
				Set<ProductAttributes> productAttributes = p.getProductAttributes();
				List<AttributesModel> attributesModels = new ArrayList<AttributesModel>();
				for (ProductAttributes productAttribute : productAttributes) {
					AttributesModel attributes = new AttributesModel();
					attributes.setAttributeName(productAttribute.getAttributes().getAttributeName());
					attributes.setAttributeValue(productAttribute.getValue());
					attributesModels.add(attributes);
				}
				product.setAttributesModels(attributesModels);
				productsModel.add(product);
			}
			return productsModel;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return null;
		}
	}

	@Override
	@Transactional
	public ResponseWrapper updateProduct(String productId, String status) {
		try {
			ResponseWrapper returnModel = null;
			Products p = productsDAO.findOne(Long.parseLong(productId));
			if (p == null)
				return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS,	"No Product Found for the give Id");
			p.setStatus(status);
			p.setModifiedBy(BibakartConstants.USER_NAME);// TODO
			p.setModifiedDate(DateUtils.getCurrentDate());
			try {
				productsDAO.saveOrupdate(p);
				returnModel = new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS,	"Product Details  Updated Successfully");
			} catch (Exception e) {
				returnModel = new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS,"Error Occured while updating Product Details, Please Try again");
				e.printStackTrace();
			}
			return returnModel;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}
	
	@Override
	public String saveBulkCatalog(BulkUploadModel bulkModel, final HttpSession session, final HttpServletRequest request) {
		String returnScreen = null;

			ArrayList<String> errors = new ArrayList<String>();
			ArrayList<String> success = new ArrayList<String>();
			ArrayList<String> warnings = new ArrayList<String>();
			ArrayList<String> messages = new ArrayList<String>();
			ArrayList<String> mailMessages = new ArrayList<String>();
			NotificationModel notificationModel = new NotificationModel(errors, success, warnings, messages, mailMessages);
			session.setAttribute("messages", notificationModel);
			try {

				final String folderName = "uploadFiles";
				final String fileName = saveExcelFile(request, bulkModel.getExcelFile(), "uploadFiles", session);

				if (fileName.equals(BibakartConstants.FILE_EXCEEDS_5MB)) {
					errors.add(BibakartConstants.FILE_EXCEEDS_5MB);
				} else if (fileName.equals(BibakartConstants.FILE_FORMAT_EXCEL)) {
					errors.add(BibakartConstants.FILE_FORMAT_EXCEL);
				} else {
					success.add(BibakartConstants.SUCCESS_EXCEL_UPLOAD);

	/*				final String zipFile = saveZipFile(request, bulkModel.getZipFile(), "productImages", session);
					final String sellerProductsLocation = PropertyReader.getInstance().getProperty("loc.images.rootLocation") + File.separator +"Profiles" +File.separator+((Seller)session.getAttribute("seller")).getSellerId()+File.separator +"Products";
					FileUtils.createDirectory(sellerProductsLocation);
					if (zipFile.equals(BellakartConstants.FILE_ZIP_ONLY)) {
						errors.add(BellakartConstants.FILE_ZIP_ONLY);
					} else if (zipFile.equals(BellakartConstants.FILE_ZIP_EXCEEDS_15MB)) {
						errors.add(BellakartConstants.FILE_ZIP_EXCEEDS_15MB);
					} else {
						Thread resizeImage = new Thread() {
                            public void run() {
                                resizeImages(zipFile, sellerProductsLocation);
                            }
                        };
                        resizeImage.start();
						

						
					}*/
					success.add(BibakartConstants.SUCCESS_ZIP_UPLOAD);
					
					Thread upload = new Thread() {
                        public void run() {
                        	log.info("Product File upload starts");
    						saveProductFile(session, request, fileName, folderName);
    						log.info("Product File upload end");
                        }
                    };
                    upload.start();
				}

				returnScreen = "success";

				notificationModel = new NotificationModel(errors, success, warnings, messages, mailMessages);
				session.setAttribute("messages", notificationModel);
			} catch (Exception ex) {
				ex.printStackTrace();
			} finally {
				errors = null;
				warnings = null;
				messages = null;
				success = null;
				mailMessages = null;
			}

		return returnScreen;
	}
	
	@Override
	public String saveExcelFile(HttpServletRequest request, CommonsMultipartFile upl, String folderName,HttpSession session) {
		
		MultipartFile file1;
		String fileName="";
		InputStream inputStream = null;
		OutputStream outputStream = null;
		
		try {
		
			file1=upl;
			
			if (file1.getSize() > 0 && (file1.getSize()/ (1024 * 1024))<=5 ) {
				log.info("Excel save starts");
				inputStream = file1.getInputStream();
				String fileex=file1.getOriginalFilename().substring(file1.getOriginalFilename().lastIndexOf('.'),file1.getOriginalFilename().length());
				FileUtils.createDirectory(PropertyReader.getInstance().getProperty("loc.images.rootLocation")+File.separator+folderName);
			    if(fileex.equalsIgnoreCase(".xlsx")|| fileex.equalsIgnoreCase(".xls")){
					fileName=DateUtils.getCurrentStringTime()+""+fileex;
					outputStream = new FileOutputStream(PropertyReader.getInstance().getProperty("loc.images.rootLocation")+File.separator+folderName+File.separator+ fileName);
					
					int readBytes = 0;
					byte[] buffer = new byte[8192];
					while ((readBytes = inputStream.read(buffer, 0, 8192)) != -1) {
						outputStream.write(buffer, 0, readBytes);
					}
					log.info("Excel save ends");
					outputStream.close();
					inputStream.close();
			    }else{
			    	return BibakartConstants.FILE_FORMAT_EXCEL;
			    }
			}else{
				return BibakartConstants.FILE_EXCEEDS_5MB;
			}
		} catch (Exception e) {
		e.printStackTrace();
		}finally{
			file1=null;
			inputStream = null;
			outputStream = null;
		}
	    
		return fileName;
	}
	
	@Override
	public String saveProductFile(final HttpSession session, HttpServletRequest request, String fileName, String folderName) {

		try {
			File fileINput = new File(PropertyReader.getInstance().getProperty("loc.images.rootLocation") + File.separator + (folderName) + "/" + fileName);
			String extention = FilenameUtils.getExtension(fileINput.getName());
				//final String sellerId = ((Seller)session.getAttribute("seller")).getSellerId();
			if (extention.equalsIgnoreCase("xlsx")) {
				FileInputStream file = new FileInputStream(
						new File(PropertyReader.getInstance().getProperty("loc.images.rootLocation") + File.separator + (folderName) + "/" + fileName));

				// Get the workbook instance for XLS file
				XSSFWorkbook workbook = new XSSFWorkbook(file);

				// Get first sheet from the workbook
				XSSFSheet sheet = workbook.getSheetAt(0);
				final DataFormatter objDefaultFormat = new DataFormatter();
				//System.out.println(count);
				int i = 0;
				for (final Row row : sheet) {
					if(i++ == 0) continue; // skip first row, as it is heading
					log.info("Row starts "+i);
					Thread uploadRow = new Thread() {
                        public void run() {
                        	if (!checkIfRowIsEmpty(row)) {
                        		
                        		try{
                        			ExcelProducts tempPr = new ExcelProducts();

        							String catName = objDefaultFormat.formatCellValue(row.getCell(4, Row.CREATE_NULL_AS_BLANK));

        							if (vProxy.hasCategory(catName)) {
										String id = vProxy.getCategoryByName(catName);
										Categories category = new Categories();
										category.setCategoryId(Long.valueOf(id));
										category.setCategoryName(catName);
										tempPr.setCategories(category);
									}

        							String title = objDefaultFormat.formatCellValue(row.getCell(5, Row.CREATE_NULL_AS_BLANK));
        							tempPr.setProductTitle(title);

        							String desc = objDefaultFormat.formatCellValue(row.getCell(6, Row.CREATE_NULL_AS_BLANK));
        							tempPr.setProductDesc(desc);

        							String skuId = objDefaultFormat.formatCellValue(row.getCell(7, Row.CREATE_NULL_AS_BLANK));
        							tempPr.setSkuId(skuId);

        							String brandName = objDefaultFormat.formatCellValue(row.getCell(8, Row.CREATE_NULL_AS_BLANK));

        							if(vProxy.hasBrand(brandName)){
    									String id = vProxy.getBrandByName(brandName);
    									Brands brand = new Brands();
    									brand.setBrandId(Integer.valueOf(id));
    									brand.setBrandName(brandName);   
    									tempPr.setBrands(brand);
    								}else{
    									Brands ct = new Brands(brandName, "1", DateUtils.getCurrentDate(),"" + Long.valueOf(((Seller)session.getAttribute("seller")).getSellerId()));
    									ct.setBrandDesc(brandName);
    									brandsDAO.save(ct);
    									vProxy.clearCache(BibakartConstants.BRANDS);
    									tempPr.setBrands(ct);
    								}

        							String mrp = objDefaultFormat.formatCellValue(row.getCell(9, Row.CREATE_NULL_AS_BLANK));
        							tempPr.setMrp(Double.parseDouble(mrp));

        							String sellingPrice = objDefaultFormat.formatCellValue(row.getCell(10, Row.CREATE_NULL_AS_BLANK));
        							tempPr.setSellingPrice(Double.parseDouble(sellingPrice));
        		
        							String units = objDefaultFormat.formatCellValue(row.getCell(11, Row.CREATE_NULL_AS_BLANK));
        							tempPr.setUnits(Integer.parseInt(units));

        							String status = objDefaultFormat.formatCellValue(row.getCell(12, Row.CREATE_NULL_AS_BLANK));
        							tempPr.setStatus(status);

        							
        							AttributesModel[] attributes = new AttributesModel[8];

        							String compositionType = objDefaultFormat.formatCellValue(row.getCell(13, Row.CREATE_NULL_AS_BLANK));
        							attributes[1] = new AttributesModel(BibakartConstants.COMPOSITION_TYPE,compositionType);
        			
        							String composition = objDefaultFormat.formatCellValue(row.getCell(14, Row.CREATE_NULL_AS_BLANK));
        							attributes[7] = new AttributesModel(BibakartConstants.COMPOSITION,composition);
        	
        							String isOrganic = objDefaultFormat.formatCellValue(row.getCell(15, Row.CREATE_NULL_AS_BLANK));
        							attributes[6] = new AttributesModel(BibakartConstants.IS_ORGANIC,isOrganic);
        							//log.info("Reading Cell 15 -end"+DateUtils.getCurrentStringTime());
        							
        							//log.info("Reading Cell 16 -starts"+DateUtils.getCurrentStringTime());
        							String skinType = objDefaultFormat.formatCellValue(row.getCell(16, Row.CREATE_NULL_AS_BLANK));
        							attributes[0] = new AttributesModel(BibakartConstants.SKIN_TYPE,skinType);
        	
        							String treatmentPeriod = objDefaultFormat.formatCellValue(row.getCell(17, Row.CREATE_NULL_AS_BLANK));
        							attributes[5] = new AttributesModel(BibakartConstants.TREATMENT_PERIOD,treatmentPeriod);
        	
        							String treatmentKit = objDefaultFormat.formatCellValue(row.getCell(18, Row.CREATE_NULL_AS_BLANK));
        							attributes[4] = new AttributesModel(BibakartConstants.TREATMENT_KIT,treatmentKit);

        							String applicationFreq = objDefaultFormat.formatCellValue(row.getCell(19, Row.CREATE_NULL_AS_BLANK));
        							attributes[2] = new AttributesModel(BibakartConstants.APPLICATION_FREQUENCY,applicationFreq);

        							String videoUrl = objDefaultFormat.formatCellValue(row.getCell(20, Row.CREATE_NULL_AS_BLANK));
        							attributes[3] = new AttributesModel(BibakartConstants.VIDEO_URL,videoUrl);

        							String warrantyType = objDefaultFormat.formatCellValue(row.getCell(21, Row.CREATE_NULL_AS_BLANK));
        							tempPr.setWarrantyType(warrantyType);
        							
        							String warrantyServiceType = objDefaultFormat.formatCellValue(row.getCell(22, Row.CREATE_NULL_AS_BLANK));
        							tempPr.setWarrantyServiceType(warrantyServiceType);

        							String weightForFright = objDefaultFormat.formatCellValue(row.getCell(23, Row.CREATE_NULL_AS_BLANK));
        							tempPr.setWeightForFright(weightForFright);

        							String hasFreeDelv = objDefaultFormat.formatCellValue(row.getCell(24, Row.CREATE_NULL_AS_BLANK));
        							if (hasFreeDelv.equalsIgnoreCase("yes")) {
    									tempPr.setHasFreeDelivery(1);
    								} else{
    									tempPr.setHasFreeDelivery(0);
    								}

        							String shippingCharges = objDefaultFormat.formatCellValue(row.getCell(25, Row.CREATE_NULL_AS_BLANK));
        							tempPr.setShippingCharges(Double.parseDouble(shippingCharges));

        							String shippingDays = objDefaultFormat.formatCellValue(row.getCell(26, Row.CREATE_NULL_AS_BLANK));
        							tempPr.setEstimatedShippingDays(Integer.parseInt(shippingDays));

        							String keywords = objDefaultFormat.formatCellValue(row.getCell(27, Row.CREATE_NULL_AS_BLANK));
        							tempPr.setSearchKeyWords(keywords);
            						tempPr.setAttributes(attributes);
            						//prdetailsList.add(tempPr);
            						String[] imageUrls = new String[5];
            						String url = objDefaultFormat.formatCellValue(row.getCell(28, Row.CREATE_NULL_AS_BLANK));
            						imageUrls[0]= url;
            						
            						
            						String url2 = objDefaultFormat.formatCellValue(row.getCell(29, Row.CREATE_NULL_AS_BLANK));
            						imageUrls[1]= url2;
        
            						String url3 = objDefaultFormat.formatCellValue(row.getCell(30, Row.CREATE_NULL_AS_BLANK));
            						imageUrls[2]= url3;
            					
            						String url4 = objDefaultFormat.formatCellValue(row.getCell(31, Row.CREATE_NULL_AS_BLANK));
            						imageUrls[3]= url4;
            			
            						String url5 = objDefaultFormat.formatCellValue(row.getCell(32, Row.CREATE_NULL_AS_BLANK));
            						imageUrls[4]= url5;
            						tempPr.setImageUrls(imageUrls);
            						
            						String codAllowed = objDefaultFormat.formatCellValue(row.getCell(33, Row.CREATE_NULL_AS_BLANK));
            						tempPr.setIsCodAllowed(codAllowed);
            						saveRow(session, tempPr,row.getRowNum());
            						tempPr = null;
                        		}catch(Exception ex){
                        			ex.printStackTrace();
                        			log.info("Issue with this row..continue...");
                        		}
        					}
                        }
                    };
                     uploadRow.run();
                 	log.info("Row ends"+i);
				}
				file.close();
			} else {
				return "wrongExtension";
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return "success";

	}
	
	private void saveImage(String sellerId, String skuId, String[] imageUrl){
		//BufferedImage image = null;
		 try {int index=1;
			 for(String url : imageUrl){
				 if(url!=null && !url.isEmpty()){
					 log.info(DateUtils.getCurrentStringTime());
					 InputStream input = new URL(url).openStream();
					 log.info(DateUtils.getCurrentStringTime());
			           imagesService.saveSkuImage(sellerId, skuId, input,index);
			           index++;
				 }
			 }

	        } catch (IOException e) {
	        	e.printStackTrace();
	        }
	}
	
	private boolean saveRow(final HttpSession session, final ExcelProducts pe,int count){
		
		try{
		ResponseWrapper response= sellerProductsService.validateSkuId(pe.getSkuId());
		if(response.getCode()!=200){
			log.info("Duplicate SKU id found "+pe.getSkuId());
			return false;
		}
		
		Products pr = new Products();
		pr.setBrands(pe.getBrands());
		pr.setCategories(pe.getCategories());
		pr.setProductDesc(pe.getProductDesc());
		pr.setProductTitle(pe.getProductTitle());
		pr.setStatus(BibakartConstants.PRODUCT_AVAILABLE);
		pr.setCreatedBy(((Seller)session.getAttribute("seller")).getSellerId());
		pr.setCreatedDate(DateUtils.getCurrentDate());
			if(count %30 == 0)
				productsDAO.flushSession();
		productsDAO.save(pr);
		AttributesModel[] attributesModels = pe.getAttributes();
		for (AttributesModel a : attributesModels) {
			Attributes attributes = new Attributes();
			List<Attributes> list = attributesDAO.findAllByColumn(BibakartConstants.ATTRIBUTE_NAME,a.getAttributeName());
			if (list != null && list.size() > 0) {
				attributes = list.get(0);
			} else {
				attributes.setAttributeName(a.getAttributeName());
				attributes.setCreatedBy(BibakartConstants.USER_NAME);// TODO
				attributes.setCreatedDate(DateUtils.getCurrentDate());
				attributesDAO.save(attributes);
			}
			// save Product Attributes
			ProductAttributes productAttributes = new ProductAttributes();
			productAttributes.setAttributes(attributes);
			productAttributes.setCreatedBy(BibakartConstants.USER_NAME);// TODO
			productAttributes.setCreatedDate(DateUtils.getCurrentDate());
			productAttributes.setProducts(pr);
			productAttributes.setValue(a.getAttributeValue());
			productAttributesDAO.save(productAttributes);
		}

		SellerProducts se = new SellerProducts();
		Thread saveimage = new Thread(){
			public void run(){
				saveImage(((Seller)session.getAttribute("seller")).getSellerId(), pe.getSkuId(), pe.getImageUrls());
			}
		};
		saveimage.start();
		
		se.setCreatedBy(((Seller)session.getAttribute("seller")).getSellerId());
		se.setCreatedDt(DateUtils.getCurrentDate());
		se.setEstimatedShippingDays(pe.getEstimatedShippingDays());
		se.setHasFreeDelivery(pe.getHasFreeDelivery() == 1 ? true : false);
		se.setIsCodAllowed(Boolean.parseBoolean(pe.getIsCodAllowed()));
		se.setMrp(pe.getMrp());
		se.setSearchKeywords(pe.getSearchKeyWords());
		se.setSkuId(pe.getSkuId());
		se.setSellingPrice(pe.getSellingPrice());
		se.setAvailableStatus(pe.getStatus());
		se.setApprovalStatus(BibakartConstants.APPROVAL_STATUS.get("new"));
		se.setUnits(pe.getUnits());
		se.setWeightForFright(Integer.parseInt(pe.getWeightForFright()));
		se.setModeOfAddition("individual");
		
		Long id = pr.getCategories().getCategoryId();
		MarketingCharges marketingCharges = marketingChargesDAO.findOne(id);
		Float mkPercentage = marketingCharges.getMkPercentage();
		Float taxOnMf = marketingCharges.getTaxOnMf();
		Double mkFee = CommonUtils.getMkfee(pe.getSellingPrice(), mkPercentage);
		se.setMarketingFee(mkFee);
		Double tax = mkFee * (taxOnMf / 100.00);

		if (se.isHasFreeDelivery()) {
			se.setShippingCharges(0.0);
			Double logisticFee = null;
			LogisticFee logisticFees = logisticFeeService.getLogisticFee(Integer.parseInt(pe.getWeightForFright())); // get logistic fee
																													
			if (logisticFees != null)
				logisticFee = logisticFees.getFee();
			else
				logisticFee = logisticFeeService.getMaxLogisticFee();
			se.setLogisticFee(logisticFee);
			Double payableValue = CommonUtils.getPayableValue(pe.getSellingPrice(), mkFee, tax, logisticFee);
			se.setPayableValue(payableValue);
		} else {
			se.setLogisticFee(0.0);
			se.setShippingCharges(pe.getShippingCharges());
			Double payableValue = CommonUtils.getPayableValue(pe.getSellingPrice(), mkFee, tax, new Double(0));
			se.setPayableValue(payableValue);
		}
		se.setProducts(pr);
		se.setSellerMaster(	sellerMasterDAO.findOne(Long.valueOf(((Seller)session.getAttribute("seller")).getSellerId())));
		sellerProductsDAO.save(se);

		}catch(Exception ex){
			ex.printStackTrace();
			return false;
		}
		return true;
	}
	
	public String saveZipFile(HttpServletRequest request, CommonsMultipartFile upl, String string, HttpSession session) {
		MultipartFile file1;
		String fileName = "";
		InputStream inputStream = null;
		OutputStream outputStream = null;
		String fileName1 = null;
		try {

			file1 = upl;
			if (file1.getSize() > 0 && file1.getSize() / (1024 * 1024) < 5000) {
				inputStream = file1.getInputStream();
				String fileex = file1.getOriginalFilename().substring(file1.getOriginalFilename().lastIndexOf('.'),	file1.getOriginalFilename().length());
				FileUtils.createDirectory(PropertyReader.getInstance().getProperty("loc.images.rootLocation")+File.separator+string);
				if (fileex.equalsIgnoreCase(".zip")) {
					log.info("Zip save starts");
					//System.out.println("string : "+string);
					String timeStampForFileName = DateUtils.getCurrentStringTime();
					fileName = timeStampForFileName + "" + fileex;
					outputStream = new FileOutputStream(
							PropertyReader.getInstance().getProperty("loc.images.rootLocation") + File.separator + string + File.separator + fileName);

					int readBytes = 0;
					byte[] buffer = new byte[8192];
					while ((readBytes = inputStream.read(buffer, 0, 8192)) != -1) {
						outputStream.write(buffer, 0, readBytes);
					}
					log.info("Zip save end");
					outputStream.close();
					inputStream.close();

					fileName1 = PropertyReader.getInstance().getProperty("loc.images.rootLocation") + File.separator + string + File.separator +"expanded" +File.separator
							+ ((Seller)session.getAttribute("seller")).getSellerId() + File.separator + "products_"
							+ timeStampForFileName;

					//System.out.println("fileName1 : "+fileName1);
					FileUtils.createDirectory(fileName1);
					FileUtils.unzip(PropertyReader.getInstance().getProperty("loc.images.rootLocation") + File.separator + string + File.separator + fileName, fileName1);

				} else {
					return BibakartConstants.FILE_ZIP_ONLY;
				}
			} else {

				return BibakartConstants.FILE_ZIP_EXCEEDS_15MB;

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			file1 = null;
			inputStream = null;
			outputStream = null;
		}

		return fileName1;
	}
	private void resizeImages(String fileName1, String folderName) {

		ArrayList<File> fileList = listFilesForFolder(fileName1);
		for (File file : fileList) {
			String skuId = FileUtils.getSkuId(file.getName());
			String number = FileUtils.getNumber(file.getName());
			String fileEx = FileUtils.getExtension(file.getName());
			try {
				FileUtils.createDirectory(folderName + File.separator + skuId);
				String folderName1 = folderName + File.separator + skuId;
				FileUtils.resize(file.getAbsolutePath(),
						folderName1 + File.separator + skuId + "_" + number + "_" + BibakartConstants.IMG_THUMB_WIDTH
								+ "x" + BibakartConstants.IMG_THUMB_HEIGHT + fileEx,
								BibakartConstants.IMG_THUMB_WIDTH, BibakartConstants.IMG_THUMB_HEIGHT);
				FileUtils.resize(file.getAbsolutePath(),
						folderName1 + File.separator + skuId + "_" + number + "_" + BibakartConstants.IMG_SHOW_WIDTH
								+ "x" + BibakartConstants.IMG_SHOW_HEIGHT + fileEx,
								BibakartConstants.IMG_SHOW_WIDTH, BibakartConstants.IMG_SHOW_HEIGHT);
				FileUtils.resize(file.getAbsolutePath(),
						folderName1 + File.separator + skuId + "_" + number + "_" + BibakartConstants.IMG_LARGE_WIDTH
								+ "x" + BibakartConstants.IMG_LARGE_HEIGHT + fileEx,
								BibakartConstants.IMG_LARGE_WIDTH, BibakartConstants.IMG_LARGE_HEIGHT);

				if (number.equals("1")) {
					FileUtils.resize(file.getAbsolutePath(),
							folderName1 + File.separator + skuId + "_" + number + "_"
									+ BibakartConstants.IMG_BANNER1_WIDTH + "x" + BibakartConstants.IMG_BANNER1_HEIGHT
									+ fileEx,
									BibakartConstants.IMG_BANNER1_WIDTH, BibakartConstants.IMG_BANNER1_HEIGHT);
					FileUtils.resize(file.getAbsolutePath(),
							folderName1 + File.separator + skuId + "_" + number + "_"
									+ BibakartConstants.IMG_BANNER2_WIDTH + "x" + BibakartConstants.IMG_BANNER2_HEIGHT
									+ fileEx,
									BibakartConstants.IMG_BANNER2_WIDTH, BibakartConstants.IMG_BANNER2_HEIGHT);
					FileUtils.resize(file.getAbsolutePath(),
							folderName1 + File.separator + skuId + "_" + number + "_"
									+ BibakartConstants.IMG_BANNER3_WIDTH + "x" + BibakartConstants.IMG_BANNER3_HEIGHT
									+ fileEx,
									BibakartConstants.IMG_BANNER3_WIDTH, BibakartConstants.IMG_BANNER3_HEIGHT);
					FileUtils.resize(file.getAbsolutePath(),
							folderName1 + File.separator + skuId + "_" + number + "_"
									+ BibakartConstants.IMG_BANNER4_WIDTH + "x" + BibakartConstants.IMG_BANNER4_HEIGHT
									+ fileEx,
									BibakartConstants.IMG_BANNER4_WIDTH, BibakartConstants.IMG_BANNER4_HEIGHT);
				}
			} catch (IOException io) {
				io.printStackTrace();
			}
		}
	}
	
	private ArrayList<File> listFilesForFolder(String folderName) {
		ArrayList<File> list=new ArrayList<File>();
		File folder=new File(folderName);
	    for (final File fileEntry : folder.listFiles()) {
	        if (fileEntry.isDirectory()) {
	            
	        } else {
	           list.add(fileEntry);
	        }
	    }
	    return list;
	}

	private double calculateMarkettingFee(Long categoryId, double sellingPrice){
		MarketingCharges marketingCharges = marketingChargesDAO.findOne(categoryId);
		Float mkPercentage = marketingCharges.getMkPercentage();
		Double mkFee = CommonUtils.getMkfee(sellingPrice, mkPercentage);
		return mkFee;
	}
	
	public boolean createBrand(String brandID) {
		try {
			Brand b = new Brand();
			b.setBrandName(brandID);
			b.setBrandDesc(brandID);
			b.setStatus("1");
			if (brandsService.addNewBrand(b).getCode() == 200)
				return true;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
		}
		return false;
	}
	
	private boolean checkIfRowIsEmpty(Row row) {
	    if (row == null) {
	        return true;
	    }
	    if (row.getLastCellNum() <= 0) {
	        return true;
	    }
	    boolean isEmptyRow = true;
	    for (int cellNum = row.getFirstCellNum(); cellNum < row.getLastCellNum(); cellNum++) {
	        Cell cell = row.getCell(cellNum);
	        if (cell != null && cell.getCellType() != Cell.CELL_TYPE_BLANK && !cell.toString().isEmpty()) {
	            isEmptyRow = false;
	        }
	    }
	    return isEmptyRow;
	}

	@Override
	public ResponseWrapper getProducts(int categoryId) {
		ProductResponseWrapper response = new ProductResponseWrapper();
		try {
			List<Products> products = productsDAO.findAllByColumn("categories",categoryId);
			List<ProductsModel> productsModels = getProductsModelList(products);
			response.setProducts(productsModels);
			response.setCode(Responses.SUCCESS_CODE);
			response.setStatus(Responses.SUCCESS_STATUS);
			response.setMessage(Responses.SUCCESS_MSG);
			return response;
		} catch (Exception e) {
			// TODO: handle exception
			response.setCode(Responses.FAILURE_CODE);
			response.setStatus(Responses.FAILURE_STATUS);
			response.setMessage("Some problem occured at server...");
			log.info("Some problem occured at server...");
			return response;
		}
	}

	@Override
	public List<DummyOrder> getSellersFromProducts(int productId) {
		List<DummyOrder>  response = new ArrayList<DummyOrder>();
		try {
			List<SellerProducts> sellerProducts=sellerProductsDAO.findAllByColumn("products", productId);
			List<Long> values = new ArrayList<Long>();
				for(SellerProducts sp : sellerProducts){
					if(!values.contains(sp.getSellerMaster().getSellerId())){
						values.add(sp.getSellerMaster().getSellerId());
						DummyOrder o = new DummyOrder();
						o.setSellerId(sp.getSellerMaster().getSellerId());
						o.setSellerName(sp.getSellerMaster().getStoreDisplayName());
						response.add(o);
					}

				}
				return response;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();

		}
		return response;
	}

	@Override
	public ResponseWrapper getProductCategories() {
		CategoryResponseWrapper response = new CategoryResponseWrapper();
		List<CategoriesModel> categories = new ArrayList<CategoriesModel>();
		try {
			List<Products> products = productsDAO.findAll();
			List<Long> values = new ArrayList<Long>();
			for(Products p : products){
				if(!values.contains(p.getCategories().getCategoryId())){
					values.add(p.getCategories().getCategoryId());
					CategoriesModel c= new CategoriesModel();
					c.setCategoryId(p.getCategories().getCategoryId());
					c.setCategoryName(p.getCategories().getCategoryName());
					categories.add(c);
				}			
			}
			response.setCategories(categories);
			return response;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return response;
	}


}
