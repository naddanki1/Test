package com.thincovate.bibakart.catalog.services.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.thincovate.bibakart.admin.dao.CategoriesDAO;
import com.thincovate.bibakart.catalog.dao.ProductsViewDAO;
import com.thincovate.bibakart.catalog.dao.SellerProductsDAO;
import com.thincovate.bibakart.catalog.model.AttributesModel;
import com.thincovate.bibakart.catalog.model.SellerProductsModel;
import com.thincovate.bibakart.catalog.services.ProductsViewService;
import com.thincovate.bibakart.common.model.SellerProductResponseWrapper;
import com.thincovate.bibakart.common.model.ResponseWrapper;
import com.thincovate.bibakart.common.utils.BibakartConstants;
import com.thincovate.bibakart.common.utils.CommonUtils;
import com.thincovate.bibakart.common.utils.DateUtils;
import com.thincovate.bibakart.common.utils.Responses;
import com.thincovate.bibakart.entitymodels.Categories;
import com.thincovate.bibakart.entitymodels.ProductAttributes;
import com.thincovate.bibakart.entitymodels.Products;
import com.thincovate.bibakart.entitymodels.ProductsView;
import com.thincovate.bibakart.entitymodels.SellerMaster;
import com.thincovate.bibakart.entitymodels.SellerProducts;

@Service
@Transactional
public class ProductsViewServicesImpl implements ProductsViewService {

	@Autowired
	private SellerProductsDAO sellerProductsDAO;

	@Autowired
	private CategoriesDAO categoriesDAO;
	
	@Autowired
	private ProductsViewDAO productsViewDAO;

	static Logger log = Logger.getLogger(ProductsViewServicesImpl.class);

	@Override
	public ResponseWrapper search(String keyword) {
		try {
			ResponseWrapper returnModel = null;
			List<ProductsView> p = productsViewDAO.search(keyword);
			List<SellerProductsModel> productsModels = getProductsModel(p);
			returnModel = new SellerProductResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_MSG,	Responses.SUCCESS_STATUS, productsModels);

			return returnModel;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}

	List<SellerProductsModel> getProductsModel(List<ProductsView> productsViews) {
		try {
			List<SellerProductsModel> sellerProductsModelList = new ArrayList<SellerProductsModel>();
			for (ProductsView pv : productsViews) {
				SellerProductsModel sellerProductsModel = new SellerProductsModel();
				SellerProducts sellerProducts = sellerProductsDAO.findOne(Long.parseLong(pv.getSellerProductId()));
				Products products = sellerProducts.getProducts();
				// Product Details
				sellerProductsModel.setProductDesc(products.getProductDesc());
				sellerProductsModel.setProductId(products.getProductId());
				sellerProductsModel.setProductID(CommonUtils.encryptText(products.getProductId().toString()));
				sellerProductsModel.setProductStatus(products.getStatus());
				sellerProductsModel.setCategoryId(products.getCategories().getCategoryId());
				sellerProductsModel.setParentCategoryId(products.getCategories().getParentCategoryId());
				Categories pc= categoriesDAO.findAllByColumn(BibakartConstants.CATEGORY_ID, products.getCategories().getParentCategoryId()).get(0);
				Categories mc= categoriesDAO.findAllByColumn(BibakartConstants.CATEGORY_ID, pc.getParentCategoryId()).get(0);
				sellerProductsModel.setMainCategoryId(mc.getCategoryId());
				sellerProductsModel.setCategoryName(products.getCategories().getCategoryName());
				sellerProductsModel.setBrandId(products.getBrands().getBrandId());
				sellerProductsModel.setBrandName(products.getBrands().getBrandName());
				// Seller Product Details
				sellerProductsModel.setProductTitle(products.getProductTitle());
				sellerProductsModel.setSellerProductId(sellerProducts.getSellerProductId());
				sellerProductsModel.setSellerProductID(CommonUtils.encryptText(sellerProducts.getSellerProductId().toString()));
				sellerProductsModel.setSkuId(sellerProducts.getSkuId());
				sellerProductsModel.setSearchKeywords(sellerProducts.getSearchKeywords());
				sellerProductsModel.setMrp(sellerProducts.getMrp());
				sellerProductsModel.setSellingPrice(sellerProducts.getSellingPrice());
				sellerProductsModel.setPayableValue(sellerProducts.getPayableValue());
				sellerProductsModel.setIsCodAllowed(sellerProducts.isIsCodAllowed());
				sellerProductsModel.setWarrantyServiceType(sellerProducts.getWarrantyServiceType());
				sellerProductsModel.setWarrantyType(sellerProducts.getWarrantyType());
				sellerProductsModel.setWeightForFright(sellerProducts.getWeightForFright());
				sellerProductsModel.setUnits(sellerProducts.getUnits());
				sellerProductsModel.setHasFreeDelivery(sellerProducts.isHasFreeDelivery());
				sellerProductsModel.setEstimatedShippingDays(sellerProducts.getEstimatedShippingDays());
				sellerProductsModel.setShippingCharges(sellerProducts.getShippingCharges());
				sellerProductsModel.setApprovalStatus(sellerProducts.getApprovalStatus());
				sellerProductsModel.setAvailableStatus(sellerProducts.getAvailableStatus());
				sellerProductsModel.setDateCreated(DateUtils.format(sellerProducts.getCreatedDt()));
				sellerProductsModel.setComments(sellerProducts.getComments());
				sellerProductsModel.setModeOfAddition(sellerProducts.getModeOfAddition());
				// SellerMaster Details
				SellerMaster sellerMaster = sellerProducts.getSellerMaster();
				sellerProductsModel.setBusinessName(sellerMaster.getBusinessName());
				sellerProductsModel.setEmailAddr(sellerMaster.getEmailAddr());
				sellerProductsModel.setMobile(sellerMaster.getMobile());
				sellerProductsModel.setStoreStatus(sellerMaster.getStoreStatus());
				sellerProductsModel.setPickupAddr(sellerMaster.getPickupAddr());
				sellerProductsModel.setStoreDisplayName(sellerMaster.getStoreDisplayName());
				sellerProductsModel.setSellerId(sellerMaster.getSellerId().toString());

				// Attributes
				Set<ProductAttributes> productAttributes = products.getProductAttributes();
				List<AttributesModel> attributesModels = new ArrayList<AttributesModel>();
				for (ProductAttributes productAttribute : productAttributes) {
					AttributesModel attributes = new AttributesModel();
					attributes.setAttributeName(productAttribute.getAttributes().getAttributeName());
					attributes.setAttributeValue(productAttribute.getValue());
					attributesModels.add(attributes);
				}
				sellerProductsModel.setAttributesModels(attributesModels);

				sellerProductsModelList.add(sellerProductsModel);
			}
			return sellerProductsModelList;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public ResponseWrapper searchSellerProduct(String keywod,String sellerId) {
		try {
			ResponseWrapper returnModel = null;
			List<ProductsView> p = productsViewDAO.searchUsingId(keywod, sellerId);
			List<SellerProductsModel> productsModels = getProductsModel(p);
			returnModel = new SellerProductResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_MSG,	Responses.SUCCESS_STATUS, productsModels);

			return returnModel;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
		
	}
	
	@Override
	public ResponseWrapper searchSellerProducts(String keyword){
			try {
				ResponseWrapper returnModel = null;
				List<ProductsView> p = productsViewDAO.searchSellerProducts(keyword);
				List<SellerProductsModel> productsModels = getProductsModel(p);
				returnModel = new SellerProductResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_MSG,	Responses.SUCCESS_STATUS, productsModels);

				return returnModel;
			} catch (Exception e) {
				// TODO
				e.printStackTrace();
				return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
			}
		}
}
