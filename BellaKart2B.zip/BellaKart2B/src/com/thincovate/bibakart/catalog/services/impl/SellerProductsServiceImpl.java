package com.thincovate.bibakart.catalog.services.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.thincovate.bibakart.admin.dao.BrandsDAO;
import com.thincovate.bibakart.admin.dao.CategoriesDAO;
import com.thincovate.bibakart.admin.model.Brand;
import com.thincovate.bibakart.admin.model.StatusModel;
import com.thincovate.bibakart.admin.services.BrandsService;
import com.thincovate.bibakart.catalog.dao.MarketingChargesDAO;
import com.thincovate.bibakart.catalog.dao.ProductsDAO;
import com.thincovate.bibakart.catalog.dao.SellerProductsDAO;
import com.thincovate.bibakart.catalog.model.AttributesModel;
import com.thincovate.bibakart.catalog.model.Catalog;
import com.thincovate.bibakart.catalog.model.SellerProductsModel;
import com.thincovate.bibakart.catalog.services.LogisticFeeService;
import com.thincovate.bibakart.catalog.services.SellerProductsService;
import com.thincovate.bibakart.common.model.ResponseWrapper;
import com.thincovate.bibakart.common.model.SellerProductResponseWrapper;
import com.thincovate.bibakart.common.services.UtilService;
import com.thincovate.bibakart.common.utils.BibakartConstants;
import com.thincovate.bibakart.common.utils.CommonUtils;
import com.thincovate.bibakart.common.utils.DateUtils;
import com.thincovate.bibakart.common.utils.Responses;
import com.thincovate.bibakart.entitymodels.Attributes;
import com.thincovate.bibakart.entitymodels.Brands;
import com.thincovate.bibakart.entitymodels.Categories;
import com.thincovate.bibakart.entitymodels.LogisticFee;
import com.thincovate.bibakart.entitymodels.MarketingCharges;
import com.thincovate.bibakart.entitymodels.ProductAttributes;
import com.thincovate.bibakart.entitymodels.Products;
import com.thincovate.bibakart.entitymodels.SellerMaster;
import com.thincovate.bibakart.entitymodels.SellerProducts;
import com.thincovate.bibakart.images.service.ImagesService;
import com.thincovate.bibakart.registration.dao.SellerMasterDAO;
import com.thincovate.bibakart.sessionmgnt.model.Seller;

@Service
@Transactional
public class SellerProductsServiceImpl implements SellerProductsService {

	@Autowired
	private ProductsDAO productsDAO;
	
	@Autowired
	private CategoriesDAO categoriesDAO;
	
	@Autowired
	private BrandsDAO brandsDAO;
	
	@Autowired
	private LogisticFeeService logisticFeeService;

	@Autowired
	private MarketingChargesDAO marketingChargesDAO;

	@Autowired
	private SellerMasterDAO sellerMasterDAO;

	@Autowired
	private SellerProductsDAO sellerProductsDAO;
	
	@Autowired
	private ImagesService imagesService;
	
	@Autowired
	private BrandsService brandsService;
	
/*	@Autowired
	private AttributesDAO attributesDAO;
	
	@Autowired
	private CategoriesService categoriesService;*/
	
	@Autowired
	UtilService utilService;
	
	private static Logger log = Logger.getLogger(SellerProductsServiceImpl.class);

	@Override
	@Transactional
	public ResponseWrapper addSellerProduct(HttpServletRequest request,Catalog catalog) {

		log.info("in add seller product");
		ResponseWrapper returnModel = null;
		try {
			// Get sellerrId from logged in user...
			HttpSession session = request.getSession();
			Seller seller = (Seller) session.getAttribute("seller");
			
			SellerMaster sellerMaster = sellerMasterDAO.findOne(Long.parseLong(seller.getSellerId()));
			if (sellerMaster == null)
				return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS,"SellerMaster not found");
			Products products = productsDAO.findOne(Long.parseLong(catalog.getProductId()));
			if (products == null)
				return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS,"No Product found for the given Id");
			List<SellerProducts> list = sellerProductsDAO.findAllByColumn("skuId", catalog.getSkuId());
			if (list.size() > 0)
				return new ResponseWrapper(Responses.FAILURE_CODE, Responses.ERROR_STATUS, "skuId must be unique");

			Double sellingPrice = Double.parseDouble(catalog.getSellingPrice());
			Double shippingCharges = catalog.getShippingCharges()==null ||  catalog.getShippingCharges().isEmpty()? 0 : Double.parseDouble(catalog.getShippingCharges());
			Boolean hasFreeDelivery = Boolean.parseBoolean(catalog.getHasFreeDelivery());
			SellerProducts sellerProducts = new SellerProducts();
			// SellerProduct details
			sellerProducts.setProducts(products);// Set Product
			sellerProducts.setSellerMaster(sellerMaster);// Set Seller
			sellerProducts.setEstimatedShippingDays(Integer.parseInt(catalog.getEstimatedShippingDays()));
			sellerProducts.setIsCodAllowed(Boolean.parseBoolean(catalog.getIsCodAllowed()));
			sellerProducts.setMrp(Double.parseDouble(catalog.getMrp()));
			sellerProducts.setSellingPrice(sellingPrice);
			sellerProducts.setSearchKeywords(catalog.getSearchKeywords());
			sellerProducts.setShippingCharges(shippingCharges);
			sellerProducts.setSkuId(catalog.getSkuId());
			sellerProducts.setUnits(Integer.parseInt(catalog.getUnits()));
			sellerProducts.setWarrantyServiceType(catalog.getWarrantyServiceType());
			sellerProducts.setWarrantyType(catalog.getWarrantyType());
			sellerProducts.setApprovalStatus(BibakartConstants.APPROVAL_STATUS.get("new"));
			sellerProducts.setAvailableStatus(catalog.getAvailableStatus());
			sellerProducts.setModeOfAddition(BibakartConstants.MODE_BY_SEARCH);
			sellerProducts.setCreatedBy(BibakartConstants.USER_NAME); // TODO
			//sellerProducts.setCreatedDt(DateUtils.getCurrentDate());
			sellerProducts.setWeightForFright(Integer.parseInt(catalog.getWeightForFright()));
			sellerProducts.setHasFreeDelivery(hasFreeDelivery);

			Long id = products.getCategories().getCategoryId();
			MarketingCharges marketingCharges = marketingChargesDAO.findOne(id);
			Float mkPercentage = marketingCharges.getMkPercentage();
			Float taxOnMf = marketingCharges.getTaxOnMf();
			Double mkFee = CommonUtils.getMkfee(sellingPrice, mkPercentage);
			sellerProducts.setMarketingFee(mkFee);
			Double tax = mkFee * (taxOnMf / 100.00);

			if (hasFreeDelivery) {
				sellerProducts.setShippingCharges(0.0);
				Double logisticFee = null;
				LogisticFee logisticFees = logisticFeeService.getLogisticFee(Integer.parseInt(catalog.getWeightForFright())); // get logistic fee
																														
				if (logisticFees != null)
					logisticFee = logisticFees.getFee();
				else
					logisticFee = logisticFeeService.getMaxLogisticFee();
				sellerProducts.setLogisticFee(logisticFee);
				Double payableValue = CommonUtils.getPayableValue(sellingPrice, mkFee, tax, logisticFee);
				sellerProducts.setPayableValue(payableValue);
			} else {
				sellerProducts.setLogisticFee(0.0);
				sellerProducts.setShippingCharges(shippingCharges);
				Double payableValue = CommonUtils.getPayableValue(sellingPrice, mkFee, tax, new Double(0));
				sellerProducts.setPayableValue(payableValue);
			}
			sellerProductsDAO.save(sellerProducts);
			// save Image
			if(! imagesService.copyImage(catalog, seller))
				return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, "failed while adding Product.Please Try again");
			returnModel = new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS,Responses.SUCCESS_MSG);
			return returnModel;
		} catch (Exception e) {
			e.printStackTrace();
		}
		returnModel = new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS,"failed while adding SellerProduct.Please Try again");
		return returnModel;
	}

	@Override
	@Transactional
	public ResponseWrapper getAllSellerProducts() {
		try {
			ResponseWrapper returnModel = null;
			List<SellerProducts> sellerProducts = sellerProductsDAO.findAll();
			List<SellerProductsModel> sellerProductsModels = getSellerProductsModelList(sellerProducts);
			returnModel = new SellerProductResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_MSG,	Responses.SUCCESS_STATUS, sellerProductsModels);
			return returnModel;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}

/*	@Override
	@Transactional
	public ResponseWrapper updateSellerProduct(CatalogUpdate catalog) {

			ResponseWrapper returnModel = new ResponseWrapper();
		try {
			SellerProducts sellerProducts = sellerProductsDAO.findOne(Long.parseLong());
			Products products = sellerProducts.getProducts();
			if (sellerProducts == null)
				return new ResponseWrapper(Responses.FAILURE_CODE, Responses.ERROR_STATUS, "Invalid SellerProductId");

			sellerProducts.setUnits(Integer.parseInt(units));
			if (availableStatus .contentEquals("Active") || availableStatus.equalsIgnoreCase("InActive")){
				sellerProducts.setAvailableStatus(availableStatus);
				returnModel.setCode(Responses.SUCCESS_CODE);
				returnModel.setMessage("Seller Product Details Updated Successfully");
				returnModel.setStatus("status");	
			}else{
				sellerProducts.setAvailableStatus(availableStatus);
				returnModel.setCode(Responses.SUCCESS_CODE);
				returnModel.setMessage("Seller Product Details Updated Successfully");
				returnModel.setStatus(Responses.SUCCESS_STATUS);
			}
			sellerProducts.setModifyBy(BellakartConstants.USER_NAME);// TODO
			sellerProducts.setModifyDt(DateUtils.getCurrentDate());
			sellerProductsDAO.saveOrupdate(sellerProducts);
				
			} catch (Exception e) {
				returnModel = new ResponseWrapper(Responses.FAILURE_CODE, Responses.ERROR_STATUS,"Failed to update Product Details,Pleae Try again");
				e.printStackTrace();
			}
			return returnModel;
		
	}*/
	@Override
	@Transactional
	public ResponseWrapper updateStatus(String sellerProductId, String status){

			ResponseWrapper returnModel = new ResponseWrapper();
		try {
			SellerProducts sellerProducts = sellerProductsDAO.findOne(Long.parseLong(sellerProductId));
			//Products products = sellerProducts.getProducts();
			if (sellerProducts == null)
				return new ResponseWrapper(Responses.FAILURE_CODE, Responses.ERROR_STATUS, "Invalid SellerProductId");
			if (status.equalsIgnoreCase("active") || status.equalsIgnoreCase("inactive")){
				sellerProducts.setAvailableStatus(status);
				returnModel.setCode(Responses.SUCCESS_CODE);
				returnModel.setMessage("Seller Product Details Updated Successfully");
				returnModel.setStatus("status");	
				sellerProducts.setModifyBy(BibakartConstants.USER_NAME);// TODO
				sellerProducts.setModifyDt(DateUtils.getCurrentDate());
				sellerProductsDAO.saveOrupdate(sellerProducts);
			}else
				new ResponseWrapper(Responses.FAILURE_CODE, Responses.ERROR_STATUS,"Invalid Status Text");
		
			} catch (Exception e) {
				returnModel = new ResponseWrapper(Responses.FAILURE_CODE, Responses.ERROR_STATUS,"Failed to update Product Details,Pleae Try again");
				e.printStackTrace();
			}
			return returnModel;
		
	}
	@Override
	@Transactional
	public ResponseWrapper updateUnits(String sellerProductId, String units) {

			ResponseWrapper returnModel = new ResponseWrapper();
		try {
			SellerProducts sellerProducts = sellerProductsDAO.findOne(Long.parseLong(sellerProductId));
			//Products products = sellerProducts.getProducts();
			if (sellerProducts == null)
				return new ResponseWrapper(Responses.FAILURE_CODE, Responses.ERROR_STATUS, "Invalid SellerProductId");

				sellerProducts.setUnits(Integer.parseInt(units));
				returnModel.setCode(Responses.SUCCESS_CODE);
				returnModel.setMessage("Seller Product Details Updated Successfully");
				returnModel.setStatus("status");	
				sellerProducts.setModifyBy(BibakartConstants.USER_NAME);// TODO
				sellerProducts.setModifyDt(DateUtils.getCurrentDate());
				sellerProductsDAO.saveOrupdate(sellerProducts);
		
			} catch (Exception e) {
				returnModel = new ResponseWrapper(Responses.FAILURE_CODE, Responses.ERROR_STATUS,"Failed to update Product Details,Pleae Try again");
				e.printStackTrace();
			}
			return returnModel;
		
	}
	@Override
	@Transactional
	public ResponseWrapper updateSellingPrice(String sellerProductId, String sellingPrice) {
			ResponseWrapper returnModel = new ResponseWrapper();
		try {
			SellerProducts sellerProducts = sellerProductsDAO.findOne(Long.parseLong(sellerProductId));
			if (sellerProducts == null)
				return new ResponseWrapper(Responses.FAILURE_CODE, Responses.ERROR_STATUS, "Invalid SellerProductId");
			Products products = sellerProducts.getProducts();		
			//Double sp= sellerProducts.getSellingPrice();
			sellerProducts.setSellingPrice(Double.parseDouble(sellingPrice));
		
			Long id = products.getCategories().getCategoryId();
			MarketingCharges marketingCharges = marketingChargesDAO.findOne(id);
			Float mkPercentage = marketingCharges.getMkPercentage();
			Float taxOnMf = marketingCharges.getTaxOnMf();
			Double mkFee = CommonUtils.getMkfee(Double.parseDouble(sellingPrice), mkPercentage);
			sellerProducts.setMarketingFee(mkFee);
			Double tax = mkFee * (taxOnMf / 100.00);

			if (sellerProducts.isHasFreeDelivery()) {
				sellerProducts.setShippingCharges(0.0);
				Double logisticFee = null;
				LogisticFee logisticFees = logisticFeeService.getLogisticFee(sellerProducts.getWeightForFright()); // get logistic fee																													
				if (logisticFees != null)
					logisticFee = logisticFees.getFee();
				else
					logisticFee = logisticFeeService.getMaxLogisticFee();
				sellerProducts.setLogisticFee(logisticFee);
				Double payableValue = CommonUtils.getPayableValue(sellerProducts.getSellingPrice(), mkFee, tax, logisticFee);
				sellerProducts.setPayableValue(payableValue);
			} else {
				sellerProducts.setLogisticFee(0.0);
				sellerProducts.setShippingCharges(sellerProducts.getShippingCharges());
				Double payableValue = CommonUtils.getPayableValue(sellerProducts.getSellingPrice(), mkFee, tax, new Double(0));
				sellerProducts.setPayableValue(payableValue);
			}
			sellerProducts.setModifyBy(BibakartConstants.USER_NAME);// TODO
			sellerProducts.setModifyDt(DateUtils.getCurrentDate());
			
			sellerProductsDAO.saveOrupdate(sellerProducts);
				
			} catch (Exception e) {
				returnModel = new ResponseWrapper(Responses.FAILURE_CODE, Responses.ERROR_STATUS,"Failed to update Product Details,Pleae Try again");
				e.printStackTrace();
			}
			return returnModel;
		
	}
	
	@Override
	@Transactional
	public ResponseWrapper updateSellerProduct(SellerProductsModel sellerProduct,HttpSession session) {
			log.info(sellerProduct.toString());
			ResponseWrapper returnModel = new ResponseWrapper();
		try {
			Seller seller = (Seller)session.getAttribute("seller");
			SellerProducts sellerProducts = sellerProductsDAO.findOne(sellerProduct.getSellerProductId());
			if (sellerProducts == null)
				return new ResponseWrapper(Responses.FAILURE_CODE, Responses.ERROR_STATUS, "Invalid SellerProductId");
			//Double sp= sellerProducts.getSellingPrice();
			sellerProducts.setSellingPrice(sellerProduct.getSellingPrice());
			sellerProducts.setMrp(sellerProduct.getMrp());
			sellerProducts.setUnits(sellerProduct.getUnits());
			sellerProducts.setAvailableStatus(sellerProduct.getAvailableStatus());
			sellerProducts.setWarrantyType(sellerProduct.getWarrantyType());
			sellerProducts.setWarrantyServiceType(sellerProduct.getWarrantyServiceType());
			sellerProducts.setWeightForFright(sellerProduct.getWeightForFright());
			sellerProducts.setShippingCharges(sellerProduct.getShippingCharges());
			sellerProducts.setEstimatedShippingDays(sellerProduct.getEstimatedShippingDays());
			sellerProducts.setHasFreeDelivery(sellerProduct.getHasFreeDelivery());
			if(sellerProduct.getIsCodAllowed()!=null)
			sellerProducts.setIsCodAllowed(sellerProduct.getIsCodAllowed());
			if(sellerProduct.getSearchKeywords()!=null)
			sellerProducts.setSearchKeywords(sellerProduct.getSearchKeywords());
			sellerProducts.setAvailableStatus(sellerProduct.getAvailableStatus());
			sellerProducts.setModifyBy(seller.getSellerId());
			sellerProducts.setModifyDt(DateUtils.getCurrentDate());
			Products products =sellerProducts.getProducts();
			if (seller.getSellerId().equals(sellerProducts.getSellerMaster().getSellerId().toString())
					&& sellerProducts.getModeOfAddition().equalsIgnoreCase("individual")) {
				products.setProductTitle(sellerProduct.getProductTitle());
				products.setProductDesc(sellerProduct.getProductDesc());
				Brands  brands = products.getBrands();
				if(products.getBrands().getBrandName() != sellerProduct.getBrandName()){
					brands = brandsDAO.findOneByColumn("brandName", sellerProduct.getBrandName());
					if (brands == null){
						if(!createBrand(sellerProduct.getBrandName()))
						return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS,"problem occured while creating new brand");
						else{
							brands =brandsDAO.findOneByColumn("brandName", sellerProduct.getBrandName());
						}
					}
				}
				Categories categories = products.getCategories();
				if (categories.getCategoryId() != sellerProduct.getCategoryId()) {
					categories = categoriesDAO.findOne(sellerProduct.getCategoryId());
				}
	
				products.setCategories(categories);
				products.setBrands(brands);
				Set<ProductAttributes> productAttributes = products.getProductAttributes();
				for (ProductAttributes productAttribute : productAttributes) {
					Attributes attributes = productAttribute.getAttributes();
					switch (attributes.getAttributeName()) {
					case BibakartConstants.COMPOSITION:
						productAttribute.setValue(sellerProduct.getComposition());
						break;
					case BibakartConstants.COMPOSITION_TYPE:
						productAttribute.setValue(sellerProduct.getCompositionType());
						break;
					case BibakartConstants.APPLICATION_FREQUENCY:
						productAttribute.setValue(sellerProduct.getApplicationFrequency());
						break;
					case BibakartConstants.VIDEO_URL:
						productAttribute.setValue(sellerProduct.getVideoUrl());
						break;
					case BibakartConstants.TREATMENT_KIT:
						productAttribute.setValue(sellerProduct.getTreatmentKit());
						break;
					case BibakartConstants.TREATMENT_PERIOD:
						productAttribute.setValue(sellerProduct.getTreatmentPeriod());
						break;
					case BibakartConstants.IS_ORGANIC:
						productAttribute.setValue(sellerProduct.getIsOrganic());
						break;
					case BibakartConstants.SKIN_TYPE:
						productAttribute.setValue(sellerProduct.getSkinType());
						break;
					}

				}
			}
			Long id = products.getCategories().getCategoryId();
			MarketingCharges marketingCharges = marketingChargesDAO.findOne(id);
			Float mkPercentage = marketingCharges.getMkPercentage();
			Float taxOnMf = marketingCharges.getTaxOnMf();
			Double mkFee = CommonUtils.getMkfee(sellerProducts.getSellingPrice(), mkPercentage);
			sellerProducts.setMarketingFee(mkFee);
			Double tax = mkFee * (taxOnMf / 100.00);

			if (sellerProducts.isHasFreeDelivery()) {
				sellerProducts.setShippingCharges(0.0);
				Double logisticFee = null;
				LogisticFee logisticFees = logisticFeeService.getLogisticFee(sellerProducts.getWeightForFright()); // get logistic fee																													
				if (logisticFees != null)
					logisticFee = logisticFees.getFee();
				else
					logisticFee = logisticFeeService.getMaxLogisticFee();
				sellerProducts.setLogisticFee(logisticFee);
				Double payableValue = CommonUtils.getPayableValue(sellerProducts.getSellingPrice(), mkFee, tax, logisticFee);
				sellerProducts.setPayableValue(payableValue);
			} else {
				sellerProducts.setLogisticFee(0.0);
				sellerProducts.setShippingCharges(sellerProducts.getShippingCharges());
				Double payableValue = CommonUtils.getPayableValue(sellerProducts.getSellingPrice(), mkFee, tax, new Double(0));
				sellerProducts.setPayableValue(payableValue);
			}
			sellerProductsDAO.saveOrupdate(sellerProducts);
			returnModel.setCode(Responses.SUCCESS_CODE);
			returnModel.setMessage("Seller Product Details Updated Successfully");
			returnModel.setStatus(Responses.SUCCESS_STATUS);
		} catch (Exception e) {
			returnModel = new ResponseWrapper(Responses.FAILURE_CODE, Responses.ERROR_STATUS,"Failed to update Product Details,Pleae Try again");
			e.printStackTrace();

		}
			return returnModel;
		
	}
/*	public Boolean saveProductImage(Catalog catalog, Seller seller) {
		try {
			String rootFolder = PropertyReader.getInstance().getProperty("rootLocation");
			String source =	rootFolder + File.separator +"Profiles"+ File.separator + catalog.getSellerId()+File.separator +"Products"+File.separator+ catalog.getBaseSku()+ File.separator + catalog.getBaseSku() + "_" + "198X232" + ".jpg";
			String destination = rootFolder + File.separator +"Profiles"+ File.separator + catalog.getSellerId()+File.separator +"Products"+File.separator+ catalog.getBaseSku();
			byte[] image=imagesService.findSkuImage(catalog.getSellerId(), catalog.getBaseSku(), "198X232");
			File file = new File(source); 
			if(file.exists()){
			FileInputStream fis = new FileInputStream(file);
			FileOutputStream fos = new FileOutputStream(destination);
			byte[] buff = new byte[fis.available()];
			fis.read(buff);
			fos.write(buff); 
			}
			imagesService.saveSkuImage(seller.getSellerId(), catalog.getSkuId(), catalog.getFile());
			return true;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return false;
		}
	}*/
	@Override
	@Transactional
	public ResponseWrapper getSellerProductUsingId(String sellerProductId) {
		try {
			ResponseWrapper returnModel = null;
			SellerProducts sellerProducts = sellerProductsDAO.findOne(Long.parseLong(sellerProductId));
			if (sellerProducts == null)
				return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS,"No SellerProduct Found for the given Id");
			List<SellerProducts> sellerProductsList = new ArrayList<SellerProducts>();
			sellerProductsList.add(sellerProducts);
			List<SellerProductsModel> list = getSellerProductsModelList(sellerProductsList);
			returnModel = new SellerProductResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS,
					Responses.SUCCESS_MSG, list);
			return returnModel;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}

	@Override
	@Transactional
	public ResponseWrapper getSellerProductUsingskuId(String skuId) {
		try {
			ResponseWrapper returnModel = null;
			List<SellerProducts> slist = sellerProductsDAO.findAllByColumn("skuId", skuId);
			if (slist.size() > 0) {
				SellerProducts sellerProducts = slist.get(0);
				if (sellerProducts == null)
					return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS,"No SellerProduct Found for the given SKUId");
				List<SellerProducts> sellerProductsList = new ArrayList<SellerProducts>();
				sellerProductsList.add(sellerProducts);
				List<SellerProductsModel> list = getSellerProductsModelList(sellerProductsList);
				returnModel = new SellerProductResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_MSG,Responses.SUCCESS_STATUS, list);
				return returnModel;
			} else {
				return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS,	"No SellerProduct Found for the given SKUId");
			}
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}

	public List<SellerProductsModel> getSellerProductsModelList(List<SellerProducts> list) {
		try {
			List<SellerProductsModel> sellerProductsModelList = new ArrayList<SellerProductsModel>();
			for (SellerProducts sellerProducts : list) {
				SellerProductsModel sellerProductsModel = new SellerProductsModel();
				Products products = sellerProducts.getProducts();
				// Product Details
				sellerProductsModel.setProductDesc(products.getProductDesc());
				sellerProductsModel.setProductId(products.getProductId());
				sellerProductsModel.setProductID(CommonUtils.encryptText(products.getProductId().toString()));
				sellerProductsModel.setProductStatus(products.getStatus());
				sellerProductsModel.setCategoryId(products.getCategories().getCategoryId());
				sellerProductsModel.setParentCategoryId(products.getCategories().getParentCategoryId());
				Categories pc= categoriesDAO.findAllByColumn(BibakartConstants.CATEGORY_ID, products.getCategories().getParentCategoryId()).get(0);
				Categories mc= categoriesDAO.findAllByColumn(BibakartConstants.CATEGORY_ID, pc.getParentCategoryId()).get(0);
				sellerProductsModel.setMainCategoryId(mc.getCategoryId());
				sellerProductsModel.setCategoryName(products.getCategories().getCategoryName());
			/*	List<Categories> categories=categoriesDAO.findAllByColumn(BellakartConstants.CATEGORY_ID, products.getCategories().getCategoryId());
				List<CategoriesModel> cm= categoriesService.getCategoriesModelList(categories);
				sellerProductsModel.setCategories(cm);*/
				sellerProductsModel.setBrandId(products.getBrands().getBrandId());
				sellerProductsModel.setBrandName(products.getBrands().getBrandName());
				// Seller Product Details
				sellerProductsModel.setProductTitle(products.getProductTitle());
				sellerProductsModel.setSellerProductId(sellerProducts.getSellerProductId());
				sellerProductsModel.setSellerProductID(CommonUtils.encryptText(sellerProducts.getSellerProductId().toString()));
			
				sellerProductsModel.setSkuId(sellerProducts.getSkuId());
				sellerProductsModel.setSearchKeywords(sellerProducts.getSearchKeywords());
				sellerProductsModel.setMrp(sellerProducts.getMrp());
				sellerProductsModel.setSellingPrice(sellerProducts.getSellingPrice());
				sellerProductsModel.setPayableValue(sellerProducts.getPayableValue());
				sellerProductsModel.setIsCodAllowed(sellerProducts.isIsCodAllowed());
				sellerProductsModel.setWarrantyServiceType(sellerProducts.getWarrantyServiceType());
				sellerProductsModel.setWarrantyType(sellerProducts.getWarrantyType());
				sellerProductsModel.setWeightForFright(sellerProducts.getWeightForFright());
				sellerProductsModel.setUnits(sellerProducts.getUnits());
				sellerProductsModel.setHasFreeDelivery(sellerProducts.isHasFreeDelivery());
				sellerProductsModel.setEstimatedShippingDays(sellerProducts.getEstimatedShippingDays());
				sellerProductsModel.setShippingCharges(sellerProducts.getShippingCharges());
				sellerProductsModel.setApprovalStatus(sellerProducts.getApprovalStatus());
				sellerProductsModel.setAvailableStatus(sellerProducts.getAvailableStatus());
				//sellerProductsModel.setDateCreated(DateUtils.formatDate(sellerProducts.getCreatedDt().toString()));
				sellerProductsModel.setDateCreated(DateUtils.format(sellerProducts.getCreatedDt()));
				sellerProductsModel.setComments(sellerProducts.getComments());
				sellerProductsModel.setModeOfAddition(sellerProducts.getModeOfAddition());
				// SellerMaster Details
				SellerMaster sellerMaster = sellerProducts.getSellerMaster();
				sellerProductsModel.setBusinessName(sellerMaster.getBusinessName());
				sellerProductsModel.setEmailAddr(sellerMaster.getEmailAddr());
				sellerProductsModel.setMobile(sellerMaster.getMobile());
				sellerProductsModel.setStoreStatus(sellerMaster.getStoreStatus());
				sellerProductsModel.setPickupAddr(sellerMaster.getPickupAddr());
				sellerProductsModel.setStoreDisplayName(sellerMaster.getStoreDisplayName());
				sellerProductsModel.setSellerId(sellerMaster.getSellerId().toString());

				// Attributes
				Set<ProductAttributes> productAttributes = products.getProductAttributes();
				List<AttributesModel> attributesModels = new ArrayList<AttributesModel>();
				for (ProductAttributes productAttribute : productAttributes) {
					AttributesModel attributes = new AttributesModel();
					attributes.setAttributeName(productAttribute.getAttributes().getAttributeName());
					attributes.setAttributeValue(productAttribute.getValue());
					if(productAttribute.getAttributes().getAttributeName().equalsIgnoreCase(BibakartConstants.IS_ORGANIC))
					sellerProductsModel.setIsOrganic(productAttribute.getValue());
					else if (productAttribute.getAttributes().getAttributeName().equalsIgnoreCase(BibakartConstants.TREATMENT_KIT))
						sellerProductsModel.setTreatmentKit(productAttribute.getValue());	
					else if (productAttribute.getAttributes().getAttributeName().equalsIgnoreCase(BibakartConstants.TREATMENT_PERIOD))
						sellerProductsModel.setTreatmentPeriod(productAttribute.getValue());	
					else if (productAttribute.getAttributes().getAttributeName().equalsIgnoreCase(BibakartConstants.APPLICATION_FREQUENCY))
						sellerProductsModel.setApplicationFrequency(productAttribute.getValue());	
					else if (productAttribute.getAttributes().getAttributeName().equalsIgnoreCase(BibakartConstants.VIDEO_URL))
						sellerProductsModel.setVideoUrl(productAttribute.getValue());	
					else if (productAttribute.getAttributes().getAttributeName().equalsIgnoreCase(BibakartConstants.SKIN_TYPE))
						sellerProductsModel.setSkinType(productAttribute.getValue());	
					else if (productAttribute.getAttributes().getAttributeName().equalsIgnoreCase(BibakartConstants.COMPOSITION_TYPE))
						sellerProductsModel.setCompositionType(productAttribute.getValue());	
					else if (productAttribute.getAttributes().getAttributeName().equalsIgnoreCase(BibakartConstants.COMPOSITION))
						sellerProductsModel.setComposition(productAttribute.getValue());
					
					attributesModels.add(attributes);
				}
				sellerProductsModel.setAttributesModels(attributesModels);

				sellerProductsModelList.add(sellerProductsModel);
			}
			return sellerProductsModelList;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return null;
		}
	}

	@Override
	@Transactional
	public ResponseWrapper getSellerProductsUsingStatus(String column, String approvalstatus) {
		try {
			ResponseWrapper returnModel = null;
			List<SellerProducts> sellerProducts = sellerProductsDAO.findAllByColumn(column, approvalstatus);
			List<SellerProductsModel> sellerProductsModel = getSellerProductsModelList(sellerProducts);
			returnModel = new SellerProductResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_MSG,	Responses.SUCCESS_STATUS, sellerProductsModel);
			return returnModel;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}

	@Override
	public ResponseWrapper updateSellerProductApprovalStatus(StatusModel status) {
		ResponseWrapper returnModel = null;
		try {
			SellerProducts sp = sellerProductsDAO.findOne(Long.parseLong(status.getSpId()));
			if (sp == null)
				return new ResponseWrapper(Responses.FAILURE_CODE, Responses.ERROR_STATUS, "Invalid SellerProductId");
			
			sp.setApprovalStatus(status.getStatus());
			sp.setModifyBy(BibakartConstants.USER_NAME);// TODO
			sp.setModifyDt(DateUtils.getCurrentDate());
			String comments= null;
			if(status.getStatus().equalsIgnoreCase("requestApproval")){
				 comments=sp.getComments();
				if(comments!= null)
					comments =comments+"/n"+DateUtils.getCurrentStringTime()+"-"+status.getComments();
				else
				comments = status.getComments();
				sp.setComments(comments);
			}
			sellerProductsDAO.saveOrupdate(sp);
			returnModel = new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS,"Seller Product Details Updated Successfully");
		} catch (Exception e) {
			returnModel = new ResponseWrapper(Responses.FAILURE_CODE, Responses.ERROR_STATUS,	"Failed to update Product Details,Pleae Try again");
			e.printStackTrace();
		}
		return returnModel;
	}

	@Override
	public ResponseWrapper updateSellerProductAvailableStatus(String sellerProductId, String availableStatus) {
		ResponseWrapper returnModel = null;
		try {
			SellerProducts sp = sellerProductsDAO.findOne(Long.parseLong(sellerProductId));
			if (sp == null)
				return new ResponseWrapper(Responses.FAILURE_CODE, Responses.ERROR_STATUS, "Invalid SellerProductId");
		
			sp.setAvailableStatus(availableStatus);
			sp.setModifyBy(BibakartConstants.USER_NAME);// TODO
			sp.setModifyDt(DateUtils.getCurrentDate());
			sellerProductsDAO.saveOrupdate(sp);
			returnModel = new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS,"Seller Product Details Updated Successfully");
		} catch (Exception e) {
			returnModel = new ResponseWrapper(Responses.FAILURE_CODE, Responses.ERROR_STATUS,	"Failed to update Product Details,Pleae Try again");
			e.printStackTrace();
		}
		return returnModel;
	}
	@Override
	public ResponseWrapper validateSkuId(String skuId) {
		try {
			ResponseWrapper returnModel = null;
			List<SellerProducts> list = sellerProductsDAO.findAllByColumn(BibakartConstants.SKU_ID, skuId);
			if (list.size() > 0)
				returnModel = new ResponseWrapper(Responses.FAILURE_CODE, Responses.ERROR_STATUS,	"skuId already exists");
			else
				returnModel = new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS, "Valid SkuId");
			return returnModel;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}

	@Override
	@Transactional
	public ResponseWrapper getSellerProducts(String column, String availableStatus) {
		try {
			ResponseWrapper returnModel = null;
			List<SellerProducts> sellerProducts = sellerProductsDAO.findAllByColumn(column,	Integer.parseInt(availableStatus));
			List<SellerProductsModel> sellerProductsModel = getSellerProductsModelList(sellerProducts);
			returnModel = new SellerProductResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_MSG,	Responses.SUCCESS_STATUS, sellerProductsModel);
			return returnModel;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}

	@Override
	@Transactional
	public ResponseWrapper getSellerProductsusingStock(String column, String stock) {
		try {
			ResponseWrapper returnModel = null;
			List<SellerProducts> sellerProducts = null;
			if (stock.equals("is"))
				sellerProducts = sellerProductsDAO.findAllByString(" units > 0");
			else
				sellerProducts = sellerProductsDAO.findAllByString(" units = 0");
			List<SellerProductsModel> sellerProductsModel = getSellerProductsModelList(sellerProducts);
			returnModel = new SellerProductResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_MSG,	Responses.SUCCESS_STATUS, sellerProductsModel);
			return returnModel;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}

	@Override
	public ResponseWrapper deleteSellerProducts(String sellerProductId) {
		ResponseWrapper returnModel = null;
		try {
			//sellerProductsDAO.deleteById(Long.parseLong(sellerProductId));
			sellerProductsDAO.findOne(Long.parseLong(sellerProductId)).setAvailableStatus(BibakartConstants.STATUS_OBSELETE);;
			returnModel = new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS,Responses.SUCCESS_MSG);
		} catch (Exception e) {
			returnModel = new ResponseWrapper(Responses.FAILURE_CODE, Responses.ERROR_STATUS,	"Problem occured while deleting product");
			e.printStackTrace();
		}
		return returnModel;
	}

	@Override
	@Transactional
	public ResponseWrapper getSellerProductsUsingSeller(String sellerId) {
		try {
			ResponseWrapper returnModel = null;
			List<SellerProducts> sellerProducts = sellerProductsDAO.findAllByColumn("sellerMaster", sellerId);
			List<SellerProductsModel> sellerProductsModel = getSellerProductsModelList(sellerProducts);
			returnModel = new SellerProductResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_MSG,	Responses.SUCCESS_STATUS, sellerProductsModel);
			return returnModel;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}
	@Override
	@Transactional
	public ResponseWrapper getSellerProductsUsingSeller(String sellerId,String status,String stock,int offset,int maxResults) {
		try {
			SellerProductResponseWrapper returnModel = new SellerProductResponseWrapper();
			List<SellerProducts> sellerProducts = null;
			log.info("Status "+status +"-- Stock"+stock);
			if(status !=null && !status.isEmpty() && !status.equalsIgnoreCase("all")){// returns all Products
				sellerProducts = sellerProductsDAO.findAllByColumn("sellerMaster", sellerId, "available_status", status, offset, maxResults);
				returnModel.setTotalProducts(sellerProductsDAO.getCount(" where sellerMaster ='"+sellerId+"' and availableStatus = '"+status+"'"));
				
			} 
			else if (status !=null && !status.isEmpty() && status.equalsIgnoreCase("all")){ // returns active/anActive products 
				sellerProducts = sellerProductsDAO.findAllByColumnNotEqual("sellerMaster", sellerId,"availableStatus","obsolete",offset,maxResults);
				returnModel.setTotalProducts(sellerProductsDAO.getCount(" where sellerMaster ='"+sellerId+"' and availableStatus != 'obsolete'"));
			}
			else if(stock != null && !stock.isEmpty() && stock.equalsIgnoreCase("inStock")){ // returns instock products
				sellerProducts = sellerProductsDAO.findAllByString("sellerMaster = '"+sellerId+"' and units >0 and availableStatus != 'obsolete'",offset,maxResults);
				returnModel.setTotalProducts(sellerProductsDAO.getCount(" where sellerMaster ='"+sellerId+"' and units >0 and availableStatus != 'obsolete'"));
			}
			else if(stock !=null && !stock.isEmpty() && stock.equalsIgnoreCase("outofStock")){ // returns outofStock products
				sellerProducts = sellerProductsDAO.findAllByString("sellerMaster = '"+sellerId+"' and units =0 and availableStatus != 'obsolete'",offset,maxResults);
				returnModel.setTotalProducts(sellerProductsDAO.getCount(" where sellerMaster ='"+sellerId+"' and units =0 and availableStatus != 'obsolete'"));
			}
			List<SellerProductsModel> sellerProductsModel = getSellerProductsModelList(sellerProducts);
			returnModel.setCode(Responses.SUCCESS_CODE);
			returnModel.setMessage(Responses.SUCCESS_MSG);
			returnModel.setStatus(Responses.SUCCESS_STATUS);
			returnModel.setSellerProducts(sellerProductsModel);
			return returnModel;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}
	public boolean createBrand(String brandID) {
		try {
			Brand b = new Brand();
			b.setBrandName(brandID);
			b.setBrandDesc(brandID);
			b.setStatus("1");
			if (brandsService.addNewBrand(b).getCode() == 200)
				return true;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public ResponseWrapper getSellerProducts(int productId, long sellerId) {
		SellerProductResponseWrapper response = new SellerProductResponseWrapper();
		try {
				List<SellerProducts> sp = sellerProductsDAO.findAllByColumn("sellerMaster", sellerId, "products", productId, "and");
				
				List<SellerProductsModel> sellerProductsModel = getSellerProductsModelList(sp);
				response.setCode(Responses.SUCCESS_CODE);
				response.setSellerProducts(sellerProductsModel);
				return response;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return response;
	}

	@Override
	public ResponseWrapper getAllSellerProducts(String status, int offset, int maxResults) {
		try{
		SellerProductResponseWrapper returnModel = new SellerProductResponseWrapper();
		List<SellerProducts> sellerProducts = null;
		if(status !=null && !status.isEmpty() && !status.equalsIgnoreCase("all")){// returns all Products
			sellerProducts = sellerProductsDAO.findAllByColumnNotEqual("approval_status", status,"availableStatus","obsolete", offset, maxResults);
			returnModel.setTotalProducts(sellerProductsDAO.getCount(" where approvalStatus = '"+status+"' and availableStatus != 'obsolete'"));
		} 
		else if (status !=null && !status.isEmpty() && status.equalsIgnoreCase("all")){ // returns active/anActive products 
			sellerProducts = sellerProductsDAO.findAllByLimitNotEqColumn("availableStatus","obsolete",offset, maxResults);
			returnModel.setTotalProducts(sellerProductsDAO.getCount(" where availableStatus != 'obsolete'"));
		}
		List<SellerProductsModel> sellerProductsModel = getSellerProductsModelList(sellerProducts);
		returnModel.setCode(Responses.SUCCESS_CODE);
		returnModel.setMessage(Responses.SUCCESS_MSG);
		returnModel.setStatus(Responses.SUCCESS_STATUS);
		returnModel.setSellerProducts(sellerProductsModel);
		return returnModel;
	} catch (Exception e) {
		// TODO
		e.printStackTrace();
		return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
	}
	}

}
