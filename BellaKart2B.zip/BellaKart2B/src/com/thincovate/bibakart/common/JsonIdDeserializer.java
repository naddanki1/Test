package com.thincovate.bibakart.common;

import java.io.IOException;

import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.DeserializationContext;
import org.codehaus.jackson.map.JsonDeserializer;

import com.thincovate.bibakart.common.utils.CommonUtils;

public class JsonIdDeserializer extends JsonDeserializer<String>{

	@Override
	public String deserialize(JsonParser jsonparser, DeserializationContext arg1)
			throws IOException, JsonProcessingException {
		
		return CommonUtils.decryptText(jsonparser.getText());
	}

	
}
