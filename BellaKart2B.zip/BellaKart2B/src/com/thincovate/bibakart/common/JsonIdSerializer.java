package com.thincovate.bibakart.common;

import java.io.IOException;

import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.JsonSerializer;
import org.codehaus.jackson.map.SerializerProvider;

import com.thincovate.bibakart.common.utils.CommonUtils;

public class JsonIdSerializer extends JsonSerializer<String>{

	@Override
	public void serialize(String arg0, JsonGenerator arg1, SerializerProvider arg2)
			throws IOException, JsonProcessingException {
		arg1.writeString(CommonUtils.encryptText(arg0));
		
	}

}
