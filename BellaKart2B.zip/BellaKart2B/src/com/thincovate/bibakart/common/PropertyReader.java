/**
 * 
 */
package com.thincovate.bibakart.common;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;

/**
 * @author Sandeep
 *
 */
public class PropertyReader {

	private static PropertyReader instance;
	private static Properties properties = new Properties();
	static Logger log = Logger.getLogger(PropertyReader.class);

	private PropertyReader() throws IOException {
		properties = new Properties();
		InputStream input = null;
		try {
			input = new FileInputStream("application.properties");
			properties.load(input);
		} catch (IOException e) {
			input = PropertyReader.class.getClassLoader().getResourceAsStream("application.properties");
			// log.info(input);
			try {
				properties.load(input);
			} catch (IOException ioe) {
				log.error("Error loading properties file");
				ioe.printStackTrace();
				throw ioe;
			}
			System.out.println("test");
		}
	}

	public static PropertyReader getInstance() throws IOException {
		if (instance == null)
			instance = new PropertyReader();
		return instance;
	}

	public String getProperty(String key) {
		String value = properties.getProperty(key);
		if (value == null)
			return null;
		else
			return value;
	}

}
