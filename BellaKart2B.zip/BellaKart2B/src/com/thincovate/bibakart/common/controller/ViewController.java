package com.thincovate.bibakart.common.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.thincovate.bibakart.admin.model.SellerDetails;
import com.thincovate.bibakart.admin.services.SellerDetailsService;
import com.thincovate.bibakart.catalog.dao.SellerProductsDAO;
import com.thincovate.bibakart.catalog.services.SellerProductsService;
import com.thincovate.bibakart.common.model.ResponseWrapper;
import com.thincovate.bibakart.common.utils.BibakartConstants;
import com.thincovate.bibakart.common.utils.BibakartRoles;
import com.thincovate.bibakart.common.utils.CommonUtils;
import com.thincovate.bibakart.common.utils.PathConstants;
import com.thincovate.bibakart.entitymodels.BankDetails;
import com.thincovate.bibakart.entitymodels.ProspectiveSellers;
import com.thincovate.bibakart.orders.dao.OrdersMasterDAO;
import com.thincovate.bibakart.registration.services.BankDetailsService;
import com.thincovate.bibakart.sessionmgnt.model.Seller;
import com.thincovate.bibakart.sessionmgnt.services.SessionMngtService;
import com.thincovate.bibakart.sessionmgnt.services.impl.User;


@Controller
@RequestMapping("/")
public class ViewController {

	@Autowired
	private SellerProductsService sellerProductsService;

	@Autowired
	private SessionMngtService sessionMngtService;
	
	@Autowired
	private SellerDetailsService sellerDetailsService;
	
	@Autowired
	private BankDetailsService bankDetailsService;
	
	@Autowired
	private SellerProductsDAO sellerProductsDAO;
	
	@Autowired
	private OrdersMasterDAO ordersMasterDAO;

	static Logger log = Logger.getLogger(ViewController.class);

	@RequestMapping(value = "/" + PathConstants.LOGIN, method = RequestMethod.GET)
	public String reg1(HttpServletRequest request, ModelMap model) {
		
		HttpSession session = request.getSession();
		Seller seller = (Seller) session.getAttribute("seller");
		if (seller == null ){
			session.setAttribute("path","catalog");
			return PathConstants.LOGIN;
		}
		else {
			if (sessionMngtService.isValidSession(request,true,seller.getEmailAddr(),BibakartRoles.VENDOR))
				return "redirect:/catalog";
			else {
				model.addAttribute("ps", new ProspectiveSellers());
				session.setAttribute("path","catalog");
				return PathConstants.LOGIN;
			}
		}		
	}

	@RequestMapping(value = { "/catalog" }, method = RequestMethod.GET)
	public String catalog(HttpServletRequest request, ModelMap model) {

		HttpSession session = request.getSession();
		Seller seller =(Seller) session.getAttribute("seller");
		if(seller == null){
			session.setAttribute("path","catalog");
			return PathConstants.LOGIN;
		}
		else{	
		if (sessionMngtService.isValidSession(request, true, seller.getEmailAddr(), BibakartRoles.VENDOR)){
				if(!(seller.getSellerStatus().equalsIgnoreCase("new") || seller.getSellerStatus().equalsIgnoreCase("pending"))){
					session.setAttribute("totalProducts",sellerProductsDAO.getCount(" where sellerMaster ='"+seller.getSellerId()+"' and availableStatus != 'obsolete'"));
					session.setAttribute("totalActiveProducts", sellerProductsDAO.getCount(" where sellerMaster ='"+seller.getSellerId()+"' and availableStatus = 'active'"));
					session.setAttribute("totalInActiveProducts", sellerProductsDAO.getCount(" where sellerMaster ='"+seller.getSellerId()+"' and availableStatus = 'inActive'"));
					session.setAttribute("totalInStockProducts", sellerProductsDAO.getCount(" where sellerMaster ='"+seller.getSellerId()+"' and units >0 and availableStatus != 'obsolete'" ));
					session.setAttribute("totalOutOfStockProducts", sellerProductsDAO.getCount(" where sellerMaster ='"+seller.getSellerId()+"' and units =0 and availableStatus != 'obsolete'"));
					return "catalog";
				}else
					return "redirect:/vendor/profile";
			}
		else{
			session.setAttribute("path","catalog");
			return PathConstants.LOGIN;
			}
		}
	}

	@RequestMapping(value = { "/addCatalog" }, method = RequestMethod.GET)
	public String addCatalog(HttpServletRequest request, ModelMap model) {
		
		HttpSession session = request.getSession();
		Seller seller =(Seller) session.getAttribute("seller");
		if(seller == null){
			session.setAttribute("path","addCatalog");
			return PathConstants.LOGIN;
		}
		else{	
			if (sessionMngtService.isValidSession(request, true, seller.getEmailAddr(), BibakartRoles.VENDOR)){
				if(!(seller.getSellerStatus().equalsIgnoreCase("new") || seller.getSellerStatus().equalsIgnoreCase("pending")))
					return "addCatalog";
				else
					return "redirect:/vendor/profile";
			}
		else{
			session.setAttribute("path","addCatalog");
			return PathConstants.LOGIN;
			}
		}
	}
	
	@RequestMapping(value = { "/addBulkCatalog" }, method = RequestMethod.GET)
	public String addBulkCatalog(HttpServletRequest request, ModelMap model) {
		
		HttpSession session = request.getSession();
		Seller seller =(Seller) session.getAttribute("seller");
		if(seller == null){
			session.setAttribute("path","addBulkCatalog");
			return PathConstants.LOGIN;
		}
		else{	
			if (sessionMngtService.isValidSession(request, true, seller.getEmailAddr(), BibakartRoles.VENDOR)){
				if(!(seller.getSellerStatus().equalsIgnoreCase("new") || seller.getSellerStatus().equalsIgnoreCase("pending")))
					return "bulkUpload";
				else
					return "redirect:/vendor/profile";
			}
		else{
			session.setAttribute("path","addBulkCatalog");
			return PathConstants.LOGIN;
			}
		}
	}

	@RequestMapping(value = { "/addCatalogBySearch" }, method = RequestMethod.GET)
	public String addCatalog2(@RequestParam(value = "spId") String sellerProductId,	HttpServletRequest request, ModelMap model) {
		
		HttpSession session = request.getSession();
		Seller seller =(Seller) session.getAttribute("seller");
		if(seller == null){
			session.setAttribute("path","addCatalogBySearch");
			return PathConstants.LOGIN;
		}
		else{
			if (sessionMngtService.isValidSession(request, true, seller.getEmailAddr(), BibakartRoles.VENDOR)){
				if(!(seller.getSellerStatus().equalsIgnoreCase("new") || seller.getSellerStatus().equalsIgnoreCase("pending"))){
					ResponseWrapper result = sellerProductsService.getSellerProductUsingId(CommonUtils.decryptText(sellerProductId));
				model.addAttribute("result", result);
				return "addCatalogBySearch";
				}
				else
					return "redirect:/vendor/profile";
			}
		else{
			session.setAttribute("path","addCatalogBySearch");
			return PathConstants.LOGIN;
			}
		}	
	}

	@RequestMapping(value = { "/searchCatalog" }, method = RequestMethod.GET)
	public String searchCatalog(HttpServletRequest request, ModelMap model) {
		
		HttpSession session = request.getSession();
		Seller seller =(Seller) session.getAttribute("seller");
		if(seller == null){
			session.setAttribute("path","searchCatalog");
			return PathConstants.LOGIN;
		}
		else{		
			if (sessionMngtService.isValidSession(request, true, seller.getEmailAddr(), BibakartRoles.VENDOR)){
				if(!(seller.getSellerStatus().equalsIgnoreCase("new") || seller.getSellerStatus().equalsIgnoreCase("pending")))
					return "searchCatalog";
				else
					return "redirect:/vendor/profile";
			}
		else{
			session.setAttribute("path","searchCatalog");
			return PathConstants.LOGIN;
			}
		}	
	}

	@RequestMapping(value = { "/help/downloads" }, method = RequestMethod.GET)
	public String download(HttpServletRequest request, ModelMap model) {
		HttpSession session = request.getSession();
		Seller seller =(Seller) session.getAttribute("seller");
		if(seller == null){
			session.setAttribute("path","help/downloads");
			return PathConstants.LOGIN;
		}
		else{
			
			if (sessionMngtService.isValidSession(request, true, seller.getEmailAddr(), BibakartRoles.VENDOR)){
				if(!(seller.getSellerStatus().equalsIgnoreCase("new") || seller.getSellerStatus().equalsIgnoreCase("pending")))
					return "downloads";
				else
					return "redirect:/vendor/profile";
			}
		else{
			session.setAttribute("path","help/downloads");
			return PathConstants.LOGIN;
			}
		}
	}

	@RequestMapping(value = "/resetpswd", method = RequestMethod.GET)
	public String resetPwd(HttpServletRequest request, ModelMap model) {

		HttpSession session = request.getSession();
		Seller seller = (Seller) session.getAttribute("seller");
		String uname = (String) session.getAttribute("userName");
		if (uname != null) {
			return "resetPwd";
		} else if (seller != null) {
			if (sessionMngtService.isValidSession(request, true, seller.getEmailAddr(), BibakartRoles.VENDOR))
				return "redirect:/catalog";
		}
		return PathConstants.LOGIN;
	}
	
	@RequestMapping(value = "/vendor/profile", method = RequestMethod.GET)
	public String viewProfile(HttpServletRequest request) {

		HttpSession session = request.getSession();
		Seller seller = (Seller) session.getAttribute("seller");
		if (seller == null){
			session.setAttribute("path","vendor/profile");
			return PathConstants.LOGIN;
		}
		else if ((sessionMngtService.isValidSession(request, true, seller.getEmailAddr(), BibakartRoles.VENDOR))&& (seller.getRegStatus().equalsIgnoreCase("finish"))) {
			SellerDetails sellerDetails = sellerDetailsService.getSellerUsingId(seller.getSellerId()).get(0);
			List<BankDetails> listBank=bankDetailsService.findAll();
			session.setAttribute("listBank", listBank);
			session.setAttribute("sellerDetails", sellerDetails);
			return "vendorProfile";
		} else{
			session.invalidate();
			HttpSession hsession =request.getSession();
			hsession.setAttribute("path","vendor/profile");
			return  PathConstants.LOGIN;
		}
	}
	@RequestMapping(value = { "/view/orders" }, method = RequestMethod.GET)
	public String orders(HttpServletRequest request, ModelMap model) {
		HttpSession session = request.getSession();
		Seller seller =(Seller) session.getAttribute("seller");
		if(seller == null){
			session.setAttribute("path","view/orders");
			return PathConstants.LOGIN;
		}
		else{		
			if (sessionMngtService.isValidSession(request, true, seller.getEmailAddr(), BibakartRoles.VENDOR)){
				if(!(seller.getSellerStatus().equalsIgnoreCase("new") || seller.getSellerStatus().equalsIgnoreCase("pending")))
					return "orders";
				else
					return "redirect:/vendor/profile";
			}else{
			session.setAttribute("path","view/orders");
			return PathConstants.LOGIN;
			}
		}
	}
	@RequestMapping(value = { "/view/payments" }, method = RequestMethod.GET)
	public String payments(HttpServletRequest request, ModelMap model) {
		HttpSession session = request.getSession();
		Seller seller =(Seller) session.getAttribute("seller");
		if(seller == null){
			session.setAttribute("path","view/payments");
			return PathConstants.LOGIN;
		}
		else{		
			if (sessionMngtService.isValidSession(request, true, seller.getEmailAddr(), BibakartRoles.VENDOR)){
				if(!(seller.getSellerStatus().equalsIgnoreCase("new") || seller.getSellerStatus().equalsIgnoreCase("pending")))
					return "payments";
				else
					return "redirect:/vendor/profile";
			}else{
			session.setAttribute("path","view/payments");
			return PathConstants.LOGIN;
			}
		}
	}
	@RequestMapping(value = "/error", method = RequestMethod.GET)
	public String error(HttpServletRequest request, ModelMap model) {

		return "error";
	}

	@RequestMapping(value = "/admin/login", method = RequestMethod.GET)
	public String adminLogin(HttpServletRequest request) {
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		if (user == null) {
			session.setAttribute("path", "admin/sellers");
			return "adminLogin";
		} else {
			return "sellers";
		}
	}

	@RequestMapping(value = "/admin/sellers", method = RequestMethod.GET)
	public String sellers(HttpServletRequest request) {
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		if (user == null) {
			session.setAttribute("path", "admin/sellers");
			return "adminLogin";
		} else {
			return "sellers";
		}

	}
	@RequestMapping(value = "/admin/catalog", method = RequestMethod.GET)
	public String adminCatalog(HttpServletRequest request) {
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		if (user == null) {
			session.setAttribute("path", "admin/catalog");
			return "adminLogin";
		} else {
			session.setAttribute("totalProducts",sellerProductsDAO.getCount(" where availableStatus != 'obsolete'"));
			return "catalogAdmin";
		}

	}
	@RequestMapping(value = "/admin/orders", method = RequestMethod.GET)
	public String adminOrders(HttpServletRequest request) {
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		if (user == null) {
			session.setAttribute("path", "admin/orders");
			return "adminLogin";
		} else {
			session.setAttribute("totalOrders", ordersMasterDAO.getCount(""));
			return "ordersAdmin";
		}
	}
	@RequestMapping(value = "/admin/payments", method = RequestMethod.GET)
	public String adminPayments(HttpServletRequest request) {
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		if (user == null) {
			session.setAttribute("path", "admin/payments");
			return "adminLogin";
		} else {
			session.setAttribute("totalOrders", ordersMasterDAO.getCount(""));
			return "paymentsAdmin";
		}

	}
	@RequestMapping(value = "/dummyOrders", method = RequestMethod.GET)
	public String orders(){
		return "dummyOrders";
	}

}