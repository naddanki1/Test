package com.thincovate.bibakart.common.exceptions;

import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.NoHandlerFoundException;

/**
 * Performs the same exception handling as {@link ExceptionHandlingController}
 * but offers them globally. The exceptions below could be raised by any
 * controller and they would be handled here, if not handled in the controller
 * already.
 * 
 * @author Rajani
 */
@ControllerAdvice
public class GlobalExceptionHandlingControllerAdvice {

	static Logger logger = Logger.getLogger(GlobalExceptionHandlingControllerAdvice.class);

	/*
	 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	 */
	/*
	 * . . . . . . . . . . . . . EXCEPTION HANDLERS . . . . . . . . . . . . . .
	 */
	/*
	 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	 */

	/**
	 * Convert a predefined exception to an HTTP Status code
	 */
	@ResponseStatus(value = HttpStatus.CONFLICT, reason = "Data integrity violation")
	// 409
	@ExceptionHandler(DataIntegrityViolationException.class)
	public void conflict(Exception exception) {
		logger.error("Request raised a DataIntegrityViolationException: " + exception.getMessage());
		// Nothing to do
	}

	/**
	 * Convert a predefined exception to an HTTP Status code and specify the
	 * name of a specific view that will be used to display the error.
	 * 
	 * @return Exception view.
	 */
	@ExceptionHandler({ SQLException.class, DataAccessException.class })
	public String databaseError(Exception exception) {
		// Nothing to do. Return value 'databaseError' used as logical view name
		// of an error page, passed to view-resolver(s) in usual way.
		logger.error("Exception Caught : " + exception.getClass().getSimpleName() + exception.getMessage());

		return "databaseError";
	}

	@ExceptionHandler(NoHandlerFoundException.class)
	public ModelAndView noHandlerFound(NoHandlerFoundException e) {
		
		logger.info("Resourcr Not Found :" + e.getMessage());
		ModelAndView mv = new ModelAndView("resouceNotFound");

		return mv;
	}

	@ExceptionHandler(HttpRequestMethodNotSupportedException.class)
	public ModelAndView methodNotSupported(){

		ModelAndView mv = new ModelAndView("resouceNotFound");
		mv.addObject("msg", "Methd not supported");
		return mv;
	}
}