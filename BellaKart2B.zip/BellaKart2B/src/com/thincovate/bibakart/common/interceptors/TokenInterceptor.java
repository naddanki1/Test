package com.thincovate.bibakart.common.interceptors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.thincovate.bibakart.common.model.ResponseWrapper;
import com.thincovate.bibakart.common.utils.Responses;
import com.thincovate.bibakart.sessionmgnt.services.SessionMngtService;

/**
 * @author Venkat
 *
 */
public class TokenInterceptor extends HandlerInterceptorAdapter {

	private static Logger logger = Logger.getLogger(TokenInterceptor.class);
	private SessionMngtService sessionMgntService;

	public SessionMngtService getSessionMgntService() {
		return sessionMgntService;
	}

	public void setSessionMgntService(SessionMngtService sessionMgntService) {
		this.sessionMgntService = sessionMgntService;
	}

	public TokenInterceptor(SessionMngtService sessionMgntService) {
		this.sessionMgntService = sessionMgntService;
	}

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
	
		logger.info("------------------  in Pre Handle ---------------" + request.getRequestURI());
			return true;
	/*	if (sessionMgntService.isValidSession(request))
				return true;
		else {
			response.addHeader("response", "Invalid Session,Please Login !");
			ResponseWrapper json = new ResponseWrapper();
			json.setMessage(Responses.INVALID_SESSION_MESSAGE);
			json.setCode(Responses.INVALID_SESSION_CODE);
			ObjectMapper mapperObj = new ObjectMapper();
			String jsonStr = mapperObj.writeValueAsString(json);
			logger.info("Response " + jsonStr);
			response.setContentType("application/json");
			response.setCharacterEncoding("UTF-8");
			response.getWriter().print(jsonStr);
			return false;
		}*/
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,ModelAndView modelAndView) throws Exception {
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)	throws Exception {
	}
}
