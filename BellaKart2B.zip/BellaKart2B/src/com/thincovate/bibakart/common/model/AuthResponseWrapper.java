/**
 * 
 */
package com.thincovate.bibakart.common.model;

import com.thincovate.bibakart.sessionmgnt.model.Seller;
import com.thincovate.bibakart.sessionmgnt.services.impl.User;

/**
 * @author Sandeep
 *
 */
public class AuthResponseWrapper extends ResponseWrapper {

	private User user;
	private Seller seller;

	public AuthResponseWrapper() {
	}

	public AuthResponseWrapper(Integer code, String message, String status) {
		super(code, status, message);

	}

	public AuthResponseWrapper(Integer code, String message, String status, User user) {
		super(code, status, message);
		this.user = user;

	}

	public AuthResponseWrapper(Integer code, String message, String status, Seller seller) {
		super(code, status, message);
		this.seller = seller;

	}

	/**
	 * @return the user
	 */
	public User getUser() {
		return user;
	}

	/**
	 * @param user
	 *            the user to set
	 */
	public void setUser(User user) {
		this.user = user;
	}

	public Seller getSeller() {
		return seller;
	}

	public void setSeller(Seller seller) {
		this.seller = seller;
	}

}
