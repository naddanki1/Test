package com.thincovate.bibakart.common.model;

import java.util.ArrayList;
import java.util.List;

import com.thincovate.bibakart.admin.model.BrandsModel;

public class BrandResponseWrapper extends ResponseWrapper {

	private List<BrandsModel> brands = new ArrayList<BrandsModel>();

	public BrandResponseWrapper() {

	}

	public BrandResponseWrapper(Integer code, String message, String status, List<BrandsModel> brands) {
		super(code, status, message);
		this.brands = brands;
	}

	public List<BrandsModel> getBrands() {
		return brands;
	}

	public void setBrands(List<BrandsModel> brands) {
		this.brands = brands;
	}

}
