package com.thincovate.bibakart.common.model;

import java.util.ArrayList;
import java.util.List;

import com.thincovate.bibakart.admin.model.CategoriesModel;

public class CategoryResponseWrapper extends ResponseWrapper {

	private List<CategoriesModel> categories = new ArrayList<CategoriesModel>();

	public CategoryResponseWrapper() {

	}

	public CategoryResponseWrapper(Integer code, String message, String status, List<CategoriesModel> categories) {
		super(code, status, message);
		this.categories = categories;
	}

	public List<CategoriesModel> getCategories() {
		return categories;
	}

	public void setCategories(List<CategoriesModel> categories) {
		this.categories = categories;
	}


}
