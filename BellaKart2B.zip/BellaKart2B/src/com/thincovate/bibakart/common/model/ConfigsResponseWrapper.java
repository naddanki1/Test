package com.thincovate.bibakart.common.model;

import java.util.ArrayList;
import java.util.List;

import com.thincovate.bibakart.configs.vo.Configuration;

public class ConfigsResponseWrapper extends ResponseWrapper {

	public ConfigsResponseWrapper() {

	}

	List<Configuration> configs = new ArrayList<Configuration>();

	public List<Configuration> getConfigs() {
		return configs;
	}

	public void setConfigs(List<Configuration> configs) {
		this.configs = configs;
	}

}
