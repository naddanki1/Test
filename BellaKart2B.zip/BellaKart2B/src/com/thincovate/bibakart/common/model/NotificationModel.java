package com.thincovate.bibakart.common.model;

import java.util.ArrayList;

public class NotificationModel {

	public ArrayList<String> errors;
	public ArrayList<String> success;
	public ArrayList<String> warnings;
	public ArrayList<String> messages;
	public ArrayList<String> mailMessages;

	public NotificationModel(ArrayList<String> errors, ArrayList<String> success, ArrayList<String> warnings,
			ArrayList<String> messages, ArrayList<String> mailMessages) {

		this.errors = errors;
		this.success = success;
		this.warnings = warnings;
		this.messages = messages;
		this.mailMessages = mailMessages;
	}

	/**
	 * @return the errors
	 */
	public ArrayList<String> getErrors() {
		return errors;
	}

	/**
	 * @param errors
	 *            the errors to set
	 */
	public void setErrors(ArrayList<String> errors) {
		this.errors = errors;
	}

	/**
	 * @return the success
	 */
	public ArrayList<String> getSuccess() {
		return success;
	}

	/**
	 * @param success
	 *            the success to set
	 */
	public void setSuccess(ArrayList<String> success) {
		this.success = success;
	}

	/**
	 * @return the warnings
	 */
	public ArrayList<String> getWarnings() {
		return warnings;
	}

	/**
	 * @param warnings
	 *            the warnings to set
	 */
	public void setWarnings(ArrayList<String> warnings) {
		this.warnings = warnings;
	}

	/**
	 * @return the messages
	 */
	public ArrayList<String> getMessages() {
		return messages;
	}

	/**
	 * @param messages
	 *            the messages to set
	 */
	public void setMessages(ArrayList<String> messages) {
		this.messages = messages;
	}

	/**
	 * @return the mailMessages
	 */
	public ArrayList<String> getMailMessages() {
		return mailMessages;
	}

	/**
	 * @param mailMessages
	 *            the mailMessages to set
	 */
	public void setMailMessages(ArrayList<String> mailMessages) {
		this.mailMessages = mailMessages;
	}

}
