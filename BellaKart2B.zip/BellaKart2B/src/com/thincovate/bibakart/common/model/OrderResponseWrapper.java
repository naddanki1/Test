package com.thincovate.bibakart.common.model;

import java.util.ArrayList;
import java.util.List;

import com.thincovate.bibakart.orders.model.Order;

public class OrderResponseWrapper extends ResponseWrapper {
	private int totalOrders;
	private List<Order> orders = new ArrayList<Order>();


	public OrderResponseWrapper() {
	}

	public OrderResponseWrapper(Integer code, String message, String status, List<Order> orders) {
		super(code, status, message);
		this.orders = orders;
	}

	public List<Order> getOrders() {
		return orders;
	}

	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}

	public int getTotalOrders() {
		return totalOrders;
	}

	public void setTotalOrders(int totalOrders) {
		this.totalOrders = totalOrders;
	}

}
