package com.thincovate.bibakart.common.model;

import java.util.ArrayList;
import java.util.List;

import com.thincovate.bibakart.payments.model.Payment;
import com.thincovate.bibakart.payments.model.SellerPayments;

public class PaymentResponseWrapper extends ResponseWrapper {
	private int totalPayments;
	private List<Payment> payments = new ArrayList<Payment>();
	private List<SellerPayments> sellerPayments = new ArrayList<SellerPayments>();

	public PaymentResponseWrapper() {

	}

	public PaymentResponseWrapper(Integer code, String message, String status) {
		super(code, status, message);
	}

	public PaymentResponseWrapper(Integer code, String message, String status, List<Payment> payments) {
		super(code, status, message);
		this.payments = payments;
	}

	public List<Payment> getPayments() {
		return payments;
	}

	public void setPayments(List<Payment> payments) {
		this.payments = payments;
	}

	public int getTotalPayments() {
		return totalPayments;
	}

	public void setTotalPayments(int totalPayments) {
		this.totalPayments = totalPayments;
	}

	public List<SellerPayments> getSellerPayments() {
		return sellerPayments;
	}

	public void setSellerPayments(List<SellerPayments> sellerPayments) {
		this.sellerPayments = sellerPayments;
	}

}
