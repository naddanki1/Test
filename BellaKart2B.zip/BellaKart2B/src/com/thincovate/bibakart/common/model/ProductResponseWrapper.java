package com.thincovate.bibakart.common.model;

import java.util.ArrayList;
import java.util.List;

import com.thincovate.bibakart.catalog.model.ProductsModel;

public class ProductResponseWrapper extends ResponseWrapper {

	private List<ProductsModel> products = new ArrayList<ProductsModel>();

	public ProductResponseWrapper() {

	}

	public ProductResponseWrapper(Integer code, String message, String status, List<ProductsModel> products) {
		super(code, status, message);
		this.products = products;
	}

	public List<ProductsModel> getProducts() {
		return products;
	}

	public void setProducts(List<ProductsModel> products) {
		this.products = products;
	}

}
