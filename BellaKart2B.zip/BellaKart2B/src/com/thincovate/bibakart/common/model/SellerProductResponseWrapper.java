package com.thincovate.bibakart.common.model;

import java.util.ArrayList;
import java.util.List;

import com.thincovate.bibakart.catalog.model.SellerProductsModel;

public class SellerProductResponseWrapper extends ResponseWrapper {

	private List<SellerProductsModel> sellerproducts = new ArrayList<SellerProductsModel>();
	private int totalProducts;

	public int getTotalProducts() {
		return totalProducts;
	}

	public void setTotalProducts(int totalProducts) {
		this.totalProducts = totalProducts;
	}

	public SellerProductResponseWrapper() {

	}

	public SellerProductResponseWrapper(Integer code, String message, String status,
			List<SellerProductsModel> products) {
		super(code, status, message);
		this.sellerproducts = products;
	}

	public List<SellerProductsModel> getSellerProducts() {
		return sellerproducts;
	}

	public void setSellerProducts(List<SellerProductsModel> sellerproducts) {
		this.sellerproducts = sellerproducts;
	}

}
