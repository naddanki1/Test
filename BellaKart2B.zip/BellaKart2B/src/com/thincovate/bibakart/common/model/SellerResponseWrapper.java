package com.thincovate.bibakart.common.model;

import java.util.ArrayList;
import java.util.List;

import com.thincovate.bibakart.admin.model.SellerDetails;

public class SellerResponseWrapper extends ResponseWrapper {

	private List<SellerDetails> sellerDetails = new ArrayList<SellerDetails>();

	public SellerResponseWrapper() {

	}

	public SellerResponseWrapper(Integer code, String message, String status, List<SellerDetails> sellerDetails) {
		super(code, status, message);
		this.sellerDetails = sellerDetails;
	}

	public List<SellerDetails> getSellerDetails() {
		return sellerDetails;
	}

	public void setSellerDetails(List<SellerDetails> sellerDetails) {
		this.sellerDetails = sellerDetails;
	}

}
