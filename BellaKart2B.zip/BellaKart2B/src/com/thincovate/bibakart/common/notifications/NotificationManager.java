/**
 * 
 */
package com.thincovate.bibakart.common.notifications;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;

/**
 * @author Sandeep
 *
 */
public class NotificationManager {

	static Logger log = Logger.getLogger(NotificationManager.class);
	private static NotificationManager instance = null;
	private static Properties emailProperties = null;
	private Session mailSession;
	private MimeMessage emailMessage;
	
	/**
	 * Singleton <i>instance</i>
	 * @return
	 * @throws IOException 
	 */
	public static NotificationManager getInstance() throws IOException{
		if(instance == null){
			instance = new NotificationManager();
		}
		return instance;
	}
	
	
	/**
	 * Private Instance
	 * Initializes server properties as part of creating an instance
	 */
	private NotificationManager() throws IOException {
		
		emailProperties = new Properties();
		InputStream input = null;
		try {
			input = new FileInputStream("newdawn.properties");
			emailProperties.load(input);
		} catch (IOException e) {
			input = NotificationManager.class.getClassLoader().getResourceAsStream("application.properties");
			//log.info(input);
			try {
				emailProperties.load(input);
			} catch (IOException ioe) {
				log.error("Error loading properties file");
				ioe.printStackTrace();
				throw ioe;
			}
			System.out.println("test");
		}/*finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException ioe) {
					ioe.printStackTrace();
					throw ioe;
				}
			}
		}*/
	}
	
	/**
	 * Creating email message
	 * @throws AddressException
	 * @throws MessagingException
	 */
	public void createNotificationMessage(String emailId, String content, String subject)
			throws AddressException, MessagingException {
		
		mailSession = Session.getDefaultInstance(emailProperties, null);
		emailMessage = new MimeMessage(mailSession);
		
		String[] toList = (emailId.toString()).split(",");
		
		for (int i = 0; i < toList.length; i++) {
			log.info(toList[i]);
			emailMessage.addRecipient(Message.RecipientType.TO,
					new InternetAddress(toList[i]));
		}
		
		// For adding BCC
		/*String[] bccList = (emailProperties.getProperty("mail.email.support.emaillist.bcc").toString()).split(",");
		
		for (int i = 0; i < toList.length; i++) {
			emailMessage.addRecipient(Message.RecipientType.BCC,
					new InternetAddress(toList[i]));
		}*/

		Address[] from = InternetAddress.parse(emailProperties.getProperty("mail.email.support.autogenerate.from"));
		emailMessage.addFrom(from);
	    
		emailMessage.setSubject(subject);
		emailMessage.setContent(content, "text/html"); // for a html email
		
		// emailMessage.setText(emailBody); // for a text email

	}
	
	/**
	 * Method to send email notification
	 * @throws AddressException
	 * @throws MessagingException
	 */
	public void pushEmailNotification() throws AddressException, MessagingException {

		Transport transport = mailSession.getTransport("smtp");
		transport.connect(emailProperties.getProperty("mail.email.host"), Integer.parseInt(emailProperties.getProperty("mail.smtp.port")),emailProperties.getProperty("mail.from.user"), emailProperties.getProperty("mail.from.user.pwd"));
		transport.sendMessage(emailMessage, emailMessage.getAllRecipients());
		transport.close();
		System.out.println("OTP Email sent successfully.");
	}
	
	/**
	 * Method to retrieve the email properties
	 * @param key
	 * @return
	 */
	public String getProperty(String key){
		String val = emailProperties.getProperty(key);
		if(val != null)
			return val;
		else
			return "";
	}
	
	
}
