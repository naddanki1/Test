/**
 * 
 */
package com.thincovate.bibakart.common.notifications;

import java.io.IOException;

import javax.mail.MessagingException;

import org.springframework.stereotype.Service;

import com.thincovate.bibakart.common.exceptions.ServiceLayerException;

/**
 * @author Sandeep
 *
 */
@Service
public class NotificationService {
	
	public void notifyConfirmationByEmail(String emailId, String emailContent, String subject){
		try{
			NotificationManager notify = NotificationManager.getInstance();
			notify.createNotificationMessage(emailId, emailContent, subject);
			notify.pushEmailNotification();
		}catch(IOException | MessagingException ioe){
			throw new ServiceLayerException(ioe.getMessage());
		}
	}
	
	public void sendSMS(String mobile, String otp, boolean isForgotPwd){
		try{
			SMSManager smsMgr = SMSManager.getInstance();
			smsMgr.sendSMS(mobile, otp , isForgotPwd);
		}catch(IOException ioe){
			ioe.printStackTrace();
		}
	}
}
