/**
 * 
 */
package com.thincovate.bibakart.common.notifications;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import org.apache.log4j.Logger;

import com.thincovate.bibakart.common.PropertyReader;

/**
 * @author Sandeep
 *
 */
public class SMSManager {
	
	static Logger log = Logger.getLogger(SMSManager.class);
	private static SMSManager instance = null;
	
	/**
	 * Singleton <i>instance</i>
	 * @return
	 * @throws IOException 
	 */
	public static SMSManager getInstance() throws IOException{
		if(instance == null){
			instance = new SMSManager();
		}
		return instance;
	}
	
	private SMSManager(){
		
	}
	
	public void sendSMS(String mobile, String otp, boolean ifForgotPwd) throws IOException 
	{ 
		String phone	= ""; 
		String message	= ""; 
		String sender	= "";
		String ppgHost	= "";
		String username = "";
		String password = "";
		String countryCode = "91";
		
		try{ 
			sender	= PropertyReader.getInstance().getProperty("sms.text.gateway.senderID");
			ppgHost	= PropertyReader.getInstance().getProperty("sms.text.gateway.host");
			username = PropertyReader.getInstance().getProperty("sms.text.gateway.user");
			password = PropertyReader.getInstance().getProperty("sms.text.gateway.password");
			
			phone = URLEncoder.encode(countryCode+mobile, "UTF-8"); 
			log.debug("phone------>"+phone); 
			
			message=URLEncoder.encode(otp, "UTF-8"); 

			log.debug("message---->"+message); 
		} 
		catch (IOException e) { 
			log.debug("Encoding not supported"); 
			throw e;
		} 
		String urlStr = ppgHost+"?user="+username+"&password="+password+"&PhoneNumber="+phone+"&Text="+message+"&Sender="+sender ;
		log.debug("url string->"+urlStr); 
		
		try {		
			URL url2=new URL(urlStr); 

			HttpURLConnection connection = (HttpURLConnection) url2.openConnection(); 
			connection.setDoOutput(false); 
			connection.setDoInput(true); 

			log.debug("Opened Con->"+connection); 
			String res=connection.getResponseMessage(); 
			log.debug("Get Resp  ->"+res); 
			int code = connection.getResponseCode () ; 
		
			if ( code == HttpURLConnection.HTTP_OK ){ 
				connection.disconnect() ; 
			}
		}
		catch(IOException e){
			e.printStackTrace();
			log.debug("unable to create new url"+e.getMessage());
		}
	} 

}
