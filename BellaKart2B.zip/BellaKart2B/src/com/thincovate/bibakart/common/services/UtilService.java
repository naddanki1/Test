package com.thincovate.bibakart.common.services;

import javax.servlet.http.HttpServletRequest;

public interface UtilService {

	public void sendEmail(String string, String emailAddr, HttpServletRequest request);

	void sendEmail(String name,String emailAddr, String subject, String text,HttpServletRequest request);
}
