package com.thincovate.bibakart.common.services.impl;


import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.thincovate.bibakart.common.PropertyReader;
import com.thincovate.bibakart.common.services.UtilService;

@Service
@Transactional
public class UtilServiceImpl implements UtilService {

	private static Logger log = Logger.getLogger(UtilServiceImpl.class);
	@Override
	public void sendEmail(String code, String emailAddr, HttpServletRequest req) {
		Properties props = null;
		Session session1 = null;
		MimeMessage msg = null;
		try {
			final String username = PropertyReader.getInstance().getProperty("mail.from.user");
			final String password = PropertyReader.getInstance().getProperty("mail.from.user.pwd");

			props = new Properties();

			props.put("mail.smtp.auth", PropertyReader.getInstance().getProperty("mail.smtp.auth"));
			props.put("mail.smtp.starttls.enable", PropertyReader.getInstance().getProperty("mail.smtp.starttls.enable"));
			props.put("mail.smtp.host", PropertyReader.getInstance().getProperty("mail.email.host"));
			props.put("mail.smtp.port", PropertyReader.getInstance().getProperty("mail.smtp.port"));

			Authenticator auth = new Authenticator() {
				public PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(username, password);
				}
			};
			try {
				session1 = Session.getInstance(props, auth);

				msg = new MimeMessage(session1);

				msg.setFrom(new InternetAddress(username));
				InternetAddress[] toAddresses = { new InternetAddress(emailAddr) };
				msg.setRecipients(Message.RecipientType.TO, toAddresses);
				msg.setSubject(getSubject("Confirmation Link From Bibakart.com"));
				msg.setContent(getText(code, emailAddr, req), "text/html");
				//msg.setText(getText(code, emailAddr, req));
				System.out.println("Sending Email");
				Transport.send(msg);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private String getText(String code, String emailAddr, HttpServletRequest request) {
		String emailContent = "";
		try {
			String serverurl = request.getRequestURL().toString().substring(0,request.getRequestURL().toString().lastIndexOf("/"));
			
			String textmsg = serverurl + "/emailVerify" + code;	
			log.info("url :"+textmsg);
			textmsg ="<a href='"+textmsg+"'>Proceed to Registration</a>";
			emailContent = PropertyReader.getInstance().getProperty("mail.email.register_message");
			emailContent = emailContent.replace("###NAME_STRING###", "user");
			emailContent = emailContent.replace("###REG_LINK###", textmsg);		
			return emailContent;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "BellaKart.com";
	}

	private String getSubject(String type) {

		try {

			if (type.equals("confirmMail")) {
				return "Confirmation Link From Bibakart.com";
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return "Bibakart.com";
	}
	
	@Override
	public void sendEmail(String name,String emailAddr, String subject, String code,HttpServletRequest request) {
		Properties props = null;
		Session session1 = null;
		MimeMessage msg = null;

		try {
			final String username = PropertyReader.getInstance().getProperty("mail.from.user");
			final String password = PropertyReader.getInstance().getProperty("mail.from.user.pwd");

			props = new Properties();

			props.put("mail.smtp.auth", PropertyReader.getInstance().getProperty("mail.smtp.auth"));
			props.put("mail.smtp.starttls.enable", PropertyReader.getInstance().getProperty("mail.smtp.starttls.enable"));
			props.put("mail.smtp.host", PropertyReader.getInstance().getProperty("mail.email.host"));
			props.put("mail.smtp.port", PropertyReader.getInstance().getProperty("mail.smtp.port"));
			Authenticator auth = new Authenticator() {
				public PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(username, password);
				}
			};
			try {
				session1 = Session.getInstance(props, auth);

				msg = new MimeMessage(session1);

				msg.setFrom(new InternetAddress(username));
				InternetAddress[] toAddresses = { new InternetAddress(emailAddr) };
				msg.setRecipients(Message.RecipientType.TO, toAddresses);
				msg.setSubject(subject);
				msg.setContent(getMailText(name,subject, code, request), "text/html");
				
				Transport.send(msg);

			} catch (Exception e) {
				e.printStackTrace();

			}

		} catch (Exception e) {

			e.printStackTrace();
		}
	}
	
	private String getMailText(String name,String subject,String code,HttpServletRequest request){
		
		String emailContent = "";
		try {
			String serverurl = request.getRequestURL().toString().substring(0,request.getRequestURL().toString().lastIndexOf("/"));
			if(subject.equalsIgnoreCase(PropertyReader.getInstance().getProperty("mail.email.lostpwd_subject"))){
				String textmsg = serverurl + "/resetpwd?i=" + code;	
				log.info("url :"+textmsg);
				textmsg ="<a href='"+textmsg+"'>Reset Password</a>";
				emailContent = PropertyReader.getInstance().getProperty("mail.email.lostpwd_message");
				emailContent = emailContent.replace("###NAME_STRING###", name);
				emailContent = emailContent.replace("###RESET_PWD_LINK###", textmsg);		
				return emailContent;
			}
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		return emailContent;
	}
	


}
