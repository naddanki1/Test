package com.thincovate.bibakart.common.utils;

import java.util.HashMap;

public class BibakartConstants {
	public final static String PS_JUSTREGISTER = "justRegister";
	public final static String PS_EMAILVERIFY = "emailVerify";
	public final static String PS_CONTACT_DETAILS = "contactDetails";
	public final static String PS_CATEGORY_DETAILS = "categoryDetails";
	public final static String PS_BUSINESS_DETAILS = "businessDetails";
	public final static String PS_MOBILE_VERIFICATION = "mobileVerified";
	public final static String PS_FINISH = "finish";

	public final static String MOBILE_VERIFY_PENDING = "mobileVerificationPending";
	public final static String MOBILE_VERIFY_COMPLETE = "complete";
	public static final String ORDER_TOBEDISPATCHED = "toBeDispatched";
	public static final String ORDER_READYTODISPATCHED = "readyToDispatched";
	public static final String ORDER_CANCELLED = "cancel";
	public static final String ORDER_SHIPPED = "shipped";
	public static final String ORDER_DELIVERED = "delivered";
	public static final String ORDER_RETURNED = "return";

	public static final String FEEDBACK_PENDING = "feedbackPending";
	public static final String FEEDBACK_REVISION = "feedbackRevision";
	public static final String FEEDBACK_COMPLETE = "feedbackComplete";
	public static final String STATUS_PENDING = "1";
	public static final String PENDING = "pending";
	public static final String NEW = "new";

	public static final String SELLER_ID = "sellerId";
	public static final String SELLER_PRODUCT_NEW = "New";
	public static final String SELLER_PRODUCT_PENDING = "Pending";
	public static final String SELLER_PRODUCT_REQUESTAPPROVAL = "Request Approval";
	public static final String USER_NAME = "username";
	public static final String ATTRIBUTE_NAME = "attributeName";
	public static final String APPROVAL_STATUS2 = "approvalStatus";
	public static final String PARENT_CATEGORY_ID = "parentCategoryId";
	public static final String CATEGORY_ID = "categoryId";
	public static final String SELLER_PRODUCT_ID = "sellerProductId";
	public static final String CATEGORY_NAME = "categoryName";
	public static final String SKIN_TYPE = "skinType";
	public static final String COMPOSITION_TYPE = "compositionType";
	public static final String COMPOSITION = "composition";
	public static final String APPLICATION_FREQUENCY = "applicationFrequency";
	public static final String VIDEO_URL = "videoUrl";
	public static final String TREATMENT_KIT = "treatmentKit";
	public static final String TREATMENT_PERIOD = "treatmentPeriod";
	public static final String IS_ORGANIC = "isOrganic";
	public static final String PRODUCT_TITLE = "productTitle";
	public static final String PRODUCT_DESC = "productDesc";
	public static final String BRAND_ID = "brandId";
	public static final String BRAND_NAME = "brandName";
	public static final String STATUS = "status";
	public static final String PRODUCT_ID = "productId";
	public static final String IMAGE_LOCATION = "imageLocation";
	public static final String SKU_ID = "skuId";
	public static final String MRP = "mrp";
	public static final String SELLING_PRICE = "sellingPrice";
	public static final String UNITS = "units";
	public static final String IS_COD_ALLOWED = "isCodAllowed";
	public static final String HAS_FREE_DELIVERY = "hasFreeDelivery";
	public static final String WEIGHT_FOR_FRIGHT = "weightForFright";
	public static final String SHIPPING_CHARGES = "shippingCharges";
	public static final String ESTIMATED_SHIPPING_DAYS = "estimatedShippingDays";
	public static final String SEARCH_KEYWORDS = "searchKeywords";
	public static final String WARRANTY_TYPE = "warrantyType";
	public static final String WARRANTY_SERVICE_TYPE = "warrantyServiceType";
	public static final String MODE_OF_ADDITION = "modeOfAddition";
	public static final String AVAILABLE_STATUS = "availableStatus";
	public static final String PRODUCT_AVAILABLE = "1";
	public static final String MODE_BY_SEARCH = "bysearch";
	public static final String MODE_INDIVIDUAL = "individual";

	public static final String VENDORS = "Vendors";
	public static final String PRODUCTS = "Products";
	public static final String CATEGORIES = "Categories";
	public static final String BRANDS = "Brands";
	public static final String ATTRIBUTES = "Attributes";
	public static final String TAN = "tan";
	public static final String PAN = "pan";
	public static final String TIN = "tin";
	public static final String CANCELLED_CHEQUE = "cancelledCheque";
	public static final String KYC_ADDRESS = "kycAddr";
	public static final String KYC_ID = "kycId";
	public static final String CONTACT_DETAILS = "contactDetails";

	public final static String NO_FILE = "There is no file";
	public final static String FILE_EXCEEDS_5MB = "File Maximum Size is 5MB Only";
	public final static String FILE_FORMAT_EXCEL = "File Formatted is Excel Only";
	public final static String FILE_ZIP_ONLY = "Image File Zip Formatted Only";
	public final static String FILE_ZIP_EXCEEDS_15MB = "Zip File Maximum Size is 15MB";
	public final static String FILE_ZIP_JPG_PNG_ONLY = "Files are jpg and png only";
	public final static String FILE_ZIP_JPG_PNG_SIZE = "The image size is 500x500 only";
	public static final String SUCCESS_EXCEL_UPLOAD = "Excel File Successfully Uploaded";
	public static final String SUCCESS_ZIP_UPLOAD = "Success Images Zip File Uploaded";

	public static final int IMG_THUMB_WIDTH = 100;
	public static final int IMG_THUMB_HEIGHT = 122;
	public static final int IMG_SHOW_WIDTH = 512;
	public static final int IMG_SHOW_HEIGHT = 512;
	public static final int IMG_LARGE_WIDTH = 850;
	public static final int IMG_LARGE_HEIGHT = 1036;
	public static final int IMG_BANNER1_WIDTH = 268;
	public static final int IMG_BANNER1_HEIGHT = 327;
	public static final int IMG_BANNER2_WIDTH = 234;
	public static final int IMG_BANNER2_HEIGHT = 350;
	public static final int IMG_BANNER3_WIDTH = 233;
	public static final int IMG_BANNER3_HEIGHT = 284;
	public static final int IMG_BANNER4_WIDTH = 300;
	public static final int IMG_BANNER4_HEIGHT = 366;

	@SuppressWarnings("serial")
	public static HashMap<String, String> APPROVAL_STATUS = new HashMap<String, String>() {
		{
			put("new", "new");
			put("pending", "pending");
			put("requestApproval", "requestApproval");
			put("approved", "approved");
			put("rejected", "rejected");
		}
	};
	@SuppressWarnings("serial")
	public static HashMap<String, String> DOC_NAME = new HashMap<String, String>() {
		{
			put("tanProof", "tanProof");
			put("panProof", "panProof");
			put("tinProof", "tinProof");
			put("kycAddr", "kycAddr");
			put("kycId", "kycId");
			put("cancelledCheque", "cancelledCheque");
		}
	};
	public static final String VENDOR_HOME_PAGE = "catalog";
	public static final String USER_HOME_PAGE = "admin";
	public static final String ONLINE = "online";
	public static final String OFFLINE = "offline";
	public static final String STORE_DISPLAY_NAME = "storeDisplayName";
	public static final String MOBILE = "mobile";
	public static final String EMAIL_ADDRESS = "emailAddr";

	// orders Module related
	public static final String DOC_SHIPPING_LABEL = "shippingLabel";
	public static final String ORDER_ID = "orderId";
	public static final String ITEM_ID = "orderItemsId";
    public static final String DOC_MANIFEST ="manifest";
    public static final String SHIPPING_LABLE_STATUS ="shipping_lable_status";
    public static final String MANIFEST_STATUS ="manifestLableStatus";
    public static final String UPLOADED_BY_ADMIN = "uploaded_by_admin";
    public static final String UPLOADED_BY_SELLER = "uploaded_by_seller";
    public static final String DOWNLOADED_BY_SELLER = "downloaded_by_seller";
    public static final String PAYMENT_STATUS_COMPLETED = "completed";
	public static final String PAYMENT_STATUS_FAILED = "failed";
	public static final String PAYMENT_STATUS_PENDING= "pending";
	public static final String STATUS_NEW = "new";
	public static final String STATUS_TO_SHIP = "to_ship";
	public static final String STATUS_SHIPPED = "shipped";
	public static final String STATUS_DELIVERED = "delivered";
	public static final String STATUS_RETURNED = "returned";
	public static final String STATUS_CANCELLED = "cancelled";
	public static final String STATUS_OBSELETE = "obsolete";
	public static final String STATUS_NA = "N/A";
	public static final String STATUS_IN_TRANSIT = "in_transit";
    
    //configurations related 
    public static final String PAYMENT_REMITTANCE_CYCLE = "payments_remittance_cycle";
    public static final String PAYMENTS_ORDERS_CUTOFF_CYCLE = "payments_orders_cutoff_cycle";
    public static final String DELIVERY_CHARGES = "delivery_charges";
    public static final String MARKETTING_FEE = "marketting_fee";
    public static final String LAST_REMITTANCE_DATE = "last_remittance_date";
    public static final String LAST_ORDERS_CUTOFF_DATE = "last_orders_cutoff_date";
    public static final String NEXT_REMITTANCE_DATE = "next_remittance_date";
    public static final String NEXT_ORDERS_CUTOFF_DATE = "next_orders_cutoff_date";
    

    
}
