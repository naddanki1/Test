package com.thincovate.bibakart.common.utils;

public class BibakartRoles {

	public final static String PRODUCT_MANAGER = "product_manager";
	public final static String ADMIN = "admin";
	public final static String RELATIONSHIP_MANAGER = "relationship_manager";
	public final static String SUPPORT = "support";
	public final static String VENDOR = "vendor";
	public final static String USER = "user";

}
