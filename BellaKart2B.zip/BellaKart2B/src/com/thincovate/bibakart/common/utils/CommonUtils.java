package com.thincovate.bibakart.common.utils;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.thincovate.bibakart.entitymodels.SellerMaster;
import com.thincovate.bibakart.sessionmgnt.model.Seller;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

@SuppressWarnings("restriction")
public class CommonUtils {

	/*@Autowired
	private ProspectiveSellersService prospectiveSellersService;*/
	private static Logger log = Logger.getLogger(CommonUtils.class);

	private static final String ALGO = "AES";
	private static final String keyVal = "venkat12345venki";

	public static enum Mode {
		ALPHA, ALPHANUMERIC, NUMERIC
	}

	public static String encryptText(String str) {
		String encryptedValue = null;
		try {
			Key key = generateKey();
			Cipher c = Cipher.getInstance(ALGO);
			c.init(Cipher.ENCRYPT_MODE, key);
			byte[] encVal = c.doFinal(str.getBytes());
			encryptedValue = new BASE64Encoder().encode(encVal);
		} catch (InvalidKeyException | NoSuchAlgorithmException | NoSuchPaddingException | IllegalBlockSizeException
				| BadPaddingException e) {
			e.printStackTrace();
		}
		return encryptedValue;
	}

	public static String decryptText(String str) {
		String decryptedValue = null;
		try {
			Key key = generateKey();
			Cipher c = Cipher.getInstance(ALGO);
			c.init(Cipher.DECRYPT_MODE, key);
			byte[] decordedValue = new BASE64Decoder().decodeBuffer(str);
			byte[] decValue = c.doFinal(decordedValue);
			decryptedValue = new String(decValue);
		} catch (InvalidKeyException | NoSuchAlgorithmException | NoSuchPaddingException | IllegalBlockSizeException
				| BadPaddingException | IOException e) {

			e.printStackTrace();
		}
		return decryptedValue;
	}

	private static Key generateKey() throws IllegalArgumentException {
		Key key = new SecretKeySpec(keyVal.getBytes(), ALGO);
		return key;
	}

	public static String generateRandomString(int length, Mode mode) throws Exception {

		StringBuffer buffer = new StringBuffer();
		String characters = "";

		switch (mode) {

		case ALPHA:
			characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
			break;

		case ALPHANUMERIC:
			characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
			break;

		case NUMERIC:
			characters = "1234567890";
			break;
		}

		int charactersLength = characters.length();

		for (int i = 0; i < length; i++) {
			double index = Math.random() * charactersLength;
			buffer.append(characters.charAt((int) index));
		}
		return buffer.toString();
	}

	public static String getIpAddress(HttpServletRequest request) {

		String ip = request.getHeader("X-Forwarded-For");
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("HTTP_X_FORWARDED_FOR");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
		}
		return ip;

	}

	public static String getMACAddress(String ip) {
		String str = "";
		String macAddress = "";
		try {
			Process p = Runtime.getRuntime().exec("nbtstat -A " + ip);
			InputStreamReader ir = new InputStreamReader(p.getInputStream());
			LineNumberReader input = new LineNumberReader(ir);
			for (int i = 1; i < 100; i++) {
				str = input.readLine();
				if (str != null) {
					if (str.indexOf("MAC Address") > 1) {
						macAddress = str.substring(str.indexOf("MAC Address") + 14, str.length());
						break;
					}
				}
			}
		} catch (IOException e) {
			e.printStackTrace(System.out);
		}
		return macAddress;
	}

	public static boolean checkStatus(HttpSession session, HttpServletRequest request) {
		boolean flag = false;
		Long mobile = null;
		String emailAddress = null;

		try {
			mobile = (Long) session.getAttribute(SessionProperties.MOBILE_NO);
			emailAddress = (String) session.getAttribute(SessionProperties.EMAIL_ADDR);

			if ((mobile != null || emailAddress != null)) {

				return true;
			} else {
				log.info("Invalid session!!!");
				session.invalidate();

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return flag;
	}

	public static boolean checkStatus(HttpSession session){
		try{
		Seller seller=(Seller)session.getAttribute("seller");
		if(seller != null && seller.getRegStatus().equalsIgnoreCase("finish")){
			return false;
		}
			
		}catch(Exception e){
			
		}
		return true;
	}
	public static void setLoginSessionValues(SellerMaster sellerMaster, HttpSession session) {

		session.setMaxInactiveInterval(100000);
		session.setAttribute(SessionProperties.SELLER_ID, sellerMaster.getSellerId());
		session.setAttribute(SessionProperties.SELLER_STATUS, sellerMaster.getSellerStatus());
		session.setAttribute(SessionProperties.SELLER_STORE_NAME, sellerMaster.getStoreDisplayName());

		session.setAttribute(SessionProperties.EMAIL_ADDR, sellerMaster.getEmailAddr());
		session.setAttribute(SessionProperties.MOBILE_NO, sellerMaster.getMobile());
		session.setAttribute(SessionProperties.LOGIN_NAME, sellerMaster.getStoreDisplayName());

	}


	public static String getEncryptKey(String text) {

		try {
			String key = "venkat12345venki"; // 128 bit key

			// Create key and cipher

			Key aesKey = new SecretKeySpec(key.getBytes(), "AES");

			Cipher cipher = Cipher.getInstance("AES");

			// encrypt the text

			cipher.init(Cipher.ENCRYPT_MODE, aesKey);

			byte[] encrypted = cipher.doFinal(text.getBytes());

			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < encrypted.length; i++) {
				sb.append(Integer.toString((encrypted[i] & 0xff) + 0x100, 16).substring(1));
			}
			// Get complete hashed password in hex format
			return sb.toString();
		} catch (InvalidKeyException | NoSuchAlgorithmException | NoSuchPaddingException | IllegalBlockSizeException
				| BadPaddingException e) {

			e.printStackTrace();
		}

		return null;

	}

	public static Double getMkfee(Double sellingPrice, Float mkPercentage) {
		Double mkFee = sellingPrice * (mkPercentage / 100.0);
		mkFee = (double) Math.round(mkFee * 100.00) / 100.00;
		return mkFee;

	}
	
	public static Double getPayableValue(Double sellingPrice, Double mkFee, Double tax, Double logisticFee) {
		Double payableValue = sellingPrice - (mkFee + tax + logisticFee);
		payableValue = (double) Math.round(payableValue * 100.00) / 100.00;
		return payableValue;

	}
	public static String goStatus(String psStatus) {
		if (psStatus.equals(BibakartConstants.PS_EMAILVERIFY)
				|| psStatus.equals(BibakartConstants.MOBILE_VERIFY_PENDING)
				|| psStatus.equals(BibakartConstants.PS_MOBILE_VERIFICATION)) {

			return  PathConstants.REGISTER_CONTACT_DETAILS;
		}

		else if (psStatus.equals(BibakartConstants.PS_CONTACT_DETAILS)) {

			return  PathConstants.REGISTER_CATEGORY_DETAILS;
		}

		else if (psStatus.equals(BibakartConstants.PS_CATEGORY_DETAILS)) {
			return  PathConstants.REGISTER_BUSINESS_DETAILS;

		}

		else if (psStatus.equals(BibakartConstants.PS_BUSINESS_DETAILS)	|| psStatus.equals(BibakartConstants.PS_FINISH)) {

			return  PathConstants.CATALOG;
		}

		return "error";
	}
	
}
