package com.thincovate.bibakart.common.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateUtils {

	public static Date getCurrentDate() {

		String pattern = "MM/dd/yyyy hh:mm:ss";
		SimpleDateFormat format = new SimpleDateFormat(pattern);
		Date date = null;
		try {
			date = format.parse(format.format(new Date()));

		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}

	public static Date getSaleTodayDate() {

		String pattern = "dd/MM/yyyy";
		SimpleDateFormat format = new SimpleDateFormat(pattern);
		Date date = null;
		try {
			date = format.parse(format.format(new Date()));

		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}

	public static String getPrintDate(Date Date) {
		String pattern = "dd-MM-yyyy";
		SimpleDateFormat format = new SimpleDateFormat(pattern);
		String result = null;
		try {
			result = format.format(Date);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public static String getCurrentStringTime() {

		String pattern = "yyyyMMddhhmmssSSS";
		SimpleDateFormat format = new SimpleDateFormat(pattern);

		String result = null;
		try {
			result = format.format(new Date());

		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public static long getHrDiff(Date date2) {
		Date date1 = getCurrentDate();
		long diff = date1.getTime() - date2.getTime();
		long diffHours = diff / (60 * 60 * 1000);
		return diffHours;
	}

	public static String getCurrentStringTimeWOPart() {

		String pattern = "yyyyMMddhhmmss";
		SimpleDateFormat format = new SimpleDateFormat(pattern);
		String result = null;
		try {
			result = format.format(new Date());

		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public static String formatDate(String dateInString) {
		String date_s = dateInString;
		SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		String formattedDate = null;
		try {
			Date date = dt.parse(date_s);
			formattedDate = (new SimpleDateFormat("dd-MM-yyyy")).format(date);
		} catch (ParseException e) {
			e.printStackTrace();
			formattedDate = dateInString.substring(0, 10);
		}
		return formattedDate;
	}
	public static Date parseDate(String dateInString) {
		String date_s = dateInString;
		SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd");
		Date date = null;
		try {
			 date = dt.parse(date_s);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}
	public static String formatDate(Date date) {
		String date_s = null;
		SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd");
		try {
			date_s = dt.format(date);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return date_s;
	}
	public static String format(Date date){
		SimpleDateFormat sd = new SimpleDateFormat("MM/dd/yyyy");
		try {
			return sd.format(date);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}
	public static String formatDateOnly(Date date){
		SimpleDateFormat sd = new SimpleDateFormat("MM/dd/yyyy");
		try {
			return sd.format(date);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}
	public static Date getRemittanceDate(){
		String pattern = "dd/MM/yyyy";
		SimpleDateFormat format = new SimpleDateFormat(pattern);
		Date date = null;
		try {
			Calendar calendar= Calendar.getInstance();
			int day = calendar.get(Calendar.DAY_OF_WEEK);
			int month = calendar.get(Calendar.MONTH);
			int year = calendar.get(calendar.YEAR)+1;
			String remittanceDate = day+"/"+month+"/"+year;
			
			date = format.parse(remittanceDate);

		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}
}
