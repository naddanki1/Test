/**
 * 
 */
package com.thincovate.bibakart.common.utils;

/**
 * @author Sandeep
 *
 */

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.imageio.ImageIO;

public class FileUtils {

	public static void createDirectory(String folderName) throws IOException {
		File theDir = new File(folderName);
		if (!theDir.exists()) {
			try {
				theDir.mkdirs();
				theDir.setWritable(true);
			} catch (Exception se) {
				se.printStackTrace();
			}
		}
	}
	public static boolean createDirector(String folderName) {
		File theDir = new File(folderName);
		if (!theDir.exists()) {
			try {
				boolean created = theDir.mkdirs();
			} catch (Exception se) {
				se.printStackTrace();
				return false;
			}
			return true;
		} else
		return true;
	}
	public static void resize(String inputImagePath, String outputImagePath, int scaledWidth, int scaledHeight)
			throws IOException {
		// reads input image
		File inputFile = new File(inputImagePath);
		BufferedImage inputImage = ImageIO.read(inputFile);

		// creates output image
		BufferedImage outputImage = new BufferedImage(scaledWidth, scaledHeight, inputImage.getType());

		// scales the input image to the output image
		Graphics2D g2d = outputImage.createGraphics();
		g2d.drawImage(inputImage, 0, 0, scaledWidth, scaledHeight, null);
		g2d.dispose();

		// extracts extension of output file
		String formatName = outputImagePath.substring(outputImagePath.lastIndexOf(".") + 1);

		// writes to output file
		ImageIO.write(outputImage, formatName, new File(outputImagePath));
	}

	public static void resize(String inputImagePath, String outputImagePath, double percent) throws IOException {
		File inputFile = new File(inputImagePath);
		BufferedImage inputImage = ImageIO.read(inputFile);
		int scaledWidth = (int) (inputImage.getWidth() * percent);
		int scaledHeight = (int) (inputImage.getHeight() * percent);
		resize(inputImagePath, outputImagePath, scaledWidth, scaledHeight);
	}

	public static String getExtension(String name) {
		return name.substring(name.lastIndexOf('.'), name.length());
	}

	public static String getSkuId(String name) {

		return name.substring(0, name.lastIndexOf('_'));
	}

	public static String getNumber(String name) {

		return name.substring(name.lastIndexOf('_') + 1, name.lastIndexOf('.'));
	}

	public static void copyFolder(File src, File dest) throws IOException {

		if (src.isDirectory()) {

			// if directory not exists, create it
			if (!dest.exists()) {
				dest.mkdir();
				System.out.println("Directory copied from " + src + "  to " + dest);
			}

			// list all the directory contents
			String files[] = src.list();

			for (String file : files) {
				// construct the src and dest file structure
				File srcFile = new File(src, file);
				File destFile = new File(dest, file);
				// recursive copy
				copyFolder(srcFile, destFile);
			}

		} else {
			// if file, then copy it
			// Use bytes stream to support all file types
			InputStream in = new FileInputStream(src);
			OutputStream out = new FileOutputStream(dest);

			byte[] buffer = new byte[1024];

			int length;
			// copy the file content in bytes
			while ((length = in.read(buffer)) > 0) {
				out.write(buffer, 0, length);
			}

			in.close();
			out.close();
			System.out.println("File copied from " + src + " to " + dest);
		}
	}
	
    public static void unzip(String zipFilePath, String destDirectory) throws IOException {
        File destDir = new File(destDirectory);
        if (!destDir.exists()) {
            destDir.mkdirs();
        }
        
        ZipInputStream zipIn = new ZipInputStream(new FileInputStream(zipFilePath));        
        ZipEntry entry = null;
        // iterates over entries in the zip file        
        while ( (entry = zipIn.getNextEntry()) != null) {
            if (!entry.isDirectory()) {            	
            	String filePath = destDirectory +File.separator+ entry.getName();
                // if the entry is a file, extracts it            	
                extractFile(zipIn, filePath);
            } else {
            	String filePath = destDirectory ;
                // if the entry is a directory, make the directory
                File dir = new File(filePath);
                dir.mkdirs();
            }
            zipIn.closeEntry();
            //entry = zipIn.getNextEntry();
        }
        zipIn.close();
    }
    
    public static void expandZip(String zipFilePath, String fileName, String destDirectory) throws IOException {
        File destDir = new File(destDirectory);
        if (!destDir.exists()) {
            destDir.mkdirs();
        }
        ZipInputStream zipIn = new ZipInputStream(new FileInputStream(zipFilePath));
        extractFile(zipIn, destDirectory+File.separator+fileName);
        zipIn.close();
    }

    private static void extractFile(ZipInputStream zipIn, String filePath) throws IOException {
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(filePath));
        byte[] bytesIn = new byte[4096];
        int read = 0;
        while ((read = zipIn.read(bytesIn)) != -1) {
            bos.write(bytesIn, 0, read);
        }
        bos.close();
    }

}
