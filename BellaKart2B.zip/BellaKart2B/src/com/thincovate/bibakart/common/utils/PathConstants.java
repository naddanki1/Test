package com.thincovate.bibakart.common.utils;

public class PathConstants {

	public final static String GO_HOMEPAGE = "/";
	public final static String GO_REG1 = "registerContactDetails";
	public final static String GO_REG2 = "registerCategoriesDetails";
	public final static String GO_REG3 = "registerBusinessDetails";
	public static final String GO_DASHBOARD = "dashboard";

	public static final String REGISTER1 = "regsb";
	public static final String GO_LOGOUT = "logOut";

	public static final String GO_MOBILE_VERIFY = "mobVerify";

	public static final String GO_Profile = "profile";
	public static final String SUBMITREG2 = "reg_2";
	public static final String SUBMIT_MOBILE_VERIFY = "verifySubmit";
	public static final String SUBMIT_CATEGORY = "submitCategory";
	public static final String SUBMIT_REGISTRATION = "saveRegistration";
	public static final String AJAX_STORENAMECHECK = "storeNameCheck";
	public static final String AJAX_APPROVECATEGORY = "approveCategory";

	public static final String USER_CATALOG = "catalog";
	public static final String USER_BULKUPLOAD = "bulkUpload";

	public static final String SAVE_BULKUPLOAD = "saveBulkUpload";
	public static final String SAVE_CAT_ONEBYONE = "oneByoneSubmit";

	public static final String AJAX_EMAILCHECK = "checkEmailSeller";
	public static final String AJAX_MOBILECHECK = "checkMobileSeller";
	public static final String AJAX_USERNAMESELLER = "checkUsernameSeller";
	public static final String USER_ORDERS = "order";
	public static final String LOGIN = "login";
	public static final String REGISTER_CONTACT_DETAILS = "registerContactDetails";
	public static final String REGISTER_BUSINESS_DETAILS = "registerBusinessDetails";
	public static final String REGISTER_CATEGORY_DETAILS = "registerCategoriesDetails";
	public static final String MOBILE_VERIFY = "mobileVerify";
	public static final String EMAIL_VERIFY = "emailVerify";

	public static final String CATALOG = "catalog";
	public static final String ADD_CATALOG = "addCatalog";
	public static final String ADD_CATALOG_BY_SEARCH = "addCatalogBySearch";
	public static final String SEARCH_CATALOG = "searchCatalog";
	
	public static final String ADMIN_LOGIN = "admin/login";
	public static final String ADMIN_SELLERS = "admin/sellers";
	

}
