package com.thincovate.bibakart.common.utils;

public class SessionProperties {
	
	public final static String TABLE_SEARCH_STATUS="searchTableStatus";
	public final static String TABLE_SEARCH_NOITEMS="searchTableNoItems";
	public final static String TABLE_SEARCH_PAGENO="searchTablePageNo";
	public final static String TABLE_SEARCH_SEARCHVALUE="searchValue";
	
	public final static String TABLE_NOITEMS="tableNoItems";
	public final static String TABLE_PAGENO="tablePageNo";
	
	public final static String LOGIN_NAME="loginName";
	public final static String BRANCH_ID="branchCode";
	public final static String USER_NAME="userName";
	public final static String USER_ROLE="roleId";
	public final static String USER_ROLE_NAME="roleName";
	public final static String USER_FULL_NAME="fullName";
	
	public final static String USER_IMAGE="loginPhoto";
	public final static String EMPLOYEE="employee";
	public static final String EMAIL_ADDR = "userEmail";
	public static final String MOBILE_NO = "userMobileNo";
	public static final String SELLER_ID = "sellerID";
	public static final String SELLER_STATUS = "sellerStatus";
	public static final String SELLER_STORE_NAME = "sellerName";
	public static final String MOBILECONFIRMPOPUP = "mobilePopupStatus";
	public static final String MOBILECONFIRMCODE = "mobileConfirmCode";
	public static final String SELLER_LOGIN_ID = "sellerLoginID";
	
	
	
}
