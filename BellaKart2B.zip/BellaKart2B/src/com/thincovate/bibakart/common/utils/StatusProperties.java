package com.thincovate.bibakart.common.utils;

public class StatusProperties {
	
	public  final static String PS_JUSTREGISTER="justRegister";
	public  final static String PS_EMAILVERIFY="emailVerify";
	public  final static String PS_REGISTER1="register1";
	public  final static String PS_REGISTER2="register2";
	public  final static String PS_REGISTER3="register3";
	public  final static String PS_MOBILE_VERIFICATION="mobileVerify";
	public  final static String PS_FINISH="finish";
	
	
	public final static String MOBILE_VERIFY_PENDING="pending";
	public final static String MOBILE_VERIFY_COMPLETE="complete";
	public static final String ORDER_TOBEDISPATCHED = "toBeDispatched";
	public static final String ORDER_READYTODISPATCHED = "readyToDispatched";
	public static final String ORDER_CANCELLED= "cancel";
	public static final String ORDER_SHIPPED= "shipped";
	public static final String ORDER_DELIVERED= "delivered";
	public static final String ORDER_RETURNED= "return";
	
	public static final String FEEDBACK_PENDING="feedbackPending";
	public static final String FEEDBACK_REVISION="feedbackRevision";
	public static final String FEEDBACK_COMPLETE="feedbackComplete";

}
