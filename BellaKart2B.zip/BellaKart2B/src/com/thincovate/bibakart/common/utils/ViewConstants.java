package com.thincovate.bibakart.common.utils;

public class ViewConstants {

	public final static String LOGIN="login";
	public final static String REGISTRATION1="REGISTRATION_1";
	public final static String REGISTRATION2="REGISTRATION_2";
	public final static String REGISTRATION3="REGISTRATION_3";
}
