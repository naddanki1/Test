/**
 * 
 */
package com.thincovate.bibakart.common.utils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.thincovate.bibakart.admin.dao.BrandsDAO;
import com.thincovate.bibakart.admin.dao.CategoriesDAO;
import com.thincovate.bibakart.catalog.dao.AttributesDAO;

import com.thincovate.bibakart.entitymodels.Attributes;
import com.thincovate.bibakart.entitymodels.Brands;
import com.thincovate.bibakart.entitymodels.Categories;

/**
 * @author Sandeep
 *
 */
@Service
public class VirtualProxy {
	
	@Autowired
	private BrandsDAO brandsDao;
	@Autowired
	private CategoriesDAO categoriesDao;	
	@Autowired
	private AttributesDAO attributesDAO;

	
	private static Map<String,String> brands;
	private static Map<String,String> categories;
	private static Map<String,String> attributes;
	
/*	private static VirtualProxy instance;
	public static VirtualProxy getInstance(){
		if(instance == null)
			instance = new VirtualProxy();
		return instance;
	} */
	
	public String getBrandById(String id){
		if(id == null) return null;
		if(brands == null){
			brands = new HashMap<>();
			List<Brands> brandsList = brandsDao.findAll();
			for(Brands brand : brandsList){
				brands.put(String.valueOf(brand.getBrandId()), brand.getBrandName());
			}
		}
		return brands.get(id);
	}
	
	public String getBrandByName(String name){
		if(name == null || name.isEmpty()) return null;
		if(brands == null){
			brands = new HashMap<>();
			List<Brands> brandsList = brandsDao.findAll();
			for(Brands brand : brandsList){
				brands.put(String.valueOf(brand.getBrandId()), brand.getBrandName());
			}
		}
		
		String key = null;
		for(Entry<String,String> entry : brands.entrySet()){
			if(entry.getValue().equalsIgnoreCase(name)){
				key = entry.getKey(); 
				break;
			}
		}
		return key;
	}
	public String getCategoryByName(String name){
		if(name == null || name.isEmpty()) return null;
		if(categories == null){
			categories = new HashMap<>();
			List<Categories> cList = categoriesDao.findAll();
			for(Categories category : cList){
				categories.put(String.valueOf(category.getCategoryId()), category.getCategoryName());
			}
		}
		
		String key = null;
		for(Entry<String,String> entry : categories.entrySet()){
			if(entry.getValue().equalsIgnoreCase(name)){
				key = entry.getKey(); 
				break;
			}
		}
		return key;
	}
	public String getAttributeByName(String name){
		if(name == null || name.isEmpty()) return null;
		if(attributes == null){
			attributes = new HashMap<>();
			List<Attributes> attributesList = attributesDAO.findAll();
			for(Attributes attribute : attributesList){
				attributes.put(String.valueOf(attribute.getAttributeId()), attribute.getAttributeName());
			}
		}
		
		String key = null;
		for(Entry<String,String> entry : attributes.entrySet()){
			if(entry.getValue().equalsIgnoreCase(name)){
				key = entry.getKey(); 
				break;
			}
		}
		return key;
	}
	public String getCategoriesById(String id){
		if(id == null) return null;
		if(categories == null){
			categories = new HashMap<>();
			List<Categories> catList = categoriesDao.findAll();
			for(Categories cat : catList){
				categories.put(String.valueOf(cat.getCategoryId()), cat.getCategoryName());
			}
		}
		return categories.get(id);
	}
	public String getAttributeById(String id){
		if(id == null) return null;
		if(attributes == null){
			attributes = new HashMap<>();
			List<Attributes> attributesList = attributesDAO.findAll();
			for(Attributes cat : attributesList){
				attributes.put(String.valueOf(cat.getAttributeId()), cat.getAttributeName());
			}
		}
		return attributes.get(id);
	}
	public boolean hasBrand(String name){
		if(name == null) return false;
		if(brands == null || brands.isEmpty()){
			brands = new HashMap<>();
			List<Brands> brandsList = brandsDao.findAll();
			for(Brands brand : brandsList){
				brands.put(String.valueOf(brand.getBrandId()), brand.getBrandName());
			}
		}
		return brands.containsValue(name);
	}
	
	public boolean hasCategory(String name){
		if(name == null) return false;
		if(categories == null){
			categories = new HashMap<>();
			List<Categories> catList = categoriesDao.findAll();
			for(Categories cat : catList){
				categories.put(String.valueOf(cat.getCategoryId()), cat.getCategoryName());
			}
		}
		return categories.containsValue(name);
	}
	public boolean hasAttribute(String name){
		if(name == null) return false;
		if(attributes == null){
			attributes = new HashMap<>();
			List<Attributes> catList = attributesDAO.findAll();
			for(Attributes cat : catList){
				attributes.put(String.valueOf(cat.getAttributeId()), cat.getAttributeName());
			}
		}
		return attributes.containsValue(name);
	}
	public int getSize(String type){
		if(type != null){
			if(type.equals(BibakartConstants.BRANDS))
					if(brands != null)
						return brands.size();
			if(type.equals(BibakartConstants.CATEGORIES))
				if(categories != null)
					return categories.size();
			if(type.equals(BibakartConstants.ATTRIBUTES))
				if(attributes != null)
					return attributes.size();
		}
		return 0;
	}
	
	public void clearCache(String type){
		if(type != null){
			if(type.equals(BibakartConstants.BRANDS))
					if(brands != null)
						brands.clear();
			if(type.equals(BibakartConstants.CATEGORIES))
				if(categories != null)
					categories.clear();
			if(type.equals(BibakartConstants.ATTRIBUTES))
				if(attributes != null)
					attributes.clear();
		} 
	}
	
	
}
