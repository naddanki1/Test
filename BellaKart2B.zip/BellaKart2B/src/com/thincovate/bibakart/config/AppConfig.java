package com.thincovate.bibakart.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.accept.ContentNegotiationManager;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.HandlerMapping;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;
import org.springframework.web.servlet.handler.AbstractHandlerMapping;
import org.springframework.web.servlet.view.ContentNegotiatingViewResolver;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;

import com.thincovate.bibakart.common.interceptors.TokenInterceptor;
import com.thincovate.bibakart.sessionmgnt.services.SessionMngtService;
import com.thincovate.bibakart.sessionmgnt.services.impl.SessionMgntServiceImpl;

@Configuration
@ComponentScan(basePackages = "com.thincovate.bibakart")
public class AppConfig extends WebMvcConfigurationSupport {
	
	@Bean
	public SessionMngtService sessionMgntService(){
		return new SessionMgntServiceImpl();
	}
	
	@Bean
	public MultipartResolver multipartResolver() {
		CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver();
		multipartResolver.setMaxUploadSize(1000000000);
		return multipartResolver;
	}

	@Bean
	public ViewResolver viewResolver() {
		InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
		viewResolver.setViewClass(JstlView.class);
		viewResolver.setPrefix("/WEB-INF/views/");
		viewResolver.setSuffix(".jsp");
		return viewResolver;
	}

	@Bean
	public MessageSource messageSource() {
		ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
		messageSource.setBasename("messages");
		return messageSource;
	}

	@Override
	public void addResourceHandlers(final ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/css/**").addResourceLocations("/css/").setCachePeriod(31556926);
		registry.addResourceHandler("/images/**").addResourceLocations("/images/").setCachePeriod(31556926);
		registry.addResourceHandler("/js/**").addResourceLocations("/js/").setCachePeriod(31556926);
		registry.addResourceHandler("/fonts/**").addResourceLocations("/fonts/").setCachePeriod(31556926);
	}

	@Override
	@Bean
	public HandlerMapping resourceHandlerMapping() {
		AbstractHandlerMapping handlerMapping = (AbstractHandlerMapping) super.resourceHandlerMapping();
		handlerMapping.setOrder(-1);
		handlerMapping.setInterceptors(getInterceptors());
		return handlerMapping;
	}

	@Override
	public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {
		configurer.enable();
	}
	@Bean  
    public ViewResolver contentNegotiatingViewResolver( ContentNegotiationManager manager) {  
            List< ViewResolver > resolvers = new ArrayList< ViewResolver >();  
            InternalResourceViewResolver r1 = new InternalResourceViewResolver();  
            r1.setPrefix("/WEB-INF/views/");  
            r1.setSuffix(".jsp");  
            r1.setViewClass(JstlView.class);  
            resolvers.add(r1);  
            /*JsonViewResolver r2 = new JsonViewResolver();
            resolvers.add((ViewResolver) r2);  */
            ContentNegotiatingViewResolver resolver = new ContentNegotiatingViewResolver();  
            resolver.setViewResolvers(resolvers);  
            resolver.setContentNegotiationManager(manager);  
            return resolver;  
    } 
	protected void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
        converters.add(converter());
        addDefaultHttpMessageConverters(converters);
    }

    @Bean
    MappingJackson2HttpMessageConverter converter() {
    	MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        //do your customizations here...
        return converter;
    }
    @Override
	public void addInterceptors(InterceptorRegistry registry) {
	    registry.addInterceptor(new TokenInterceptor(sessionMgntService())).addPathPatterns("/**");
	}
}