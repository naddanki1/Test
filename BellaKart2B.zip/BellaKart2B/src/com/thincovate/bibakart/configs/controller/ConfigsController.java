/**
 * 
 */
package com.thincovate.bibakart.configs.controller;

import java.text.ParseException;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.thincovate.bibakart.common.model.ResponseWrapper;
import com.thincovate.bibakart.configs.services.ConfigsServicesI;

/**
 * @author Sandeep
 *
 */
@RestController
public class ConfigsController {

	@Autowired
	private ConfigsServicesI configsService;
	
	static Logger log = Logger.getLogger(ConfigsController.class);
	
/*	// Save configs
	@RequestMapping(method = RequestMethod.POST, value = "/configs", consumes = "application/json")
	public @ResponseBody ResponseWrapper saveConfigs(@RequestBody Configurations conf, HttpServletRequest req) throws ParseException {

		ResponseWrapper response = null;
		log.info("Save configs - starts");
		response = configsService.save(conf);
		log.info("Save configs - Done");
		return response;
	}
	
	// update configs
	@RequestMapping(method = RequestMethod.PUT, value = "/configs", consumes = "application/json")
	public @ResponseBody ResponseWrapper updateConfigs(@RequestBody Configurations conf, HttpServletRequest req) throws ParseException {

		ResponseWrapper response = null;
		log.info("Save configs - starts");
		response = configsService.save(conf);
		log.info("Save configs - Done");
		return response;
	}
	
	// update configs
	@RequestMapping(method = RequestMethod.PUT, value = "/configurations", consumes = "application/json")
	public @ResponseBody ResponseWrapper updateConfigurations(@RequestBody Configs conf, HttpServletRequest req) throws ParseException {

		ResponseWrapper response = null;
		log.info("Save configs - starts");
		response = configsService.updateConfigs(conf);
		log.info("Save configs - Done");
		return response;
	}*/
	
	// Find/search configs
	@RequestMapping(method = RequestMethod.GET, value = "/configs")
	public ResponseWrapper findAllConfigs(HttpServletRequest req) throws ParseException {
		ResponseWrapper response = null;
		log.info("Get configs - starts");
		response = configsService.getAllConfigs();
		log.info("Get configs - Done");
		return response;
	
	}
}
