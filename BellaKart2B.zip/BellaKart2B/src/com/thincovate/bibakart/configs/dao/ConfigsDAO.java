package com.thincovate.bibakart.configs.dao;

import org.springframework.stereotype.Repository;

import com.thincovate.bibakart.configs.vo.Configurations;
import com.thincovate.bibakart.dao.AbstractHibernateDAO;

/**
 * @author Sandeep
 *
 */
@Repository
public class ConfigsDAO extends AbstractHibernateDAO<Configurations> {

	public ConfigsDAO() {
		setClazz(Configurations.class);
	}

}
