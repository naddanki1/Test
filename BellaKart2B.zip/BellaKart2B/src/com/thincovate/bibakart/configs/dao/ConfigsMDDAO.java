package com.thincovate.bibakart.configs.dao;

import org.springframework.stereotype.Repository;

import com.thincovate.bibakart.configs.vo.Configs;
import com.thincovate.bibakart.dao.AbstractHibernateDAO;

@Repository
public class ConfigsMDDAO extends AbstractHibernateDAO<Configs> {

	public ConfigsMDDAO() {
		setClazz(Configs.class);
	}
}
