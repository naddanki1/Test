/**
 * 
 */
package com.thincovate.bibakart.configs.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.thincovate.bibakart.common.exceptions.DataAccessLayerException;
import com.thincovate.bibakart.common.model.ConfigsResponseWrapper;
import com.thincovate.bibakart.common.model.ResponseWrapper;
import com.thincovate.bibakart.common.utils.Responses;
import com.thincovate.bibakart.configs.dao.ConfigsDAO;
import com.thincovate.bibakart.configs.vo.Configuration;
import com.thincovate.bibakart.configs.vo.Configurations;

/**
 * @author Sandeep
 *
 */
@Service
@Transactional
public class ConfigServicesImpl implements ConfigsServicesI {

	@Autowired
	private ConfigsDAO configsDao;

	private static Logger log = Logger.getLogger(ConfigServicesImpl.class);

	private static Map<String, Map<String, String>> mdConfigs = null;
	private static Map<String, String> configs = new HashMap<String,String>();
	private static List<Configuration> configsList = null;

	public ResponseWrapper save(Configurations config) {
		ResponseWrapper response = null;
		try {
			configsDao.save(config);
			response = new ResponseWrapper();
			response.setCode(Responses.SUCCESS_CODE);
			response.setStatus(Responses.SUCCESS_STATUS);
			response.setMessage(Responses.SUCCESS_MSG);
		} catch (DataAccessLayerException dale) {
			dale.printStackTrace();
			response = new ResponseWrapper();
			response.setCode(Responses.FAILURE_CODE);
			response.setStatus(Responses.FAILURE_STATUS);
			response.setMessage(Responses.FAILURE_MSG);
		}

		return response;
	}

	public List<Configuration> getConfigurationList(List<Configurations> configurations) {
		List<Configuration> configs = new ArrayList<Configuration>();

		for (Configurations c : configurations) {
			Configuration configuration = new Configuration();
			configuration.setId(c.getConfigId() + "");
			configuration.setKey(c.getConfigs().getTitle());
			configuration.setType(c.getConfigs().getConfigType());
			Object o = parseConfigValue(c);
			configuration.setValue((o == null) ? "" : o.toString());
			configs.add(configuration);
		}
		return configs;
	}

	private Object parseConfigValue(Configurations configurations) {
		String column = configurations.getConfigs().getColumn();
		switch (column) {
		case "column0":
			return configurations.getColumn0();
		case "column1":
			return configurations.getColumn1();
		case "column2":
			return configurations.getColumn2();
		case "column3":
			return configurations.getColumn3();
		case "column4":
			return configurations.getColumn4();
		case "column5":
			return configurations.getColumn5();
		case "column6":
			return configurations.getColumn6();
		case "column7":
			return configurations.getColumn7();
		case "column8":
			return configurations.getColumn8();
		case "column9":
			return configurations.getColumn9();
		case "column10":
			return configurations.getColumn10();
		case "column11":
			return configurations.getColumn11();
		case "column12":
			return configurations.getColumn12();
		case "column13":
			return configurations.getColumn13();
		case "column14":
			return configurations.getColumn14();
		case "column15":
			return configurations.getColumn15();
		case "column16":
			return configurations.getColumn16();
		case "column17":
			return configurations.getColumn17();
		case "column18":
			return configurations.getColumn18();
		case "column19":
			return configurations.getColumn19();
		case "column20":
			return configurations.getColumn20();
		case "column21":
			return configurations.getColumn21();
		case "column22":
			return configurations.getColumn22();
		case "column23":
			return configurations.getColumn23();
		case "column24":
			return configurations.getColumn24();
		case "column25":
			return configurations.getColumn25();
		case "column26":
			return configurations.getColumn26();
		case "column27":
			return configurations.getColumn27();
		case "column28":
			return configurations.getColumn28();
		case "column29":
			return configurations.getColumn29();
		case "column30":
			return configurations.getColumn30();
		case "column31":
			return configurations.getColumn31();
		case "column32":
			return configurations.getColumn32();
		case "column33":
			return configurations.getColumn33();
		case "column34":
			return configurations.getColumn34();
		case "column35":
			return configurations.getColumn35();
		case "column36":
			return configurations.getColumn36();
		case "column37":
			return configurations.getColumn37();
		case "column38":
			return configurations.getColumn38();
		case "column39":
			return configurations.getColumn39();
		case "column40":
			return configurations.getColumn40();
		case "column41":
			return configurations.getColumn41();
		case "column42":
			return configurations.getColumn42();
		case "column43":
			return configurations.getColumn43();
		case "column44":
			return configurations.getColumn44();
		case "column45":
			return configurations.getColumn45();
		case "column46":
			return configurations.getColumn46();
		case "column47":
			return configurations.getColumn47();
		case "column48":
			return configurations.getColumn48();
		case "column49":
			return configurations.getColumn49();
		case "column50":
			return configurations.getColumn50();

		default:
			break;
		}
		return null;
	}

	private void initConfigs() {
		List<Configurations> configurations = configsDao.findAll();
		configsList = getConfigurationList(configurations);
		if(configs == null || configs.isEmpty()){
			for(Configuration c :  configsList)
				configs.put(c.getKey(), c.getValue());
		}
	}

/*	public void resetConfigsMD() {
		if (configs != null) {
			configs.clear();
			configs = null;
		}
	}*/

	public void resetConfigs() {
		if (mdConfigs != null) {
			mdConfigs.clear();
			mdConfigs = null;
		}
	}

	@Override
	public ResponseWrapper getAllConfigs() {
		ConfigsResponseWrapper response = new ConfigsResponseWrapper();
		try {
			if(configs == null)
				initConfigs();
				response.setCode(Responses.SUCCESS_CODE);
				response.setStatus(Responses.SUCCESS_STATUS);
				response.setMessage(Responses.SUCCESS_MSG);
				response.setConfigs(configsList);
		} catch (Exception e) {
			e.printStackTrace();
			response.setCode(Responses.FAILURE_CODE);
			response.setStatus(Responses.FAILURE_STATUS);
			response.setMessage(Responses.FAILURE_MSG);
		}
		return response;
	}
	
	@Override
	public String getValueByKey(String key){
		if(configs == null || configs.isEmpty())
			initConfigs();
		return configs.get(key);
	}
}
