/**
 * 
 */
package com.thincovate.bibakart.configs.services;

import com.thincovate.bibakart.common.model.ResponseWrapper;

/**
 * @author Sandeep
 *
 */
public interface ConfigsServicesI {

	// ResponseWrapper save(Configurations config);

	// ResponseWrapper updateConfigs(Configs config);

	// Configurations findByKey(String key);

	ResponseWrapper getAllConfigs();

	String getValueByKey(String key);
	

}
