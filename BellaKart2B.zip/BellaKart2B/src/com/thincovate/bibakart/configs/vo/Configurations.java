package com.thincovate.bibakart.configs.vo;

import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "configurations")
public class Configurations implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "config_id")
	private Integer configId;

	@ManyToOne
	@JoinColumn(name = "config_type")
	private Configs configs;

	@Column(name = "column0")
	private String column0;

	@Column(name = "column1")
	private String column1;

	@Column(name = "column2")
	private String column2;

	@Column(name = "column3")
	private String column3;

	@Column(name = "column4")
	private String column4;

	@Column(name = "column5")
	private String column5;

	@Column(name = "column6")
	private String column6;

	@Column(name = "column7")
	private String column7;

	@Column(name = "column8")
	private String column8;

	@Column(name = "column9")
	private String column9;

	@Column(name = "column10")
	private String column10;

	@Column(name = "column11")
	private String column11;

	@Column(name = "column12")
	private String column12;

	@Column(name = "column13")
	private String column13;

	@Column(name = "column14")
	private String column14;

	@Column(name = "column15")
	private Integer column15;

	@Column(name = "column16")
	private Integer column16;

	@Column(name = "column17")
	private Integer column17;

	@Column(name = "column18")
	private Integer column18;

	@Column(name = "column19")
	private Integer column19;

	@Column(name = "column20")
	private Integer column20;

	@Column(name = "column21")
	private Integer column21;

	@Column(name = "column22")
	private Integer column22;

	@Column(name = "column23")
	private Integer column23;

	@Column(name = "column24")
	private Integer column24;

	@Column(name = "column25")
	private Integer column25;

	@Column(name = "column26")
	private Integer column26;

	@Column(name = "column27")
	private Integer column27;

	@Column(name = "column28")
	private Integer column28;

	@Column(name = "column29")
	private Integer column29;

	@Column(name = "column30")
	private Integer column30;

	@Column(name = "column31")
	private Integer column31;

	@Column(name = "column32")
	private Integer column32;

	@Column(name = "column33")
	private Integer column33;

	@Column(name = "column34")
	private Integer column34;

	@Column(name = "column35")
	private Double column35;

	@Column(name = "column36")
	private Double column36;

	@Column(name = "column37")
	private Double column37;

	@Column(name = "column38")
	private Double column38;

	@Column(name = "column39")
	private Double column39;

	@Column(name = "column40")
	private Double column40;

	@Column(name = "column41")
	private Double column41;

	@Column(name = "column42")
	private Double column42;

	@Column(name = "column43")
	private Double column43;

	@Column(name = "column44")
	private Double column44;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "column45")
	private Date column45;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "column46")
	private Date column46;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "column47")
	private Date column47;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "column48")
	private Date column48;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "column49")
	private Date column49;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "column50")
	private Date column50;

	public Integer getConfigId() {
		return configId;
	}

	public void setConfigId(Integer configId) {
		this.configId = configId;
	}

	public Configs getConfigs() {
		return configs;
	}

	public void setConfigs(Configs configs) {
		this.configs = configs;
	}

	public String getColumn0() {
		return column0;
	}

	public void setColumn0(String column0) {
		this.column0 = column0;
	}

	public String getColumn1() {
		return column1;
	}

	public void setColumn1(String column1) {
		this.column1 = column1;
	}

	public String getColumn2() {
		return column2;
	}

	public void setColumn2(String column2) {
		this.column2 = column2;
	}

	public String getColumn3() {
		return column3;
	}

	public void setColumn3(String column3) {
		this.column3 = column3;
	}

	public String getColumn4() {
		return column4;
	}

	public void setColumn4(String column4) {
		this.column4 = column4;
	}

	public String getColumn5() {
		return column5;
	}

	public void setColumn5(String column5) {
		this.column5 = column5;
	}

	public String getColumn6() {
		return column6;
	}

	public void setColumn6(String column6) {
		this.column6 = column6;
	}

	public String getColumn7() {
		return column7;
	}

	public void setColumn7(String column7) {
		this.column7 = column7;
	}

	public String getColumn8() {
		return column8;
	}

	public void setColumn8(String column8) {
		this.column8 = column8;
	}

	public String getColumn9() {
		return column9;
	}

	public void setColumn9(String column9) {
		this.column9 = column9;
	}

	public String getColumn10() {
		return column10;
	}

	public void setColumn10(String column10) {
		this.column10 = column10;
	}

	public String getColumn11() {
		return column11;
	}

	public void setColumn11(String column11) {
		this.column11 = column11;
	}

	public String getColumn12() {
		return column12;
	}

	public void setColumn12(String column12) {
		this.column12 = column12;
	}

	public String getColumn13() {
		return column13;
	}

	public void setColumn13(String column13) {
		this.column13 = column13;
	}

	public String getColumn14() {
		return column14;
	}

	public void setColumn14(String column14) {
		this.column14 = column14;
	}

	public Integer getColumn15() {
		return column15;
	}

	public void setColumn15(Integer column15) {
		this.column15 = column15;
	}

	public Integer getColumn16() {
		return column16;
	}

	public void setColumn16(Integer column16) {
		this.column16 = column16;
	}

	public Integer getColumn17() {
		return column17;
	}

	public void setColumn17(Integer column17) {
		this.column17 = column17;
	}

	public Integer getColumn18() {
		return column18;
	}

	public void setColumn18(Integer column18) {
		this.column18 = column18;
	}

	public Integer getColumn19() {
		return column19;
	}

	public void setColumn19(Integer column19) {
		this.column19 = column19;
	}

	public Integer getColumn20() {
		return column20;
	}

	public void setColumn20(Integer column20) {
		this.column20 = column20;
	}

	public Integer getColumn21() {
		return column21;
	}

	public void setColumn21(Integer column21) {
		this.column21 = column21;
	}

	public Integer getColumn22() {
		return column22;
	}

	public void setColumn22(Integer column22) {
		this.column22 = column22;
	}

	public Integer getColumn23() {
		return column23;
	}

	public void setColumn23(Integer column23) {
		this.column23 = column23;
	}

	public Integer getColumn24() {
		return column24;
	}

	public void setColumn24(Integer column24) {
		this.column24 = column24;
	}

	public Integer getColumn25() {
		return column25;
	}

	public void setColumn25(Integer column25) {
		this.column25 = column25;
	}

	public Integer getColumn26() {
		return column26;
	}

	public void setColumn26(Integer column26) {
		this.column26 = column26;
	}

	public Integer getColumn27() {
		return column27;
	}

	public void setColumn27(Integer column27) {
		this.column27 = column27;
	}

	public Integer getColumn28() {
		return column28;
	}

	public void setColumn28(Integer column28) {
		this.column28 = column28;
	}

	public Integer getColumn29() {
		return column29;
	}

	public void setColumn29(Integer column29) {
		this.column29 = column29;
	}

	public Integer getColumn30() {
		return column30;
	}

	public void setColumn30(Integer column30) {
		this.column30 = column30;
	}

	public Integer getColumn31() {
		return column31;
	}

	public void setColumn31(Integer column31) {
		this.column31 = column31;
	}

	public Integer getColumn32() {
		return column32;
	}

	public void setColumn32(Integer column32) {
		this.column32 = column32;
	}

	public Integer getColumn33() {
		return column33;
	}

	public void setColumn33(Integer column33) {
		this.column33 = column33;
	}

	public Integer getColumn34() {
		return column34;
	}

	public void setColumn34(Integer column34) {
		this.column34 = column34;
	}

	public Double getColumn35() {
		return column35;
	}

	public void setColumn35(Double column35) {
		this.column35 = column35;
	}

	public Double getColumn36() {
		return column36;
	}

	public void setColumn36(Double column36) {
		this.column36 = column36;
	}

	public Double getColumn37() {
		return column37;
	}

	public void setColumn37(Double column37) {
		this.column37 = column37;
	}

	public Double getColumn38() {
		return column38;
	}

	public void setColumn38(Double column38) {
		this.column38 = column38;
	}

	public Double getColumn39() {
		return column39;
	}

	public void setColumn39(Double column39) {
		this.column39 = column39;
	}

	public Double getColumn40() {
		return column40;
	}

	public void setColumn40(Double column40) {
		this.column40 = column40;
	}

	public Double getColumn41() {
		return column41;
	}

	public void setColumn41(Double column41) {
		this.column41 = column41;
	}

	public Double getColumn42() {
		return column42;
	}

	public void setColumn42(Double column42) {
		this.column42 = column42;
	}

	public Double getColumn43() {
		return column43;
	}

	public void setColumn43(Double column43) {
		this.column43 = column43;
	}

	public Double getColumn44() {
		return column44;
	}

	public void setColumn44(Double column44) {
		this.column44 = column44;
	}

	public Date getColumn45() {
		return column45;
	}

	public void setColumn45(Date column45) {
		this.column45 = column45;
	}

	public Date getColumn46() {
		return column46;
	}

	public void setColumn46(Date column46) {
		this.column46 = column46;
	}

	public Date getColumn47() {
		return column47;
	}

	public void setColumn47(Date column47) {
		this.column47 = column47;
	}

	public Date getColumn48() {
		return column48;
	}

	public void setColumn48(Date column48) {
		this.column48 = column48;
	}

	public Date getColumn49() {
		return column49;
	}

	public void setColumn49(Date column49) {
		this.column49 = column49;
	}

	public Date getColumn50() {
		return column50;
	}

	public void setColumn50(Date column50) {
		this.column50 = column50;
	}

}
