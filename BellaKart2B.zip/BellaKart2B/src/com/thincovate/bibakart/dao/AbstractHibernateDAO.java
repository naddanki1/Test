package com.thincovate.bibakart.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.base.Preconditions;
import com.thincovate.bibakart.common.utils.BibakartConstants;
import com.thincovate.bibakart.payments.model.SellerPayments;

@Repository
@Transactional
public abstract class AbstractHibernateDAO<T extends Serializable> {

	private Class<T> clazz;

	@Autowired
	SessionFactory sessionFactory;

	public void setClazz(final Class<T> clazzToSet) {

		clazz = clazzToSet;

	}

	@SuppressWarnings("unchecked")
	public T findOne(final String id) {

		Preconditions.checkArgument(id != null);

		return (T) getCurrentSession().get(clazz, id);

	}

	@SuppressWarnings("unchecked")
	public T findOne(final long id) {

		Preconditions.checkArgument(id != 0);

		return (T) getCurrentSession().get(clazz, id);

	}

	@SuppressWarnings("unchecked")
	public T findOne(final Long id) {

		Preconditions.checkArgument(id != 0);

		return (T) getCurrentSession().get(clazz, id);

	}

	@SuppressWarnings("unchecked")
	public T findOne(final int id) {

		Preconditions.checkArgument(id != 0);

		return (T) getCurrentSession().get(clazz, id);

	}

	@SuppressWarnings("unchecked")
	public T findOne(final Integer id) {

		Preconditions.checkArgument(id != 0);

		return (T) getCurrentSession().get(clazz, id);

	}
	public int getCount(String query){
		return ((Long)getCurrentSession().createQuery("select count(*) from " + clazz.getName()+query).uniqueResult()).intValue();
	}
	public String getTotalCount(String query){
		return getCurrentSession().createSQLQuery(query).list().get(0).toString();
	}
	@SuppressWarnings("unchecked")
	public List<T> findAll() {
		return getCurrentSession()	.createQuery("from " + clazz.getName()).list();
	}

	@SuppressWarnings("unchecked")
	public List<T> findAllByColumn(String column1, String value) {
		return getCurrentSession().createQuery("from " + clazz.getName() + " where " + column1 + "='" + value + "'")
				.list();
	}
	@SuppressWarnings("unchecked")
	public List<T> findAllByColumn(String column1, String value,int offset, int maxResults) {
		return getCurrentSession().createQuery("from " + clazz.getName() + " where " + column1 + "='" + value + "'").setFirstResult(offset).setMaxResults(maxResults)
				.list();
	}
	@SuppressWarnings("unchecked")
	public List<T> findAllByColumn(String column1, long value,String column2,String value2,int offset, int maxResults) {
		return getCurrentSession().createQuery("from " + clazz.getName() + " where " + column1 + "='" + value + "' and "+ column2 + "='" + value2 + "'").setFirstResult(offset).setMaxResults(maxResults)
				.list();
	}
	@SuppressWarnings("unchecked")
	public List<T> findAllByColumn(String column1, long value,int offset, int maxResults) {
		return getCurrentSession().createQuery("from " + clazz.getName() + " where " + column1 + "='" + value + "'").setFirstResult(offset).setMaxResults(maxResults)
				.list();
	}
	@SuppressWarnings("unchecked")
	public List<T> findAllByColumn(String column1, String value,String column2,String value2,int offset, int maxResults) {
		return getCurrentSession().createQuery("from " + clazz.getName() + " where " + column1 + "='" + value + "' and "+column2 + "='"+value2+"'").setFirstResult(offset).setMaxResults(maxResults)
				.list();
	}
	@SuppressWarnings("unchecked")
	public List<T> findAllByColumnNotEqual(String column1, String value,String column2,String value2,int offset, int maxResults) {
		return getCurrentSession().createQuery("from " + clazz.getName() + " where " + column1 + "='" + value + "' and "+column2 + "!='"+value2+"'").setFirstResult(offset).setMaxResults(maxResults)
				.list();
	}
	@SuppressWarnings("unchecked")
	public List<T> findAllByColumn(String column1, String value,String column2,int value2,int offset, int maxResults) {
		return getCurrentSession().createQuery("from " + clazz.getName() + " where " + column1 + "='" + value + "' and "+column2 + " "+value2).setFirstResult(offset).setMaxResults(maxResults)
				.list();
	}

	@SuppressWarnings("unchecked")
	public List<T> findAllByColumn(String column, Object value) {
		return getCurrentSession().createQuery("from " + clazz.getName() + " where " + column + "='" + value + "'")	.list();
	}

	@SuppressWarnings("unchecked")
	public T findOneByColumn(String column1, String value) {
		return (T) getCurrentSession().createQuery("from " + clazz.getName() + " where " + column1 + "='" + value + "'").uniqueResult();
	}

	@SuppressWarnings("unchecked")
	public List<T> findAllByColumn(String column1, String value, String column2, String value2, String condition) {
		ArrayList<T> list = (ArrayList<T>) getCurrentSession().createQuery("from " + clazz.getName() + " where "+ column1 + "='" + value + "' " + condition + " " + column2 + "='" + value2 + "'").list();
		return list;
	}

	@SuppressWarnings("unchecked")
	public T findOneByColumn(String column1, String value, String column2, String value2, String condition) {
		return (T) getCurrentSession().createQuery("from " + clazz.getName() + " where " + column1 + "='" + value + "' " + condition + " " + column2 + "='" + value2 + "'").uniqueResult();

	}

	@SuppressWarnings("unchecked")
	public List<T> findAllByColumn(String column1, String value, String column2, String value2, String column3,
			String value3, String condition) {
		return getCurrentSession().createQuery("from " + clazz.getName() + " where " + column1 + "='" + value + "' "
				+ condition + " " + column2 + "='" + value2 + "' " + condition + " " + column3 + "='" + value3 + "'")
				.list();
	}

	@SuppressWarnings("unchecked")
	public T findOneByColumn(String column1, String value, String column2, String value2, String column3, String value3,
			String condition) {
		return (T) getCurrentSession()
				.createQuery("from " + clazz.getName() + " where " + column1 + "='" + value + "' " + condition + " "
						+ column2 + "='" + value2 + "' " + condition + " " + column3 + "='" + value3 + "'")
				.uniqueResult();
	}

	@SuppressWarnings("unchecked")
	public List<T> findAllByColumn(String column1, String value, String column2, String value2, String column3,
			String value3, String column4, String value4, String condition) {
		ArrayList<T> list = (ArrayList<T>) getCurrentSession().createQuery("from " + clazz.getName() + " where "
				+ column1 + "='" + value + "' " + condition + " " + column2 + "='" + value2 + "' " + condition + " "
				+ column3 + "='" + value3 + "' " + condition + " " + column4 + "='" + value4 + "' ").list();

		return list;
	}

	@SuppressWarnings("unchecked")
	public T findOneByColumn(String column1, String value, String column2, String value2, String column3, String value3,
			String column4, String value4, String condition) {
		return (T) getCurrentSession().createQuery("from " + clazz.getName() + " where " + column1 + "='" + value + "' "
				+ condition + " " + column2 + "='" + value2 + "' " + condition + " " + column3 + "='" + value3 + "' "
				+ condition + " " + column4 + "='" + value4 + "' ").uniqueResult();

	}

	@SuppressWarnings("unchecked")
	public List<T> findAllByString(String queryString) {
		return getCurrentSession().createQuery("from " + clazz.getName() + " where " + queryString).list();
	}
	@SuppressWarnings("unchecked")
	public List<T> findAllByString(String queryString,int offset, int maxResults) {
		return getCurrentSession().createQuery("from " + clazz.getName() + " where " + queryString).setFirstResult(offset).setMaxResults(maxResults).list();
	}
	@SuppressWarnings("unchecked")
	public List<T> findAllByLike(String queryString) {
		return getCurrentSession().createQuery("from " + clazz.getName() + " where " + queryString).list();
	}

	@SuppressWarnings("unchecked")
	public List<T> findAllBylimit(String queryString, int startLimit, int EndLimit) {
		Query q = getCurrentSession().createQuery("from " + clazz.getName() + "  " + queryString);
		q.setFirstResult(startLimit);
		q.setMaxResults(EndLimit);
		return q.list();
	}

	@SuppressWarnings("unchecked")
	public List<T> findByLikeOrder(String queryString, int startLimit, int EndLimit) {
		Query q = getCurrentSession().createQuery("from " + clazz.getName() + "  " + queryString);
		q.setFirstResult(startLimit);
		q.setMaxResults(EndLimit);
		return q.list();
	}

	@SuppressWarnings("unchecked")
	public List<T> findAllByLimit(int startLimit, int EndLimit) {
		Query q = getCurrentSession().createQuery("from " + clazz.getName());
		q.setFirstResult(startLimit);
		q.setMaxResults(EndLimit);
		return q.list();
	}
	@SuppressWarnings("unchecked")
	public List<T> findAllByLimitNotEqColumn(String column,String value,int startLimit, int EndLimit) {
		Query q = getCurrentSession().createQuery("from " + clazz.getName()+"where "+column+"!='"+value+"'");
		q.setFirstResult(startLimit);
		q.setMaxResults(EndLimit);
		return q.list();
	}
	@SuppressWarnings("unchecked")
	public List<T> findAllByLimit(String column,String value,int startLimit, int EndLimit) {
		Query q = getCurrentSession().createQuery("from " + clazz.getName()+ " where " + column + "='" + value + "' ");
		q.setFirstResult(startLimit);
		q.setMaxResults(EndLimit);
		return q.list();
	}

	public void save(final T entity) {

		Preconditions.checkNotNull(entity);

		getCurrentSession().persist(entity);

	}

	public void update(final T entity) {

		Preconditions.checkNotNull(entity);

		getCurrentSession().merge(entity);

	}

	public void saveOrupdate(final T entity) {

		/* Preconditions.checkNotNull(entity); */

		getCurrentSession().saveOrUpdate(entity);

	}

	public void delete(final T entity) {

		Preconditions.checkNotNull(entity);

		getCurrentSession().delete(entity);

	}

	public void deleteById(final String entityId) {

		final T entity = findOne(entityId);

		Preconditions.checkState(entity != null);

		delete(entity);

	}

	public void deleteById(final int entityId) {

		final T entity = findOne(entityId);

		Preconditions.checkState(entity != null);

		delete(entity);

	}

	public void deleteById(final long entityId) {

		final T entity = findOne(entityId);

		Preconditions.checkState(entity != null);

		delete(entity);

	}

	protected final Session getCurrentSession() {

		return sessionFactory.getCurrentSession();

	}

	@SuppressWarnings("unchecked")
	public List<T> search(String keyword) {
		Criteria c = getCurrentSession().createCriteria(clazz);
		c.add(Restrictions.ne(BibakartConstants.AVAILABLE_STATUS, BibakartConstants.STATUS_OBSELETE));
		Criterion c1 = Restrictions.ilike(BibakartConstants.SKU_ID, keyword, MatchMode.ANYWHERE);
		Criterion c2 = Restrictions.ilike(BibakartConstants.SEARCH_KEYWORDS, keyword, MatchMode.ANYWHERE);
		//Criterion c3 = Restrictions.ilike(BellakartConstants.PRODUCT_DESC, keyword, MatchMode.ANYWHERE);
		Criterion c4 = Restrictions.ilike(BibakartConstants.PRODUCT_TITLE, keyword, MatchMode.ANYWHERE);
		Criterion c5 = Restrictions.ilike(BibakartConstants.SELLER_PRODUCT_ID, keyword, MatchMode.ANYWHERE);
		Criterion c6 = Restrictions.ilike(BibakartConstants.CATEGORY_NAME, keyword, MatchMode.ANYWHERE);
		Criterion c7 = Restrictions.ilike(BibakartConstants.SELLING_PRICE, keyword, MatchMode.ANYWHERE);
		Disjunction disjunction = Restrictions.disjunction();
		disjunction.add(c1);
		disjunction.add(c2);
		//disjunction.add(c3);
		disjunction.add(c4);
		disjunction.add(c5);
		disjunction.add(c6);
		disjunction.add(c7);

		c.add(disjunction);
		return c.list();

	}

	@SuppressWarnings("unchecked")
	public List<T> searchSellerProducts(String keyword) {
		Criteria c = getCurrentSession().createCriteria(clazz);
		c.add(Restrictions.ne(BibakartConstants.AVAILABLE_STATUS, BibakartConstants.STATUS_OBSELETE));
		Criterion c1 = Restrictions.ilike(BibakartConstants.SKU_ID, keyword, MatchMode.ANYWHERE);
		Criterion c2 = Restrictions.ilike(BibakartConstants.PRODUCT_TITLE, keyword, MatchMode.ANYWHERE);
		Criterion c3 = Restrictions.ilike(BibakartConstants.SELLER_PRODUCT_ID, keyword, MatchMode.ANYWHERE);
		Criterion c4 = Restrictions.ilike(BibakartConstants.SELLER_ID, keyword, MatchMode.ANYWHERE);
		Criterion c5 = Restrictions.ilike(BibakartConstants.STORE_DISPLAY_NAME, keyword, MatchMode.ANYWHERE);
		Disjunction disjunction = Restrictions.disjunction();
		disjunction.add(c1);
		disjunction.add(c2);
		disjunction.add(c3);
		disjunction.add(c4);
		disjunction.add(c5);

		c.add(disjunction);
		return c.list();

	}
	@SuppressWarnings("unchecked")
	public List<T> searchUsingId(String keyword, String sellerId) {
		Criteria c = getCurrentSession().createCriteria(clazz);
		c.add(Restrictions.like(BibakartConstants.SELLER_ID, sellerId));
		c.add(Restrictions.ne(BibakartConstants.AVAILABLE_STATUS, BibakartConstants.STATUS_OBSELETE));
		Criterion c1 = Restrictions.ilike(BibakartConstants.SKU_ID, keyword, MatchMode.ANYWHERE);
		//Criterion c3 = Restrictions.ilike(BellakartConstants.PRODUCT_DESC, keyword, MatchMode.ANYWHERE);
		Criterion c4 = Restrictions.ilike(BibakartConstants.PRODUCT_TITLE, keyword, MatchMode.ANYWHERE);
		Criterion c5 = Restrictions.ilike(BibakartConstants.SELLER_PRODUCT_ID, keyword, MatchMode.ANYWHERE);
		Criterion c6 = Restrictions.ilike(BibakartConstants.CATEGORY_NAME, keyword, MatchMode.ANYWHERE);
		Criterion c7 = Restrictions.ilike(BibakartConstants.SELLING_PRICE, keyword, MatchMode.ANYWHERE);
		Criterion c2 = Restrictions.ilike(BibakartConstants.SEARCH_KEYWORDS, keyword, MatchMode.ANYWHERE);
		Disjunction disjunction = Restrictions.disjunction();
		disjunction.add(c1);
		disjunction.add(c2);
		//disjunction.add(c3);
		disjunction.add(c4);
		disjunction.add(c5);
		disjunction.add(c6);
		disjunction.add(c7);
		c.add(disjunction);
		return c.list();

	}

	@SuppressWarnings("unchecked")
	public List<T> findByValue(String value) {
		Criteria c = getCurrentSession().createCriteria(clazz);
		c.add(Restrictions.ilike("storeDisplayName", value, MatchMode.EXACT));
		return c.list();
	}
	
	@SuppressWarnings("unchecked")
	public List<T> searchSellers(String column1, String value, String column2, String value2, String column3, String value3,
			String column4, String value4, String condition) {
		return getCurrentSession().createQuery("from " + clazz.getName() + " where " + column1 + " LIKE '%" + value + "%' "
				+ condition + " " + column2 + " LIKE '%" + value2 + "%' " + condition + " " + column3 + " LIKE '%" + value3 + "%' "
				+ condition + " " + column4 + " LIKE '%" + value4 + "%' ").list();

	}
	public void flushSession(){
			getCurrentSession().flush();
			getCurrentSession().clear();
	}
	
	@SuppressWarnings({ "rawtypes" })
	public List findByProjection(String filterColumn,Object value,String column1,String Column2){
		Criteria c = getCurrentSession().createCriteria(clazz);
		c.add(Restrictions.like(filterColumn, value));
		c.setProjection(Projections.property(column1));
		c.setProjection(Projections.property(Column2));
		return c.list();
	}
	@SuppressWarnings("unchecked")
	public List<T> findAllByColumn(String column1, long value, String column2, int value2,String condition) {
	
		return getCurrentSession().createQuery("from " + clazz.getName() + " where "+ column1 + "='" + value + "' " + condition + " " + column2 + "='" + value2 + "'").list();
	}
	
	@SuppressWarnings("unchecked")
	public List<Object[]> findReqColumn(String queryString,int offset, int maxResults) {
	Query query=	 getCurrentSession().createSQLQuery(queryString).setFirstResult(offset).setMaxResults(maxResults);
	System.out.println(query.getQueryString());
		 return query.list();
	}
	
}