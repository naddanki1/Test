/**
 * 
 */
package com.thincovate.bibakart.entitymodels;

import org.springframework.web.multipart.commons.CommonsMultipartFile;

/**
 * @author Sandeep
 *
 */
public class BulkUploadModel {
	
	private CommonsMultipartFile excelFile;
	private CommonsMultipartFile zipFile;
	/**
	 * @return the excelFile
	 */
	public CommonsMultipartFile getExcelFile() {
		return excelFile;
	}
	/**
	 * @param excelFile the excelFile to set
	 */
	public void setExcelFile(CommonsMultipartFile excelFile) {
		this.excelFile = excelFile;
	}
	/**
	 * @return the zipFile
	 */
	public CommonsMultipartFile getZipFile() {
		return zipFile;
	}
	/**
	 * @param zipFile the zipFile to set
	 */
	public void setZipFile(CommonsMultipartFile zipFile) {
		this.zipFile = zipFile;
	}
	
}
