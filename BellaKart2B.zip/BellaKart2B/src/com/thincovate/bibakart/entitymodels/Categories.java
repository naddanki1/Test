 package com.thincovate.bibakart.entitymodels;

// Generated 13 Aug, 2015 7:05:12 PM by Hibernate Tools 3.4.0.CR1

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;


@Entity
@Table(name = "categories")
public class Categories implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4745087186228219804L;
	private Long categoryId;
	private String categoryName;
	private String categoryDesc;
	private long parentCategoryId;
	private Boolean isMainCategory;
	private String status;
	private Date createdDate;
	private Date modifiedDate;
	private String createdBy;
	private String modifiedBy;
	private Set<SellerMaster> sellerMasters = new HashSet<SellerMaster>(0);
	private Set<Products> productses = new HashSet<Products>(0);
	private MarketingCharges marketingCharges;

	public Categories() {
	}

	public Categories(String categoryName, String categoryDesc,
			long parentCategoryId, String status, Date createdDt,
			String createdBy) {
		this.categoryName = categoryName;
		this.categoryDesc = categoryDesc;
		this.parentCategoryId = parentCategoryId;
		this.status = status;
		this.createdDate = createdDt;
		this.createdBy = createdBy;
	}

	public Categories(String categoryName, String categoryDesc,
			long parentCategoryId, Boolean isMainCategory, String status,
			Date createdDt, Date modifiedDt, String createdBy,
			String modifiedBy, Set<SellerMaster> sellerMasters,
			Set<Products> productses, MarketingCharges marketingCharges) {
		this.categoryName = categoryName;
		this.categoryDesc = categoryDesc;
		this.parentCategoryId = parentCategoryId;
		this.isMainCategory = isMainCategory;
		this.status = status;
		this.createdDate = createdDt;
		this.modifiedDate = modifiedDt;
		this.createdBy = createdBy;
		this.modifiedBy = modifiedBy;
		this.sellerMasters = sellerMasters;
		this.productses = productses;
		this.marketingCharges = marketingCharges;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "category_id", unique = true, nullable = false)
	public Long getCategoryId() {
		return this.categoryId;
	}

	public void setCategoryId(Long categoryId) {
		this.categoryId = categoryId;
	}

	@Column(name = "category_name", nullable = false, length = 100)
	public String getCategoryName() {
		return this.categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	@Column(name = "category_desc", nullable = false)
	public String getCategoryDesc() {
		return this.categoryDesc;
	}

	public void setCategoryDesc(String categoryDesc) {
		this.categoryDesc = categoryDesc;
	}

	@Column(name = "parent_category_id", nullable = false)
	public long getParentCategoryId() {
		return this.parentCategoryId;
	}

	public void setParentCategoryId(long parentCategoryId) {
		this.parentCategoryId = parentCategoryId;
	}

	@Column(name = "is_main_category")
	public Boolean getIsMainCategory() {
		return this.isMainCategory;
	}

	public void setIsMainCategory(Boolean isMainCategory) {
		this.isMainCategory = isMainCategory;
	}

	@Column(name = "status", nullable = false, length = 25)
	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@DateTimeFormat(pattern="dd/MM/yyyy") 
    @Column(name = "CREATED_DATE", nullable = true)
	@Temporal(TemporalType.TIMESTAMP)
	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDt) {
		this.createdDate = createdDt;
	}

	@DateTimeFormat(pattern="dd/MM/yyyy") 
    @Column(name = "modified_date", nullable = true)
	@Temporal(TemporalType.TIMESTAMP)
	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Date modifiedDt) {
		this.modifiedDate = modifiedDt;
	}

	@Column(name = "created_by", nullable = false, length = 45)
	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	@Column(name = "modified_by", length = 45)
	public String getModifiedBy() {
		return this.modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	@ManyToMany(fetch = FetchType.LAZY, mappedBy = "categorieses")
	public Set<SellerMaster> getSellerMasters() {
		return this.sellerMasters;
	}

	public void setSellerMasters(Set<SellerMaster> sellerMasters) {
		this.sellerMasters = sellerMasters;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "categories")
	public Set<Products> getProductses() {
		return this.productses;
	}

	public void setProductses(Set<Products> productses) {
		this.productses = productses;
	}

	@OneToOne(fetch = FetchType.LAZY, mappedBy = "categories")
	public MarketingCharges getMarketingCharges() {
		return this.marketingCharges;
	}

	public void setMarketingCharges(MarketingCharges marketingCharges) {
		this.marketingCharges = marketingCharges;
	}

}
