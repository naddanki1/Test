package com.thincovate.bibakart.entitymodels;



import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;



@Entity
@Table(name = "feedbacks")
public class Feedbacks implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5899427212222518392L;
	private long sellerId;
	private SellerMaster sellerMaster;
	private OrdersMaster ordersMaster;
	private float rating;
	private String feedback;
	private boolean isEligibleForRevision;
	private boolean isRevisionRequested;
	private String status;
	private Date feedbackDt;

	public Feedbacks() {
	}

	public Feedbacks(SellerMaster sellerMaster, OrdersMaster ordersMaster,
			float rating, String feedback, boolean isEligibleForRevision,
			boolean isRevisionRequested, String status, Date feedbackDt) {
		this.sellerMaster = sellerMaster;
		this.ordersMaster = ordersMaster;
		this.rating = rating;
		this.feedback = feedback;
		this.isEligibleForRevision = isEligibleForRevision;
		this.isRevisionRequested = isRevisionRequested;
		this.status = status;
		this.feedbackDt = feedbackDt;
	}

	@GenericGenerator(name = "generator", strategy = "foreign", parameters = @Parameter(name = "property", value = "sellerMaster"))
	@Id
	@GeneratedValue(generator = "generator")
	@Column(name = "seller_id", unique = true, nullable = false)
	public long getSellerId() {
		return this.sellerId;
	}

	public void setSellerId(long sellerId) {
		this.sellerId = sellerId;
	}

	@OneToOne(fetch = FetchType.LAZY)
	@PrimaryKeyJoinColumn
	public SellerMaster getSellerMaster() {
		return this.sellerMaster;
	}

	public void setSellerMaster(SellerMaster sellerMaster) {
		this.sellerMaster = sellerMaster;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "order_id", nullable = false)
	public OrdersMaster getOrdersMaster() {
		return this.ordersMaster;
	}

	public void setOrdersMaster(OrdersMaster ordersMaster) {
		this.ordersMaster = ordersMaster;
	}

	@Column(name = "rating", nullable = false, precision = 5)
	public float getRating() {
		return this.rating;
	}

	public void setRating(float rating) {
		this.rating = rating;
	}

	@Column(name = "feedback", nullable = false, length = 65535)
	public String getFeedback() {
		return this.feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

	@Column(name = "is_eligible_for_revision", nullable = false)
	public boolean isIsEligibleForRevision() {
		return this.isEligibleForRevision;
	}

	public void setIsEligibleForRevision(boolean isEligibleForRevision) {
		this.isEligibleForRevision = isEligibleForRevision;
	}

	@Column(name = "is_revision_requested", nullable = false)
	public boolean isIsRevisionRequested() {
		return this.isRevisionRequested;
	}

	public void setIsRevisionRequested(boolean isRevisionRequested) {
		this.isRevisionRequested = isRevisionRequested;
	}

	@Column(name = "status", nullable = false, length = 45)
	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "feedback_dt", nullable = false, length = 19)
	public Date getFeedbackDt() {
		return this.feedbackDt;
	}

	public void setFeedbackDt(Date feedbackDt) {
		this.feedbackDt = feedbackDt;
	}

}
