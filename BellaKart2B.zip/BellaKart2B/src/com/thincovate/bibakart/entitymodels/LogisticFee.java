package com.thincovate.bibakart.entitymodels;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "logistic_fee")
public class LogisticFee implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -368896867096764612L;

	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "logistic_fee_id", unique = true, nullable = false)
	private Integer logisticFeeId;

	@Column(name = "lower_limit")
	private Integer lowerLimit;

	@Column(name = "upper_limit")
	private Integer upperLimit;

	@Column(name = "fee")
	private Double fee;

	@Column(name = "tax_on_logistic_fee")
	private Float taxOnLogisticFee;

	@Column(name = "created_date")
	private Date createdDate;

	@Column(name = "modified_date")
	private Date modifiedDate;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "modified_by")
	private String modifiedBy;

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Integer getLogisticFeeId() {
		return logisticFeeId;
	}

	public void setLogisticFeeId(Integer logisticFeeId) {
		this.logisticFeeId = logisticFeeId;
	}

	public Integer getLowerLimit() {
		return lowerLimit;
	}

	public void setLowerLimit(Integer lowerLimit) {
		this.lowerLimit = lowerLimit;
	}

	public Integer getUpperLimit() {
		return upperLimit;
	}

	public void setUpperLimit(Integer upperLimit) {
		this.upperLimit = upperLimit;
	}

	public Double getFee() {
		return fee;
	}

	public void setFee(Double fee) {
		this.fee = fee;
	}

	public Float getTaxOnLogisticFee() {
		return taxOnLogisticFee;
	}

	public void setTaxOnLogisticFee(Float taxOnLogisticFee) {
		this.taxOnLogisticFee = taxOnLogisticFee;
	}

}
