package com.thincovate.bibakart.entitymodels;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "orders_details")
public class OrdersDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "order_id")
	private String orderId;

	@Column(name = "customer_id")
	private String customerId;

	@Column(name = "order_items_id")
	private String orderItemsId;

	@Column(name = "seller_id")
	private String sellerId;
	
	@Column(name = "shipping_address_id")
	private int addressId;

	@Column(name = "cart_value")
	private double cartValue;

	@Column(name = "total_tax_applied")
	private double totalTaxedApplied;

	@Column(name = "total_order_amount")
	private double totalOrderAmount;

	@Column(name = "payment_type")
	private String paymentType;

	@Column(name = "payment_status")
	private String paymentStatus;

	@Column(name = "transaction_id")
	private String transactionId;

	@Column(name = "status")
	private String status;

	@Column(name = "reason")
	private String reason;

	@Column(name = "comments")
	private String comments;

	@Column(name = "updated_by")
	private String updatedBy;

	@Column(name = "updated_date")
	private Date updatedDate;
	
	@Column(name = "return_courier_name")
	private String returnCourierName;

	@Column(name = "shipping_lable_status")
	private String shippingLableStatus;

	@Column(name = "manifest_status")
	private String manifestStatus;
	

	public String getShippingLableStatus() {
		return shippingLableStatus;
	}

	public void setShippingLableStatus(String shippingLableStatus) {
		this.shippingLableStatus = shippingLableStatus;
	}


	public String getManifestStatus() {
		return manifestStatus;
	}

	public void setManifestStatus(String manifestStatus) {
		this.manifestStatus = manifestStatus;
	}

	public String getReturnCourierName() {
		return returnCourierName;
	}

	public void setReturnCourierName(String returnCourierName) {
		this.returnCourierName = returnCourierName;
	}

	@Column(name = "return_tracking_id")
	private String returnTrackingId;

	@Column(name = "return_status")
	private String returnStatus;

	@Column(name = "courier_name")
	private String courierName;

	@Column(name = "tracking_id")
	private String trackingId;

	@Column(name = "tracking_url")
	private String trackingUrl;

	@Column(name = "seller_product_id")
	private String sellerProductId;

	@Column(name = "sku_id")
	private String skuId;

	@Column(name = "taxes_applied")
	private double taxesApplied;

	@Column(name = "shipping_charges")
	private double shippingCharges;

	@Column(name = "promo_code")
	private String promoCode;

	@Column(name = "discount")
	private double discount;

	@Column(name = "effective_product_cost")
	private double effectiveProductCost;

	@Column(name = "units")
	private int units;

	@Column(name = "price_at_sale")
	private double priceAtSale;

	@Column(name = "product_title")
	private String productTitle;

	@Column(name = "created_by", nullable = false, length = 45)
	private String createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date", nullable = false, length = 19)
	private Date cratedDt;

	@Column(name = "modified_by", length = 45)
	private String modifyBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modified_date", length = 19)
	private Date modifyDt;

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifyBy() {
		return this.modifyBy;
	}

	public Date getCratedDt() {
		return cratedDt;
	}

	public void setCratedDt(Date cratedDt) {
		this.cratedDt = cratedDt;
	}

	public void setModifyBy(String modifyBy) {
		this.modifyBy = modifyBy;
	}

	public Date getModifyDt() {
		return this.modifyDt;
	}

	public void setModifyDt(Date modifyDt) {
		this.modifyDt = modifyDt;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getSellerId() {
		return sellerId;
	}

	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public double getCartValue() {
		return cartValue;
	}

	public void setCartValue(double cartValue) {
		this.cartValue = cartValue;
	}

	public double getTotalTaxedApplied() {
		return totalTaxedApplied;
	}

	public void setTotalTaxedApplied(double totalTaxedApplied) {
		this.totalTaxedApplied = totalTaxedApplied;
	}

	public double getTotalOrderAmount() {
		return totalOrderAmount;
	}

	public void setTotalOrderAmount(double totalOrderAmount) {
		this.totalOrderAmount = totalOrderAmount;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getReturnTrackingId() {
		return returnTrackingId;
	}

	public void setReturnTrackingId(String returnTrackingId) {
		this.returnTrackingId = returnTrackingId;
	}

	public String getReturnStatus() {
		return returnStatus;
	}

	public void setReturnStatus(String returnStatus) {
		this.returnStatus = returnStatus;
	}

	public String getCourierName() {
		return courierName;
	}

	public void setCourierName(String courierName) {
		this.courierName = courierName;
	}

	public String getTrackingId() {
		return trackingId;
	}

	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}

	public String getTrackingUrl() {
		return trackingUrl;
	}

	public void setTrackingUrl(String trackingUrl) {
		this.trackingUrl = trackingUrl;
	}

	public String getSellerProductId() {
		return sellerProductId;
	}

	public void setSellerProductId(String sellerProductId) {
		this.sellerProductId = sellerProductId;
	}

	public String getSkuId() {
		return skuId;
	}

	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}

	public double getTaxesApplied() {
		return taxesApplied;
	}

	public void setTaxesApplied(double taxesApplied) {
		this.taxesApplied = taxesApplied;
	}

	public double getShippingCharges() {
		return shippingCharges;
	}

	public void setShippingCharges(double shippingCharges) {
		this.shippingCharges = shippingCharges;
	}

	public String getPromoCode() {
		return promoCode;
	}

	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public double getEffectiveProductCost() {
		return effectiveProductCost;
	}

	public void setEffectiveProductCost(double effectiveProductCost) {
		this.effectiveProductCost = effectiveProductCost;
	}

	public int getUnits() {
		return units;
	}

	public void setUnits(int units) {
		this.units = units;
	}

	public double getPriceAtSale() {
		return priceAtSale;
	}

	public void setPriceAtSale(double priceAtSale) {
		this.priceAtSale = priceAtSale;
	}

	public String getProductTitle() {
		return productTitle;
	}

	public void setProductTitle(String productTitle) {
		this.productTitle = productTitle;
	}

	public String getOrderItemsId() {
		return orderItemsId;
	}

	public void setOrderItemsId(String orderItemsId) {
		this.orderItemsId = orderItemsId;
	}

}
