package com.thincovate.bibakart.entitymodels;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "payments_master")
public class Payments implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "payment_id")
	private Integer paymentId;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "order_id")
	private OrdersMaster ordersMaster;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "seller_id", nullable = false)
	private SellerMaster sellerMaster;

	@Column(name = "order_value")
	private Double orderValue;

	@Column(name = "charges_applicable")
	private Double chargesApplicable;

	@Column(name = "payable_amount")
	private Double payableAmount;

	@Column(name = "remittance_date")
	private Date remittanceDate;

	@Column(name = "reference_no")
	private String referenceNo;
	@Column(name = "bank_name")
	private String bankName;
	@Column(name = "status")
	private String status;

	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@Column(name = "created_date", nullable = true)
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;

	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@Column(name = "modified_date", nullable = true)
	@Temporal(TemporalType.TIMESTAMP)
	private Date modifiedDate;

	@Column(name = "created_by", nullable = false, length = 45)
	private String createdBy;

	@Column(name = "modified_by", length = 45)
	private String modifiedBy;

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public Integer getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(Integer paymentId) {
		this.paymentId = paymentId;
	}

	public OrdersMaster getOrdersMaster() {
		return ordersMaster;
	}

	public void setOrdersMaster(OrdersMaster ordersMaster) {
		this.ordersMaster = ordersMaster;
	}

	public SellerMaster getSellerMaster() {
		return sellerMaster;
	}

	public void setSellerMaster(SellerMaster sellerMaster) {
		this.sellerMaster = sellerMaster;
	}

	public Double getOrderValue() {
		return orderValue;
	}

	public void setOrderValue(Double orderValue) {
		this.orderValue = orderValue;
	}

	public Double getChargesApplicable() {
		return chargesApplicable;
	}

	public void setChargesApplicable(Double chargesApplicable) {
		this.chargesApplicable = chargesApplicable;
	}

	public Date getRemittanceDate() {
		return remittanceDate;
	}

	public void setRemittanceDate(Date remittanceDate) {
		this.remittanceDate = remittanceDate;
	}

	public String getReferenceNo() {
		return referenceNo;
	}

	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Double getPayableAmount() {
		return payableAmount;
	}

	public void setPayableAmount(Double payableAmount) {
		this.payableAmount = payableAmount;
	}

}
