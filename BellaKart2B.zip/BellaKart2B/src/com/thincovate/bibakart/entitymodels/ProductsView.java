package com.thincovate.bibakart.entitymodels;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "products_view")
public class ProductsView implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8967917261031738974L;

	@Column(name = "product_title", nullable = false)
	private String productTitle;

	@Column(name = "product_desc", nullable = false)
	private String productDesc;

	@Column(name = "sku_id", nullable = false)
	private String skuId;

	@Column(name = "category_name", nullable = false)
	private String categoryName;

	@Column(name = "product_id", nullable = false)
	private String productId;

	@Id
	@Column(name = "seller_product_id", nullable = false)
	private String sellerProductId;

	@Column(name = "selling_price", nullable = false)
	private String sellingPrice;

	@Column(name = "seller_id", nullable = false)
	private String sellerId;

	@Column(name = "search_keywords", nullable = false)
	private String searchKeywords;

	@Column(name = "store_display_name", nullable = false)
	private String storeDisplayName;
	
	@Column(name = "available_status", nullable = false)
	private String availableStatus;

	public String getAvailableStatus() {
		return availableStatus;
	}

	public void setAvailableStatus(String availableStatus) {
		this.availableStatus = availableStatus;
	}

	public String getStoreDisplayName() {
		return storeDisplayName;
	}

	public void setStoreDisplayName(String storeDisplayName) {
		this.storeDisplayName = storeDisplayName;
	}

	public String getSellerId() {
		return sellerId;
	}

	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}

	public String getSearchKeywords() {
		return searchKeywords;
	}

	public void setSearchKeywords(String searchKeywords) {
		this.searchKeywords = searchKeywords;
	}

	public String getProductTitle() {
		return productTitle;
	}

	public void setProductTitle(String productTitle) {
		this.productTitle = productTitle;
	}

	public String getProductDesc() {
		return productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}

	public String getSkuId() {
		return skuId;
	}

	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getSellerProductId() {
		return sellerProductId;
	}

	public void setSellerProductId(String sellerProductId) {
		this.sellerProductId = sellerProductId;
	}

	public String getSellingPrice() {
		return sellingPrice;
	}

	public void setSellingPrice(String sellingPrice) {
		this.sellingPrice = sellingPrice;
	}

}
