package com.thincovate.bibakart.entitymodels;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;

import javax.persistence.ManyToOne;

import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "profile_verification")
public class ProfileVerification implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long profileVerificationId;
	// private int prospectId;
	private String mobileVerificationCode;
	private int mobileVerificationStatus;
	private String emailVerificationCode;
	private String emailVerificationLink;
	private int emailVerificationStatus;
	private int profileVerificationStatus;
	private String createdBy;
	private Date createdDate;
	private String modifyBy;
	private Date modifyDate;

	private ProspectiveSellers prospectiveSellers;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "prospect_id", referencedColumnName = "prospect_id")
	public ProspectiveSellers getProspectiveSellers() {
		return prospectiveSellers;
	}

	public void setProspectiveSellers(ProspectiveSellers prospectiveSellers) {
		this.prospectiveSellers = prospectiveSellers;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "profile_verification_id", unique = true, nullable = false)
	public Long getProfileVerificationId() {
		return profileVerificationId;
	}

	public void setProfileVerificationId(Long profileVerificationId) {
		this.profileVerificationId = profileVerificationId;
	}

	/*
	 * @Column(name = "prospect_id", unique = true, nullable = false) public int
	 * getProspectId() { return this.prospectId; }
	 * 
	 * public void setProspectId(int prospectId) { this.prospectId = prospectId;
	 * }
	 */
	@Column(name = "mobile_verification_code", nullable = true, length = 10)
	public String getMobileVerificationCode() {
		return mobileVerificationCode;
	}

	public void setMobileVerificationCode(String mobileVerificationCode) {
		this.mobileVerificationCode = mobileVerificationCode;
	}

	@Column(name = "mobile_verification_status", nullable = true, length = 1)
	public int getMobileVerificationStatus() {
		return mobileVerificationStatus;
	}

	public void setMobileVerificationStatus(int mobileVerificationStatus) {
		this.mobileVerificationStatus = mobileVerificationStatus;
	}

	@Column(name = "email_verification_code", nullable = true, length = 10)
	public String getEmailVerificationCode() {
		return emailVerificationCode;
	}

	public void setEmailVerificationCode(String emailVerificationCode) {
		this.emailVerificationCode = emailVerificationCode;
	}

	@Column(name = "email_verification_status", nullable = true, length = 1)
	public int getEmailVerificationStatus() {
		return emailVerificationStatus;
	}

	public void setEmailVerificationStatus(int emailVerificationStatus) {
		this.emailVerificationStatus = emailVerificationStatus;
	}

	@Column(name = "profile_verification_status", nullable = true, length = 1)
	public int getProfileVerificationStatus() {
		return profileVerificationStatus;
	}

	public void setProfileVerificationStatus(int profileVerificationStatus) {
		this.profileVerificationStatus = profileVerificationStatus;
	}

	@Column(name = "created_by", nullable = true)
	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@Column(name = "CREATED_DATE", nullable = true)
	@Temporal(TemporalType.TIMESTAMP)
	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	@Column(name = "MODIFIED_BY", nullable = true)
	public String getModifyBy() {
		return modifyBy;
	}

	public void setModifyBy(String modifyBy) {
		this.modifyBy = modifyBy;
	}

	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@Column(name = "MODIFIED_DATE", nullable = true)
	@Temporal(TemporalType.TIMESTAMP)
	public Date getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}

	@Column(name = "email_verification_link", nullable = true)
	public String getEmailVerificationLink() {
		return emailVerificationLink;
	}

	public void setEmailVerificationLink(String emailVerificationLink) {
		this.emailVerificationLink = emailVerificationLink;
	}

}
