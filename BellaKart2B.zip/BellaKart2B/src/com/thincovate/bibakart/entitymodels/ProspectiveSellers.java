package com.thincovate.bibakart.entitymodels;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "prospective_sellers")
public class ProspectiveSellers implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1583967988959621143L;
	private int prospectId;
	@NotEmpty(message = "may not be empty")
	private String emailAddr;
	private Long mobile;
	private String status;
	private String comments;
	private String createdBy;
	private Date createdDate;
	private String modifyBy;
	private Date modifyDate;
	private String ipAddress;
	private String macAddress;

	private ProfileVerification profileVerification;

	public void setProfileVerification(ProfileVerification profileVerification) {
		this.profileVerification = profileVerification;
	}

	public ProspectiveSellers() {
	}

	public ProspectiveSellers(String emailAddr, Long mobile, String status, String comments, String createdBy,
			Date createdDate, String modifyBy, Date modifyDate, String ipAddress, String macAddr,
			ProfileVerification profileVerification) {
		this.emailAddr = emailAddr;
		this.mobile = mobile;
		this.status = status;
		this.comments = comments;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.modifyBy = modifyBy;
		this.modifyDate = modifyDate;
		this.ipAddress = ipAddress;
		this.macAddress = macAddr;
		this.profileVerification = profileVerification;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "PROSPECT_ID", unique = true, nullable = false)
	public int getProspectId() {
		return this.prospectId;
	}

	public void setProspectId(int prospectId) {
		this.prospectId = prospectId;
	}

	@Column(name = "EMAIL_ADDR", length = 100)
	public String getEmailAddr() {
		return this.emailAddr;
	}

	public void setEmailAddr(String emailAddr) {
		this.emailAddr = emailAddr;
	}

	@Column(name = "STATUS", nullable = false, length = 1)
	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Column(name = "COMMENTS")
	public String getComments() {
		return this.comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	@Column(name = "MODIFIED_BY", nullable = true)
	public String getModifyBy() {
		return this.modifyBy;
	}

	public void setModifyBy(String modifyBy) {
		this.modifyBy = modifyBy;
	}

	@Column(name = "MOBILE")
	public Long getMobile() {
		return mobile;
	}

	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}

	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@Column(name = "CREATED_DATE", nullable = true)
	@Temporal(TemporalType.TIMESTAMP)
	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@Column(name = "MODIFIED_DATE", nullable = true)
	@Temporal(TemporalType.TIMESTAMP)
	public Date getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}

	@Column(name = "IP_ADDRESS", nullable = true)
	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	@Column(name = "MAC_ADDRESS", nullable = true)
	public String getMacAddress() {
		return macAddress;
	}

	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}

	@Column(name = "CREATED_BY", nullable = true)
	public String getCreatedBy() {
		return createdBy;
	}

	@OneToOne(fetch = FetchType.EAGER, mappedBy = "prospectiveSellers")
	public ProfileVerification getProfileVerification() {
		return this.profileVerification;
	}

}
