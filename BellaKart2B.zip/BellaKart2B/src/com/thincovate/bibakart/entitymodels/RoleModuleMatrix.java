package com.thincovate.bibakart.entitymodels;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "role_module_matrix")
public class RoleModuleMatrix implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2418266632501215034L;
	@OneToOne(fetch = FetchType.LAZY,cascade={CascadeType.ALL})
	@PrimaryKeyJoinColumn
	private Roles roles;
	
	@GenericGenerator(name = "generator", strategy = "foreign", parameters = @Parameter(name = "property", value = "roles"))
	@Id
	@GeneratedValue(generator = "generator")
	@Column(name = "role_id", unique = true, nullable = false)
	private Integer roleId;

	public Roles getRoles() {
		return roles;
	}

	public void setRoles(Roles roles) {
		this.roles = roles;
	}

	public String getCol01() {
		return col01;
	}

	public void setCol01(String col01) {
		this.col01 = col01;
	}

	public String getCol02() {
		return col02;
	}

	public void setCol02(String col02) {
		this.col02 = col02;
	}

	public String getCol03() {
		return col03;
	}

	public void setCol03(String col03) {
		this.col03 = col03;
	}

	public String getCol04() {
		return col04;
	}

	public void setCol04(String col04) {
		this.col04 = col04;
	}

	public String getCol05() {
		return col05;
	}

	public void setCol05(String col05) {
		this.col05 = col05;
	}

	public String getCol06() {
		return col06;
	}

	public void setCol06(String col06) {
		this.col06 = col06;
	}

	public String getCol07() {
		return col07;
	}

	public void setCol07(String col07) {
		this.col07 = col07;
	}

	public String getCol08() {
		return col08;
	}

	public void setCol08(String col08) {
		this.col08 = col08;
	}

	public String getCol09() {
		return col09;
	}

	public void setCol09(String col09) {
		this.col09 = col09;
	}

	public String getCol10() {
		return col10;
	}

	public void setCol10(String col10) {
		this.col10 = col10;
	}

	public String getCol11() {
		return col11;
	}

	public void setCol11(String col11) {
		this.col11 = col11;
	}

	public String getCol12() {
		return col12;
	}

	public void setCol12(String col12) {
		this.col12 = col12;
	}

	public String getCol13() {
		return col13;
	}

	public void setCol13(String col13) {
		this.col13 = col13;
	}

	public String getCol14() {
		return col14;
	}

	public void setCol14(String col14) {
		this.col14 = col14;
	}

	public String getCol15() {
		return col15;
	}

	public void setCol15(String col15) {
		this.col15 = col15;
	}

	public String getCol16() {
		return col16;
	}

	public void setCol16(String col16) {
		this.col16 = col16;
	}

	public String getCol17() {
		return col17;
	}

	public void setCol17(String col17) {
		this.col17 = col17;
	}

	public String getCol18() {
		return col18;
	}

	public void setCol18(String col18) {
		this.col18 = col18;
	}

	public String getCol19() {
		return col19;
	}

	public void setCol19(String col19) {
		this.col19 = col19;
	}

	public String getCol20() {
		return col20;
	}

	public void setCol20(String col20) {
		this.col20 = col20;
	}

	public String getCol21() {
		return col21;
	}

	public void setCol21(String col21) {
		this.col21 = col21;
	}

	public String getCol22() {
		return col22;
	}

	public void setCol22(String col22) {
		this.col22 = col22;
	}

	public String getCol23() {
		return col23;
	}

	public void setCol23(String col23) {
		this.col23 = col23;
	}

	public String getCol24() {
		return col24;
	}

	public void setCol24(String col24) {
		this.col24 = col24;
	}

	public String getCol25() {
		return col25;
	}

	public void setCol25(String col25) {
		this.col25 = col25;
	}

	public String getCol26() {
		return col26;
	}

	public void setCol26(String col26) {
		this.col26 = col26;
	}

	public String getCol27() {
		return col27;
	}

	public void setCol27(String col27) {
		this.col27 = col27;
	}

	public String getCol28() {
		return col28;
	}

	public void setCol28(String col28) {
		this.col28 = col28;
	}

	public String getCol29() {
		return col29;
	}

	public void setCol29(String col29) {
		this.col29 = col29;
	}

	public String getCol30() {
		return col30;
	}

	public void setCol30(String col30) {
		this.col30 = col30;
	}

	public Date getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifyBy() {
		return modifyBy;
	}

	public void setModifyBy(String modifyBy) {
		this.modifyBy = modifyBy;
	}

	public Date getModifyDt() {
		return modifyDt;
	}

	public void setModifyDt(Date modifyDt) {
		this.modifyDt = modifyDt;
	}

	@Column(name = "col01", length = 3)
	private String col01;

	@Column(name = "col02", length = 3)
	private String col02;

	@Column(name = "col03", length = 3)
	private String col03;

	@Column(name = "col04", length = 3)
	private String col04;

	@Column(name = "col05", length = 3)
	private String col05;

	@Column(name = "col06", length = 3)
	private String col06;

	@Column(name = "col07", length = 3)
	private String col07;

	@Column(name = "col08", length = 3)
	private String col08;

	@Column(name = "col09", length = 3)
	private String col09;

	@Column(name = "col10", length = 3)
	private String col10;

	@Column(name = "col11", length = 3)
	private String col11;

	@Column(name = "col12", length = 3)
	private String col12;

	@Column(name = "col13", length = 3)
	private String col13;

	@Column(name = "col14", length = 3)
	private String col14;

	@Column(name = "col15", length = 3)
	private String col15;

	@Column(name = "col16", length = 3)
	private String col16;

	@Column(name = "col17", length = 3)
	private String col17;

	@Column(name = "col18", length = 3)
	private String col18;

	@Column(name = "col19", length = 3)
	private String col19;

	@Column(name = "col20", length = 3)
	private String col20;

	@Column(name = "col21", length = 3)
	private String col21;

	@Column(name = "col22", length = 3)
	private String col22;

	@Column(name = "col23", length = 3)
	private String col23;

	@Column(name = "col24", length = 3)
	private String col24;

	@Column(name = "col25", length = 3)
	private String col25;

	@Column(name = "col26", length = 3)
	private String col26;

	@Column(name = "col27", length = 3)
	private String col27;

	@Column(name = "col28", length = 3)
	private String col28;

	@Column(name = "col29", length = 3)
	private String col29;

	@Column(name = "col30", length = 3)
	private String col30;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "date_created")
	private Date createdDt;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "modified_by")
	private String modifyBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "date_modified")
	private Date modifyDt;

}
