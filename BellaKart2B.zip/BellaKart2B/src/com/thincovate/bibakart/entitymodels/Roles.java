package com.thincovate.bibakart.entitymodels;

import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "roles")
public class Roles implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1414416928853129712L;

	@Column(name = "role_id")
	@Id
	@GeneratedValue(strategy = IDENTITY)
	private Integer roleId;

	@Column(name = "role_name")
	private String roleName;

	@Column(name = "status", length = 45)
	private String status;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "date_created")
	private Date createdDt;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "modified_by")
	private String modifyBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "date_modified")
	private Date modifyDt;

	public Integer getRoleId() {
		return roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifyBy() {
		return modifyBy;
	}

	public RoleModuleMatrix getRoleModuleMatrix() {
		return roleModuleMatrix;
	}

	public void setRoleModuleMatrix(RoleModuleMatrix roleModuleMatrix) {
		this.roleModuleMatrix = roleModuleMatrix;
	}

	public Set<UserRoleMatrix> getUserRoleMatrix() {
		return userRoleMatrix;
	}

	public void setModifyBy(String modifyBy) {
		this.modifyBy = modifyBy;
	}

	public Date getModifyDt() {
		return modifyDt;
	}

	public void setModifyDt(Date modifyDt) {
		this.modifyDt = modifyDt;
	}

	@OneToOne(fetch = FetchType.LAZY, mappedBy = "roles")
	private RoleModuleMatrix roleModuleMatrix;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "roles")
	private Set<UserRoleMatrix> userRoleMatrix;

	public void setUserRoleMatrix(Set<UserRoleMatrix> userRoleMatrix) {
		this.userRoleMatrix = userRoleMatrix;
	}

}
