package com.thincovate.bibakart.entitymodels;

// Generated 13 Aug, 2015 7:05:12 PM by Hibernate Tools 3.4.0.CR1

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.springframework.format.annotation.DateTimeFormat;

import com.thincovate.bibakart.registration.models.Pendingcategory;

@Entity
@Table(name = "seller_master")
public class SellerMaster implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -9045509694665411464L;
	private Long sellerId;
	private String businessName;
	private String storeDisplayName;

	private String description;
	private String pickupAddr;
	private int pickupPin;

	private String primaryContactName;
	private String emailAddr;
	private String pwd;
	private Long mobile;
	private String sellerStatus;

	private String storeStatus;
	private String createdBy;
	private Date createdDate;
	private String modifiedBy;
	private Date modifiedDate;
	private String reason;
	private String comments;
	private Integer contactDetailsVerified;

	@Column(name = "contact_details_verified")
	public Integer getContactDetailsVerified() {
		return contactDetailsVerified;
	}

	public void setContactDetailsVerified(Integer contactDetailsVerified) {
		this.contactDetailsVerified = contactDetailsVerified;
	}

	@Column(name = "reason")
	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	@Column(name = "comments")
	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	// private Set<SellerSessions> sellerSessions = new
	// HashSet<SellerSessions>(0);
	private Set<Categories> categorieses = new HashSet<Categories>(0);

	private Set<SellerProducts> sellerProducts = new HashSet<SellerProducts>(0);
	private Set<OrdersMaster> ordersMasters = new HashSet<OrdersMaster>(0);

	private Set<Pendingcategory> pendingcategories = new HashSet<Pendingcategory>(0);
	private Feedbacks feedbacks;
	private Set<Payments> payments;
	private Set<SellerDocs> sellerDocs = new HashSet<SellerDocs>(0);
	private Set<Inquiries> inquiries = new HashSet<Inquiries>(0);

	public SellerMaster() {
	}

	public SellerMaster(String pickupAddr, int pickupPinCd, String primaryContactNm, String emailAddr, String pwd,
			long mobileNo, String sellerSt, String storeSt, String createdBy, Date createdDt, String mobileCCd) {
		this.pickupAddr = pickupAddr;
		this.pickupPin = pickupPinCd;
		this.primaryContactName = primaryContactNm;
		this.emailAddr = emailAddr;
		this.pwd = pwd;
		this.mobile = mobileNo;
		this.sellerStatus = sellerSt;
		this.storeStatus = storeSt;
		this.createdBy = createdBy;
		this.createdDate = createdDt;

	}

	public SellerMaster(String storeDisplayNm, String descriptioin, String pickupAddr, int pickupPinCd,
			String primaryContactNm, String emailAddr, String pwd, long mobileNo, String sellerSt, String storeSt,
			String createdBy, Date createdDt, String modifyBy, Date modifyDt, String mobileCCd, Byte resetStatus,
			Set<SellerSessions> sellerLoginDetailses, Set<Categories> categorieses,
			Set<SellerProducts> sellerProductses, Set<OrdersMaster> ordersMasters,

			Set<Pendingcategory> pendingcategories, Feedbacks feedbacks, Set<SellerDocs> sellerDocses,
			Set<Inquiries> inquirieses) {
		this.storeDisplayName = storeDisplayNm;
		this.description = descriptioin;
		this.pickupAddr = pickupAddr;
		this.pickupPin = pickupPinCd;
		this.primaryContactName = primaryContactNm;
		this.emailAddr = emailAddr;
		this.pwd = pwd;
		this.mobile = mobileNo;
		this.sellerStatus = sellerSt;
		this.storeStatus = storeSt;
		this.createdBy = createdBy;
		this.createdDate = createdDt;
		this.modifiedBy = modifyBy;
		this.modifiedDate = modifyDt;
		// this.sellerSessions = sellerLoginDetailses;
		this.categorieses = categorieses;
		this.sellerProducts = sellerProductses;
		this.ordersMasters = ordersMasters;

		this.pendingcategories = pendingcategories;
		this.feedbacks = feedbacks;
		this.sellerDocs = sellerDocses;
		this.inquiries = inquirieses;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "SELLER_ID", unique = true, nullable = false)
	public Long getSellerId() {
		return this.sellerId;
	}

	public void setSellerId(Long sellerId) {
		this.sellerId = sellerId;
	}

	@Column(name = "STORE_DISPLAY_NAME", length = 150)
	public String getStoreDisplayName() {
		return this.storeDisplayName;
	}

	public void setStoreDisplayName(String storeDisplayNm) {
		this.storeDisplayName = storeDisplayNm;
	}

	@Column(name = "description")
	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Column(name = "PICKUP_ADDRESS", nullable = false)
	public String getPickupAddr() {
		return this.pickupAddr;
	}

	public void setPickupAddr(String pickupAddr) {
		this.pickupAddr = pickupAddr;
	}

	@Column(name = "PRIMARY_CONTACT_NAME", nullable = false, length = 100)
	public String getPrimaryContactName() {
		return this.primaryContactName;
	}

	public void setPrimaryContactName(String primaryContactNm) {
		this.primaryContactName = primaryContactNm;
	}

	@Column(name = "EMAIL_ADDRESS", nullable = false, length = 150)
	public String getEmailAddr() {
		return this.emailAddr;
	}

	public void setEmailAddr(String emailAddr) {
		this.emailAddr = emailAddr;
	}

	@Column(name = "PASSWORD", nullable = false, length = 100)
	public String getPwd() {
		return this.pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	@Column(name = "MOBILE", nullable = false)
	public Long getMobile() {
		return this.mobile;
	}

	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}

	@Column(name = "SELLER_STATUS", nullable = false, length = 10)
	public String getSellerStatus() {
		return this.sellerStatus;
	}

	public void setSellerSt(String sellerStatus) {
		this.sellerStatus = sellerStatus;
	}

	@Column(name = "STORE_STATUS", nullable = false, length = 10)
	public String getStoreStatus() {
		return this.storeStatus;
	}

	public void setStoreStatus(String storeStatus) {
		this.storeStatus = storeStatus;
	}

	@Column(name = "CREATED_BY", nullable = false, length = 45)
	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@Column(name = "CREATED_DATE", nullable = true)
	@Temporal(TemporalType.TIMESTAMP)
	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	@Column(name = "MODIFIED_BY", length = 45)
	public String getModifiedBy() {
		return this.modifiedBy;
	}

	public void setModifiedBy(String modifyBy) {
		this.modifiedBy = modifyBy;
	}

	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@Column(name = "MODIFIED_DATE", nullable = true)
	@Temporal(TemporalType.TIMESTAMP)
	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Date modifyDate) {
		this.modifiedDate = modifyDate;
	}

	/*
	 * @OneToMany(fetch = FetchType.LAZY, mappedBy = "sellerMaster") public
	 * Set<SellerLoginDetails> getSellerLoginDetails() { return
	 * this.sellerLoginDetails; }
	 * 
	 * public void setSellerLoginDetails(Set<SellerLoginDetails>
	 * sellerLoginDetails) { this.sellerLoginDetails = sellerLoginDetails; }
	 */
	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(name = "seller_categories", joinColumns = {
			@JoinColumn(name = "seller_id", nullable = false, updatable = false) }, inverseJoinColumns = {
					@JoinColumn(name = "category_id", nullable = false, updatable = false) })
	public Set<Categories> getCategorieses() {
		return this.categorieses;
	}

	public void setCategories(Set<Categories> categories) {
		this.categorieses = categories;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "sellerMaster")
	public Set<SellerProducts> getSellerProducts() {
		return this.sellerProducts;
	}

	public void setSellerProducts(Set<SellerProducts> sellerProducts) {
		this.sellerProducts = sellerProducts;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "sellerMaster")
	public Set<OrdersMaster> getOrdersMasters() {
		return this.ordersMasters;
	}

	public void setOrdersMasters(Set<OrdersMaster> ordersMasters) {
		this.ordersMasters = ordersMasters;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "sellerMaster")
	public Set<Pendingcategory> getPendingcategories() {
		return this.pendingcategories;
	}

	public void setPendingcategories(Set<Pendingcategory> pendingcategories) {
		this.pendingcategories = pendingcategories;
	}

	@OneToOne(fetch = FetchType.LAZY, mappedBy = "sellerMaster")
	public Feedbacks getFeedbacks() {
		return this.feedbacks;
	}

	public void setFeedbacks(Feedbacks feedbacks) {
		this.feedbacks = feedbacks;
	}

	@OneToMany(fetch = FetchType.EAGER, mappedBy = "sellerMaster")
	public Set<SellerDocs> getSellerDocs() {
		return this.sellerDocs;
	}

	public void setSellerDocs(Set<SellerDocs> sellerDocses) {
		this.sellerDocs = sellerDocses;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "sellerMaster")
	public Set<Inquiries> getInquiries() {
		return this.inquiries;
	}

	public void setInquirieses(Set<Inquiries> inquiries) {
		this.inquiries = inquiries;
	}

	public void setCategorieses(Set<Categories> categorieses) {
		this.categorieses = categorieses;
	}

	public void setInquiries(Set<Inquiries> inquiries) {
		this.inquiries = inquiries;
	}

	public void setSellerStatus(String sellerStatus) {
		this.sellerStatus = sellerStatus;
	}

	private String retypePwd;

	@Transient
	public String getRetypePwd() {
		return retypePwd;
	}

	public void setRetypePwd(String retypePwd) {
		this.retypePwd = retypePwd;
	}

	@Column(name = "PICKUP_PIN", nullable = false, length = 10)
	public int getPickupPin() {
		return pickupPin;
	}

	public void setPickupPin(int pickupPin) {
		this.pickupPin = pickupPin;
	}

	@Column(name = "business_name")
	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "sellerMaster")
	public Set<Payments> getPayments() {
		return payments;
	}

	public void setPayments(Set<Payments> payments) {
		this.payments = payments;
	}

}
