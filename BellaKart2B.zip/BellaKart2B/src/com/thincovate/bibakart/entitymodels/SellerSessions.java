package com.thincovate.bibakart.entitymodels;

// Generated 13 Aug, 2015 7:05:12 PM by Hibernate Tools 3.4.0.CR1

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table(name = "seller_sessions")
public class SellerSessions implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "session_id", unique = true, nullable = false)
	private String sessionId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "seller_id", nullable = false)
	private SellerMaster sellerMaster;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "loggedin_time", nullable = false, length = 19)
	private Date loggedInTime;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "loggedout_time", length = 19)
	private Date loggedOutTime;
	
	@Column(name = "ip_address", length = 150)
	private String ipAddress;
	
	@Column(name = "mac_address", length = 150)
	private String macAddress;
	
	@Column(name = "session_token")
	private String sessionToken;

	public SellerSessions() {
	}


	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}



	public SellerMaster getSellerMaster() {
		return sellerMaster;
	}


	public void setSellerMaster(SellerMaster sellerMaster) {
		this.sellerMaster = sellerMaster;
	}


	public Date getLoggedInTime() {
		return loggedInTime;
	}

	public void setLoggedInTime(Date loggedInTime) {
		this.loggedInTime = loggedInTime;
	}

	public Date getLoggedOutTime() {
		return loggedOutTime;
	}

	public void setLoggedOutTime(Date loggedOutTime) {
		this.loggedOutTime = loggedOutTime;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public String getMacAddress() {
		return macAddress;
	}

	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}

	public String getSessionToken() {
		return sessionToken;
	}

	public void setSessionToken(String sessionToken) {
		this.sessionToken = sessionToken;
	}


	
	

	
}
