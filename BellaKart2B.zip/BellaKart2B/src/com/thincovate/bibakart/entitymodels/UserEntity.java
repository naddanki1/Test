package com.thincovate.bibakart.entitymodels;

import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "users")
public class UserEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1890813079765482135L;

	@Column(name = "user_id", length = 10)
	@Id
	@GeneratedValue(strategy = IDENTITY)
	private Integer userId;

	@Column(name = "login_id")
	private String loginId;

	@Column(name = "password")
	private String password;

	@Column(name = "name")
	private String name;

	@Column(name = "status", length = 45)
	private String status;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "date_created")
	private Date createdDt;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "modified_by")
	private String modifyBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "date_modified")
	private Date modifyDt;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "users")
	private Set<UserRoleMatrix> userRoleMatrix;

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifyBy() {
		return modifyBy;
	}

	public void setModifyBy(String modifyBy) {
		this.modifyBy = modifyBy;
	}

	public Date getModifyDt() {
		return modifyDt;
	}

	public void setModifyDt(Date modifyDt) {
		this.modifyDt = modifyDt;
	}

	public Set<UserRoleMatrix> getUserRoleMatrix() {
		return userRoleMatrix;
	}

	public void setUserRoleMatrix(Set<UserRoleMatrix> userRoleMatrix) {
		this.userRoleMatrix = userRoleMatrix;
	}
}
