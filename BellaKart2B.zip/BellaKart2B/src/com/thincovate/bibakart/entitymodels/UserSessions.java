/**
 * 
 */
package com.thincovate.bibakart.entitymodels;

import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author Venkat
 *
 */
@Entity
@Table(name = "user_sessions")
public class UserSessions implements Serializable {

	private static final long serialVersionUID = -5037588760357030546L;

	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "session_id", unique = true, nullable = false)
	private String sessionId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id", nullable = false)
	private UserEntity users;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "loggedin_time", nullable = false, length = 19)
	private Date loggedInTime;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "loggedout_time", length = 19)
	private Date loggedOutTime;

	@Column(name = "ip_address", length = 150)
	private String ipAddress;

	@Column(name = "mac_address", length = 150)
	private String macAddress;

	@Column(name = "session_token")
	private String sessionToken;

	public UserSessions() {

	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public UserEntity getUsers() {
		return users;
	}

	public void setUsers(UserEntity users) {
		this.users = users;
	}

	public Date getLoggedInTime() {
		return loggedInTime;
	}

	public void setLoggedInTime(Date loggedInTime) {
		this.loggedInTime = loggedInTime;
	}

	public Date getLoggedOutTime() {
		return loggedOutTime;
	}

	public void setLoggedOutTime(Date loggedOutTime) {
		this.loggedOutTime = loggedOutTime;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public String getMacAddress() {
		return macAddress;
	}

	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}

	public String getSessionToken() {
		return sessionToken;
	}

	public void setSessionToken(String sessionToken) {
		this.sessionToken = sessionToken;
	}

}
