package com.thincovate.bibakart.images.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.thincovate.bibakart.images.service.ImagesService;

@RestController
@RequestMapping("/")
public class ImagesController {

	@Autowired
	private ImagesService imagesService;

/*	@RequestMapping(value = "docs/images", method = RequestMethod.POST)
	public MDResponseWrapper saveDocument(@RequestParam(value = "sellerId") String sellerId,
			@RequestParam(value = "docName") String docName, MultipartFile file) {

		return imagesService.saveDocImage(sellerId, docName, file);
	}

	@RequestMapping(value = "/docs/images", method = RequestMethod.GET, produces = { "image/jpg" })
	public byte[] findDocument(@RequestParam(value = "sellerId") String sellerId,
			@RequestParam(value = "docName") String docName) {

		return imagesService.findDocImage(sellerId, docName);
	}

	@RequestMapping(value = "images", method = RequestMethod.POST)
	public MDResponseWrapper saveImage(@RequestParam(value = "id") String id, @RequestParam(value = "name") String name,
			MultipartFile file) {

		return imagesService.saveImage(name, id, file);
	}

	@RequestMapping(value = "images/{id}", method = RequestMethod.GET, produces = { "image/jpg" })
	public byte[] findmage(@PathVariable("id") String id, @RequestParam(value = "name") String name,
			@RequestParam(value = "size", required = false, defaultValue = "198X232") String size) {

		return imagesService.findImage(name, id, size);

	}*/
	
	@RequestMapping(value="/image/{type}", method=RequestMethod.GET, produces = { "image/jpg" })
	public byte[] findDummyImage(@PathVariable String type){
		return imagesService.findDummnyImage(type);
	}
 
}
