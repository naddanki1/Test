package com.thincovate.bibakart.images.service;

import java.io.InputStream;

import org.springframework.web.multipart.MultipartFile;

import com.thincovate.bibakart.catalog.model.Catalog;
import com.thincovate.bibakart.common.model.ResponseWrapper;
import com.thincovate.bibakart.sessionmgnt.model.Seller;

public interface ImagesService {

	ResponseWrapper saveDocImage(String sellerId, String docName, MultipartFile file);

	ResponseWrapper saveImage(String name, String id, MultipartFile file);

	byte[] findImage(String name, String id, String size);

	byte[] findDocImage(String sellerId, String docName);

	// Boolean saveSkuImage(String sellerId, String skuId, MultipartFile file);

	byte[] findSkuImage(String sellerId, String id, String size);

	boolean copyImage(Catalog catalog, Seller seller);

	byte[] findDummnyImage(String type);

	Boolean saveSkuImage(String sellerId, String skuId, InputStream inputStream, int imageIndex);

}
