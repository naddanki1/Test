package com.thincovate.bibakart.images.service.impl;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.thincovate.bibakart.catalog.model.Catalog;
import com.thincovate.bibakart.common.PropertyReader;
import com.thincovate.bibakart.common.exceptions.ResourceNotFoundException;
import com.thincovate.bibakart.common.model.ResponseWrapper;
import com.thincovate.bibakart.common.utils.BibakartConstants;
import com.thincovate.bibakart.common.utils.Responses;
import com.thincovate.bibakart.images.service.ImagesService;
import com.thincovate.bibakart.sessionmgnt.model.Seller;

@Service
public class ImagesServiceImpl implements ImagesService {
	
	private static Logger log = Logger.getLogger(ImagesServiceImpl.class);

	@Override
	public ResponseWrapper saveDocImage(String sellerId, String docName, MultipartFile file) {

		InputStream inputStream = null;
		OutputStream outputStream = null;
		String fileName = null;
		String extension = null;
		List<String> errors = new ArrayList<String>();
		try {
			inputStream = file.getInputStream();
			extension = ".jpg";
			if (extension.equalsIgnoreCase(".jpg") || extension.equalsIgnoreCase(".jpeg") || extension.equalsIgnoreCase(".png")) {
				fileName = docName + extension;
				String rootFolder = PropertyReader.getInstance().getProperty("loc.images.rootLocation");
				if (rootFolder == null) {
					errors.add("root directory is missing");
					log.debug("root directory is missing");
					return new ResponseWrapper(Responses.FAILURE_STATUS, Responses.ERROR_MSG, errors);
				}
				String docLocation = rootFolder + File.separator +"Profiles"+ File.separator + sellerId+File.separator +"Proof_Documents" ;
				if (createDirectory(docLocation)) {
					File newFile = new File(docLocation + File.separator + fileName);
					outputStream = new FileOutputStream(newFile);
					int readBytes = 0;
					byte[] buffer = new byte[8192];
					while ((readBytes = inputStream.read(buffer, 0, 8192)) != -1) {
						outputStream.write(buffer, 0, readBytes);
					}
					outputStream.close();
					inputStream.close();

					return new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS,
							"" + newFile.getAbsolutePath());
				}
			} else {
				errors.add("Unsupported File Type");
				return new ResponseWrapper(Responses.FAILURE_STATUS, Responses.ERROR_MSG, errors);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return new ResponseWrapper(Responses.FAILURE_CODE, Responses.ERROR_STATUS,
				"Exception occured while saving image");
	}

	@Override
	public byte[] findDocImage(String sellerId, String docName) {
		
		ByteArrayOutputStream bao = new ByteArrayOutputStream();
		try {
			if (docName.equalsIgnoreCase("tanProof") || docName.equalsIgnoreCase("panProof")
					|| docName.equalsIgnoreCase("tinProof") || docName.equalsIgnoreCase("cancelledCheque")
					|| docName.equalsIgnoreCase("kycAddr") || docName.equalsIgnoreCase("kycId")) {

				String rootFolder = PropertyReader.getInstance().getProperty("loc.images.rootLocation");
				if (rootFolder == null) {
					log.debug("root directory is missing");
					return bao.toByteArray();
				}
				// sellerId = CommonUtils.decryptText(sellerId);
				String docLocation = rootFolder + File.separator +"Profiles"+ File.separator + sellerId+File.separator +"Proof_Documents"+File.separator+ docName + ".jpg" ;

					File file = new File(docLocation);

					InputStream inputStream = new FileInputStream(file);
					// Prepare buffered image.
					BufferedImage img = ImageIO.read(inputStream);
					// Write to output stream
					ImageIO.write(img, "jpg", bao);
					return bao.toByteArray();
			
			} else {
				log.debug("invalid docname");
				return bao.toByteArray();
			}
		}catch (FileNotFoundException e) {
			throw new ResourceNotFoundException("Image Not uploaded yet");
		}catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}
	

	@Override
	public ResponseWrapper saveImage(String name, String id, MultipartFile file) {
		InputStream inputStream = null;
		OutputStream outputStream = null;
		String fileName = null;
		String extension = null;
		String fname = null;
		List<String> errors = new ArrayList<String>();
		try {
			if (name.equalsIgnoreCase(BibakartConstants.PRODUCTS))
				fname = BibakartConstants.PRODUCTS;
			else if (name.equalsIgnoreCase(BibakartConstants.CATEGORIES))
				fname = BibakartConstants.CATEGORIES;
			else if (name.equalsIgnoreCase(BibakartConstants.BRANDS))
				fname = BibakartConstants.BRANDS;
			else
				return new ResponseWrapper(Responses.FAILURE_CODE, Responses.ERROR_STATUS, "Invalid Name");

			inputStream = file.getInputStream();
			extension = ".jpg";
			if (extension.equalsIgnoreCase(".jpg") || extension.equalsIgnoreCase(".jpeg")
					|| extension.equalsIgnoreCase(".png")) {
				fileName = id + extension;
				String rootFolder = PropertyReader.getInstance().getProperty("loc.images.rootLocation");
				if (rootFolder == null) {
					errors.add("root directory is missing");
					return new ResponseWrapper(Responses.FAILURE_CODE,Responses.FAILURE_STATUS, Responses.ERROR_MSG, errors);
				}
				String docLocation = rootFolder + File.separator + fname + File.separator + id;
				if (createDirectory(docLocation)) {
					File newFile = new File(docLocation + File.separator + fileName);
					outputStream = new FileOutputStream(newFile);
					int readBytes = 0;
					byte[] buffer = new byte[8192];
					while ((readBytes = inputStream.read(buffer, 0, 8192)) != -1) {
						outputStream.write(buffer, 0, readBytes);
					}
					outputStream.close();
					inputStream.close();

					// images with different Size
					resize(newFile.getAbsolutePath(), docLocation + File.separator + id + "_198X232.jpg", 198, 232);
					resize(newFile.getAbsolutePath(), docLocation + File.separator + id + "_640x720.jpg", 640, 720);

					return new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS, "Path:" + newFile.getAbsolutePath());
				}
			} else {
				errors.add("Unsupported File Type");
				return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG, errors);
			}
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG, errors);
		} catch (IOException e) {
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.ERROR_STATUS,	"Exception occured while saving image");
		}
	
	}
	
	@Override
	public Boolean saveSkuImage(String sellerId, String skuId, InputStream inputStream,int imageIndex) {
		//InputStream inputStream = null;
		OutputStream outputStream = null;
		String fileName = null;
		String extension = null;
		//String fname = null;
		//int imageIndex = 1;
		List<String> errors = new ArrayList<String>();
		try {
			//inputStream = file.getInputStream();
			extension = ".jpg";
			if (extension.equalsIgnoreCase(".jpg") || extension.equalsIgnoreCase(".jpeg")|| extension.equalsIgnoreCase(".png")) {
				fileName = skuId + extension;
				String rootFolder = PropertyReader.getInstance().getProperty("loc.images.rootLocation");
				if (rootFolder == null) {
					errors.add("root directory is missing");
					return false;
				}
				String docLocation = rootFolder + File.separator +"Profiles"+ File.separator + sellerId+File.separator +"Products"+File.separator+ skuId;
				//String docLocation = rootFolder + File.separator + fname + File.separator + skuId;
				if (createDirectory(docLocation)) {
					File newFile = new File(docLocation + File.separator + fileName);
					outputStream = new FileOutputStream(newFile);
					int readBytes = 0;
					byte[] buffer = new byte[8192];
					while ((readBytes = inputStream.read(buffer, 0, 8192)) != -1) {
						outputStream.write(buffer, 0, readBytes);
					}
					outputStream.close();
					inputStream.close();

					// images with different Size
					resize(newFile.getAbsolutePath(), docLocation + File.separator + skuId + "_"+imageIndex+"_" +BibakartConstants.IMG_THUMB_WIDTH+"x"+BibakartConstants.IMG_THUMB_HEIGHT+".jpg", BibakartConstants.IMG_THUMB_WIDTH, BibakartConstants.IMG_THUMB_HEIGHT);
					resize(newFile.getAbsolutePath(), docLocation + File.separator + skuId + "_"+imageIndex+"_"  +BibakartConstants.IMG_SHOW_WIDTH+"x"+BibakartConstants.IMG_SHOW_HEIGHT+".jpg", BibakartConstants.IMG_SHOW_WIDTH, BibakartConstants.IMG_SHOW_HEIGHT);
					resize(newFile.getAbsolutePath(), docLocation + File.separator + skuId + "_"+imageIndex+"_"  +BibakartConstants.IMG_LARGE_WIDTH+"x"+BibakartConstants.IMG_LARGE_HEIGHT+".jpg", BibakartConstants.IMG_LARGE_WIDTH, BibakartConstants.IMG_LARGE_HEIGHT);

					resize(newFile.getAbsolutePath(), docLocation + File.separator + skuId + "_"+imageIndex+"_"  +BibakartConstants.IMG_BANNER1_WIDTH+"x"+BibakartConstants.IMG_BANNER1_HEIGHT+".jpg", BibakartConstants.IMG_BANNER1_WIDTH, BibakartConstants.IMG_BANNER1_HEIGHT);
					resize(newFile.getAbsolutePath(), docLocation + File.separator + skuId + "_"+imageIndex+"_"  +BibakartConstants.IMG_BANNER2_WIDTH+"x"+BibakartConstants.IMG_BANNER2_HEIGHT+".jpg", BibakartConstants.IMG_BANNER2_WIDTH, BibakartConstants.IMG_BANNER2_HEIGHT);
					resize(newFile.getAbsolutePath(), docLocation + File.separator + skuId + "_"+imageIndex+"_"  +BibakartConstants.IMG_BANNER3_WIDTH+"x"+BibakartConstants.IMG_BANNER3_HEIGHT+".jpg", BibakartConstants.IMG_BANNER3_WIDTH, BibakartConstants.IMG_BANNER3_HEIGHT);
					resize(newFile.getAbsolutePath(), docLocation + File.separator + skuId + "_"+imageIndex+"_"  +BibakartConstants.IMG_BANNER4_WIDTH+"x"+BibakartConstants.IMG_BANNER4_HEIGHT+".jpg", BibakartConstants.IMG_BANNER4_WIDTH, BibakartConstants.IMG_BANNER4_HEIGHT);

					return true;
				}
			} else {
				errors.add("Unsupported File Type");
				return false;
			}
			return false;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	
	}

	@Override
	public byte[] findSkuImage(String sellerId, String skuId, String size) {
		ByteArrayOutputStream bao = new ByteArrayOutputStream();
		try {
			String rootFolder = PropertyReader.getInstance().getProperty("loc.images.rootLocation");
			if (rootFolder == null) {
				log.debug("root directory is missing");
				return bao.toByteArray();
			}
			//String docLocation = rootFolder + File.separator +"Profiles" + File.separator + sellerId + File.separator +"Products" + File.separator + skuId + File.separator+ skuId + "_" + size + ".jpg";
			String docLocation = rootFolder + File.separator +"Profiles" + File.separator + sellerId + File.separator +"Products" + File.separator + skuId + File.separator+ skuId + "_1_"+size+".jpg";	
			File file = new File(docLocation);
			InputStream inputStream = new FileInputStream(file);
			// Prepare buffered image.
			BufferedImage img = ImageIO.read(inputStream);
			// Write to output stream
			ImageIO.write(img, "jpg", bao);
			return bao.toByteArray();
		} catch (FileNotFoundException e) {
			throw new ResourceNotFoundException("Image not found");
		}catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}
	
	@Override
	public byte[] findImage(String name, String id, String size) {
		
		ByteArrayOutputStream bao = new ByteArrayOutputStream();
		try {
			String fname = null;
			String rootFolder = PropertyReader.getInstance().getProperty("loc.images.rootLocation");
			if (name.equalsIgnoreCase(BibakartConstants.PRODUCTS)){
				fname = BibakartConstants.PRODUCTS;}
			else if (name.equalsIgnoreCase(BibakartConstants.CATEGORIES))
				fname = BibakartConstants.CATEGORIES;
			else if (name.equalsIgnoreCase(BibakartConstants.BRANDS))
				fname = BibakartConstants.BRANDS;
			else
				return bao.toByteArray();

			if (rootFolder == null) {
				log.debug("root directory is missing");
				return bao.toByteArray();
			}
			// brandId=CommonUtils.decryptText(brandId);
			String docLocation = rootFolder + File.separator + fname + "" + File.separator + id + File.separator + id + "_" + size + ".jpg";

			File file = new File(docLocation);

			InputStream inputStream = new FileInputStream(file);
			// Prepare buffered image.
			BufferedImage img = ImageIO.read(inputStream);
			// Write to output stream
			ImageIO.write(img, "jpg", bao);

			return bao.toByteArray();

		} catch (Exception e) {
			e.printStackTrace();
			String rootFolder = null;
			try {
				rootFolder = PropertyReader.getInstance().getProperty("loc.images.rootLocation");
				String docLocation = rootFolder + File.separator +"imagenotfound.jpg";
				File file = new File(docLocation);
				InputStream inputStream = new FileInputStream(file);
				BufferedImage img = ImageIO.read(inputStream);
				ImageIO.write(img, "jpg", bao);
				return bao.toByteArray();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return null;
	}

	@Override
	public byte[] findDummnyImage(String type){
		String rootFolder = null;
		ByteArrayOutputStream bao = new ByteArrayOutputStream();
		try {
			rootFolder = PropertyReader.getInstance().getProperty("loc.images.rootLocation");
			String docLocation = rootFolder + File.separator+type+".jpg";
			File file = new File(docLocation);
			InputStream inputStream = new FileInputStream(file);
			BufferedImage img = ImageIO.read(inputStream);
			ImageIO.write(img, "jpg", bao);
			return bao.toByteArray();
		} catch (Exception e1) {
			// TODO Auto-generated catch block.
			e1.printStackTrace();
		}
		return null;
	}
	
	private boolean createDirectory(String folderName) {
		log.debug("creating directory");
		File theDir = new File(folderName);
		log.debug("got file ");
		if (!theDir.exists()) {
			log.debug("no directory");
			try {
				log.debug("making directory. can created? :" + theDir.canWrite());
				boolean created = theDir.mkdirs();
				log.debug("done mk directory :" + created);
			} catch (Exception se) {
				se.printStackTrace();
				System.out.println("Creating Directory failed :: " + se.getMessage());
				return false;
			}
			log.debug("seems created directory well");
			return true;
		} else
			log.debug("directory exists");
		return true;
	}

	public static void resize(String inputImagePath, String outputImagePath, int scaledWidth, int scaledHeight) {

		try {
			BufferedImage originalImage = ImageIO.read(new File(inputImagePath));
			int type = originalImage.getType() == 0 ? BufferedImage.TYPE_INT_ARGB : originalImage.getType();
			BufferedImage resizedImage = new BufferedImage(scaledWidth, scaledHeight, type);
			Graphics2D g = resizedImage.createGraphics();
			g.drawImage(originalImage, 0, 0, scaledWidth, scaledHeight, null);
			g.dispose();
			ImageIO.write(resizedImage, "jpg", new File(outputImagePath));

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public boolean copyImage(Catalog catalog ,Seller seller){
		FileInputStream fis =  null;
		FileOutputStream fos = null;
		try {
			String rootFolder = PropertyReader.getInstance().getProperty("loc.images.rootLocation");
			String source =	rootFolder + File.separator +"Profiles"+ File.separator + catalog.getSellerId()+File.separator +"Products"+File.separator+ catalog.getBaseSku()+ File.separator + catalog.getBaseSku() + "_1_" +BibakartConstants.IMG_SHOW_WIDTH+"x"+BibakartConstants.IMG_SHOW_HEIGHT+".jpg";
			String destination = rootFolder + File.separator +"Profiles"+ File.separator + seller.getSellerId()+File.separator +"Products"+File.separator+ catalog.getSkuId();
			String fileName= catalog.getSkuId()+".jpg";
			if (createDirectory(destination)) {
				File newFile = new File(destination + File.separator + fileName);
				fos = new FileOutputStream(newFile);
				File file = new File(source); 
				if(file.exists()){
				fis = new FileInputStream(file);
				byte[] buff = new byte[fis.available()];
				fis.read(buff);
				fos.write(buff); 
				// images with different Size
				resize(newFile.getAbsolutePath(), destination + File.separator + catalog.getSkuId() + "_1_"+BibakartConstants.IMG_THUMB_WIDTH+"x"+BibakartConstants.IMG_THUMB_HEIGHT+".jpg", BibakartConstants.IMG_THUMB_WIDTH, BibakartConstants.IMG_THUMB_HEIGHT);
				resize(newFile.getAbsolutePath(), destination + File.separator + catalog.getSkuId() + "_1_"+BibakartConstants.IMG_SHOW_WIDTH+"x"+BibakartConstants.IMG_SHOW_HEIGHT+".jpg", BibakartConstants.IMG_SHOW_WIDTH, BibakartConstants.IMG_SHOW_HEIGHT);
				resize(newFile.getAbsolutePath(), destination + File.separator + catalog.getSkuId() + "_1_"+BibakartConstants.IMG_LARGE_WIDTH+"x"+BibakartConstants.IMG_LARGE_HEIGHT+".jpg", BibakartConstants.IMG_LARGE_WIDTH, BibakartConstants.IMG_LARGE_HEIGHT);

				resize(newFile.getAbsolutePath(), destination + File.separator + catalog.getSkuId() + "_1_"+BibakartConstants.IMG_BANNER1_WIDTH+"x"+BibakartConstants.IMG_BANNER1_HEIGHT+".jpg", BibakartConstants.IMG_BANNER1_WIDTH, BibakartConstants.IMG_BANNER1_HEIGHT);
				resize(newFile.getAbsolutePath(), destination + File.separator + catalog.getSkuId() + "_1_"+BibakartConstants.IMG_BANNER2_WIDTH+"x"+BibakartConstants.IMG_BANNER2_HEIGHT+".jpg", BibakartConstants.IMG_BANNER2_WIDTH, BibakartConstants.IMG_BANNER2_HEIGHT);
				resize(newFile.getAbsolutePath(), destination + File.separator + catalog.getSkuId() + "_1_"+BibakartConstants.IMG_BANNER3_WIDTH+"x"+BibakartConstants.IMG_BANNER3_HEIGHT+".jpg", BibakartConstants.IMG_BANNER3_WIDTH, BibakartConstants.IMG_BANNER3_HEIGHT);
				resize(newFile.getAbsolutePath(), destination + File.separator + catalog.getSkuId() + "_1_"+BibakartConstants.IMG_BANNER4_WIDTH+"x"+BibakartConstants.IMG_BANNER4_HEIGHT+".jpg", BibakartConstants.IMG_BANNER4_WIDTH, BibakartConstants.IMG_BANNER4_HEIGHT);

				}
			}
		
			return true;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return false;
		}finally {
			try {
				fis.close();
				fos.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
}
