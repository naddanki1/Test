package com.thincovate.bibakart.orders.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.thincovate.bibakart.common.model.OrderResponseWrapper;
import com.thincovate.bibakart.common.model.ResponseWrapper;
import com.thincovate.bibakart.common.utils.Responses;
import com.thincovate.bibakart.orders.model.Order;
import com.thincovate.bibakart.orders.services.OrdersService;

@RestController
public class OrdersController {

	@Autowired
	private OrdersService ordersService;

	private static Logger log = Logger.getLogger(OrdersController.class);

	/** saves order
	 * @param order
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/order", method = RequestMethod.POST)
	public ResponseWrapper saveOrder(@RequestBody Order order, HttpServletRequest request) {
		ResponseWrapper response = null;
		log.info("save order - starts");
		response = ordersService.saveOrder(order, request);
		log.info("save order - ends");
		return response;
	}

	/** return orders with limit
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/orders", method = RequestMethod.GET)
	public ResponseWrapper getAllOrders(HttpServletRequest request) {
		ResponseWrapper response = null;
		
		String offset = request.getParameter("offset");
		String maxResults = request.getParameter("maxResults");
		offset = (String) (offset == null ? 0 : offset);  // set offset 
		maxResults = (String) (maxResults == null ? 50 : maxResults); // set maxResults
		log.info("Get all orders with offset = "+offset+" MaxResults ="+maxResults+" - starts");
		response = ordersService.getAllOrders(request.getParameter("status"),Integer.parseInt(offset), Integer.parseInt(maxResults));
		log.info("Get all orders with offset = "+offset+" MaxResults ="+maxResults+" - ends");
		return response;
	}

	/** return orders of a seller with limit
	 * @param sellerId
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "sellers/{sellerId}/orders", method = RequestMethod.GET)
	public ResponseWrapper getAllOrders(@PathVariable Long sellerId,HttpServletRequest request) {
		ResponseWrapper response = null;
		
		String offset = request.getParameter("offset");
		String maxResults = request.getParameter("maxResults");
		offset = (String) (offset == null ? 0 : offset);  // set offset 
		maxResults = (String) (maxResults == null ? 50 : maxResults); // set maxResults
		log.info("Get orders of Seller: " + sellerId + "with offset = "+offset+" MaxResults ="+maxResults+" - starts");
		response = ordersService.getOrdersBySeller(sellerId,request.getParameter("status"),Integer.parseInt(offset),Integer.parseInt(maxResults));
		log.info("Get orders of Seller: " + sellerId + "with offset = "+offset+" MaxResults ="+maxResults+" - starts");
		return response;
	}
	
	/** update order status and courier details
	 * @param order
	 * @param request
	 * @return
	 */
	@RequestMapping(value="/order",method=RequestMethod.PUT)
	public ResponseWrapper updateOrder(@RequestBody Order order,HttpServletRequest request){
		ResponseWrapper response = null;
		log.info("Update order - "+order.getOrderId()+" starts");
		String type = request.getParameter("type");
		if(type!=null && type.equalsIgnoreCase("courier"))
			response = ordersService.updateCourierDetails(order, request);
		else
			response= ordersService.updateOrder(order, request);
		log.info("Update order - "+order.getOrderId()+" ends");
		return response;
	}
	
	/** update order return status and courier details
	 * @param order
	 * @param request
	 * @return
	 */
	@RequestMapping(value="/order/return",method=RequestMethod.PUT)
	public ResponseWrapper updateOrderReturn(@RequestBody Order order,HttpServletRequest request){
		ResponseWrapper response = null;
		log.info("Update order - "+order.getOrderId()+" starts");
		String type = request.getParameter("type");
		if(type!=null && type.equalsIgnoreCase("courier"))
			response = ordersService.updateReturnCourierDetails(order, request);
		else
			response= ordersService.updateOrderReturnDetails(order, request);
		log.info("Update order - "+order.getOrderId()+" ends");
		return response;
	}
	
	@RequestMapping(value ="/orders/search")
	public ResponseWrapper searchOrders(@RequestParam(value = "keyword") String keyword,HttpServletRequest request){
		ResponseWrapper response = null;
		log.info("Search Orders with  keyword "+keyword+"starts");
		response = ordersService.searchOrders(keyword,request);
		log.info("Search Orders with  keyword "+keyword+"ends");
		return response;
	}
	@RequestMapping(value ="/orders/{orderId}")
	public ResponseWrapper getOrder(@PathVariable Long orderId,HttpServletRequest request){
		ResponseWrapper response = null;
		log.info("Get  order details of "+orderId+" starts");
		Order order = ordersService.getOrder(orderId);
		List<Order> ordersList = new ArrayList<Order>();
		if(order!=null){
			ordersList.add(order);
			response = new OrderResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_MSG, Responses.SUCCESS_STATUS,ordersList);
		}
		else
			response = new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.FAILURE_MSG);
		
		log.info("Get  order details of "+orderId+" ends");
		return response;
	}
/*	@RequestMapping(value = "sellers/orders/document/", method = RequestMethod.POST)
	public  ResponseWrapper uploadDoc(MultipartHttpServletRequest request) {
		try{
			HttpSession session = request.getSession();
			Long orderId = Long.parseLong(request.getParameter("orderId"));
			Seller seller = (Seller) session.getAttribute("seller");
			String sellerId = request.getParameter("sellerId");
			if (sellerId == null)
				sellerId = seller.getSellerId();
			Iterator<String> it = request.getFileNames();
			int i= 0;
			while(it.hasNext()){
					String name = it.next();
					log.info("Uploading "+name+" for order "+orderId+"of Seller "+sellerId);
				if(downloadService.uploadDoc(sellerId, name,orderId, request.getFile(name)))
						i++;
			}
			if(i==2){
				log.info("test");
			return new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS, Responses.SUCCESS_MSG);
			}
		}catch(Exception e){
			// TODO 
			e.printStackTrace();
		}
		 return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.FAILURE_MSG);
	}*/
	
}
