package com.thincovate.bibakart.orders.dao;

import org.springframework.stereotype.Repository;

import com.thincovate.bibakart.dao.AbstractHibernateDAO;
import com.thincovate.bibakart.entitymodels.Addresses;

@Repository
public class AddressDAO extends AbstractHibernateDAO<Addresses>{

	public AddressDAO() {
		setClazz(Addresses.class);
	}
}
