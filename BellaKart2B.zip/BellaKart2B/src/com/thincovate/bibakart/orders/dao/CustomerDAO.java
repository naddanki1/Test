package com.thincovate.bibakart.orders.dao;

import org.springframework.stereotype.Repository;

import com.thincovate.bibakart.dao.AbstractHibernateDAO;
import com.thincovate.bibakart.entitymodels.CustomerDetails;

@Repository
public class CustomerDAO extends AbstractHibernateDAO<CustomerDetails> {
	
	public CustomerDAO() {
		setClazz(CustomerDetails.class);
	}
}
