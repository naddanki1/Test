package com.thincovate.bibakart.orders.dao;

import org.springframework.stereotype.Repository;

import com.thincovate.bibakart.dao.AbstractHibernateDAO;
import com.thincovate.bibakart.entitymodels.OrderItems;

@Repository
public class OrderItemsDAO extends AbstractHibernateDAO<OrderItems> {
	public OrderItemsDAO() {
		setClazz(OrderItems.class);
	}
}
