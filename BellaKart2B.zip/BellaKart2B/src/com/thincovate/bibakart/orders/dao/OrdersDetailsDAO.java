package com.thincovate.bibakart.orders.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.thincovate.bibakart.common.utils.BibakartConstants;
import com.thincovate.bibakart.dao.AbstractHibernateDAO;
import com.thincovate.bibakart.entitymodels.OrdersDetails;

@Repository
public class OrdersDetailsDAO extends AbstractHibernateDAO<OrdersDetails> {
	public OrdersDetailsDAO() {
		setClazz(OrdersDetails.class);
	}
	@SuppressWarnings("unchecked")
	public List<OrdersDetails> search(String keyword) {
		Criteria c = getCurrentSession().createCriteria(OrdersDetails.class);
		//c.add(Restrictions.ne(BellakartConstants.AVAILABLE_STATUS, BellakartConstants.STATUS_OBSELETE));
		Criterion c1 = Restrictions.ilike(BibakartConstants.SKU_ID, keyword, MatchMode.ANYWHERE);
		Criterion c2 = Restrictions.ilike(BibakartConstants.ITEM_ID, keyword, MatchMode.ANYWHERE);
		Criterion c4 = Restrictions.ilike(BibakartConstants.PRODUCT_TITLE, keyword, MatchMode.ANYWHERE);
		Criterion c5 = Restrictions.ilike(BibakartConstants.ORDER_ID, keyword, MatchMode.ANYWHERE);
		Disjunction disjunction = Restrictions.disjunction();
		disjunction.add(c1);
		disjunction.add(c2);
		disjunction.add(c4);
		disjunction.add(c5);
		c.add(disjunction);
		return c.list();

	}	
	public List<OrdersDetails> searchOrders(String keyword, String sellerId) {
		Criteria c = getCurrentSession().createCriteria(OrdersDetails.class);
		c.add(Restrictions.like(BibakartConstants.SELLER_ID, sellerId));
		Criterion c1 = Restrictions.ilike(BibakartConstants.SKU_ID, keyword, MatchMode.ANYWHERE);
		Criterion c2 = Restrictions.ilike(BibakartConstants.ITEM_ID, keyword, MatchMode.ANYWHERE);
		Criterion c4 = Restrictions.ilike(BibakartConstants.PRODUCT_TITLE, keyword, MatchMode.ANYWHERE);
		Criterion c5 = Restrictions.ilike(BibakartConstants.ORDER_ID, keyword, MatchMode.ANYWHERE);
		Disjunction disjunction = Restrictions.disjunction();
		disjunction.add(c1);
		disjunction.add(c2);
		disjunction.add(c4);
		disjunction.add(c5);
		c.add(disjunction);
		return c.list();

	}
}
