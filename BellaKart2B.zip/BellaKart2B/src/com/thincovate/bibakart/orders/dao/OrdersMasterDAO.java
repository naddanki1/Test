package com.thincovate.bibakart.orders.dao;

import org.springframework.stereotype.Repository;

import com.thincovate.bibakart.dao.AbstractHibernateDAO;
import com.thincovate.bibakart.entitymodels.OrdersMaster;

@Repository
public class OrdersMasterDAO extends AbstractHibernateDAO<OrdersMaster> {
	
	public OrdersMasterDAO() {
		setClazz(OrdersMaster.class);
	}
}
