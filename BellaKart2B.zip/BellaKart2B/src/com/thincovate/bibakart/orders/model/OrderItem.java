package com.thincovate.bibakart.orders.model;

public class OrderItem {
	private long itemId;
	private long sellerProductId;
	private long productId;
	private String productTitle;
	private String skuId;
	private String title;
	private double taxesApplied;
	private double shippingCharges;
	private String promoCode;
	private double discount;
	private double effectiveProductCost;
	private int units;
	private double priceAtSale;

	public long getItemId() {
		return itemId;
	}

	public void setItemId(long itemId) {
		this.itemId = itemId;
	}

	public long getProductId() {
		return productId;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

	public String getProductTitle() {
		return productTitle;
	}

	public void setProductTitle(String productTitle) {
		this.productTitle = productTitle;
	}

	public String getSkuId() {
		return skuId;
	}

	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getUnits() {
		return units;
	}

	public void setUnits(int units) {
		this.units = units;
	}

	public double getPriceAtSale() {
		return priceAtSale;
	}

	public void setPriceAtSale(double priceAtSale) {
		this.priceAtSale = priceAtSale;
	}

	public long getSellerProductId() {
		return sellerProductId;
	}

	public void setSellerProductId(long sellerProductId) {
		this.sellerProductId = sellerProductId;
	}

	public double getTaxesApplied() {
		return taxesApplied;
	}

	public void setTaxesApplied(double taxesApplied) {
		this.taxesApplied = taxesApplied;
	}

	public double getShippingCharges() {
		return shippingCharges;
	}

	public void setShippingCharges(double shippingCharges) {
		this.shippingCharges = shippingCharges;
	}

	public String getPromoCode() {
		return promoCode;
	}

	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public double getEffectiveProductCost() {
		return effectiveProductCost;
	}

	public void setEffectiveProductCost(double effectiveProductCost) {
		this.effectiveProductCost = effectiveProductCost;
	}

}
