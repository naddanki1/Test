package com.thincovate.bibakart.orders.services;

public interface CustomerService {

	boolean isCustomerExists(long customerId);
}
