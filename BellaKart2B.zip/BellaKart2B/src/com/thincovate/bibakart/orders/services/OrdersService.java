package com.thincovate.bibakart.orders.services;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.thincovate.bibakart.common.model.ResponseWrapper;
import com.thincovate.bibakart.orders.model.Order;
import com.thincovate.bibakart.orders.model.OrderItem;

public interface OrdersService {

	ResponseWrapper saveOrder(Order order, HttpServletRequest request);

	ResponseWrapper getAllOrders(String status, int offset, int maxResults);
	
	Order getOrder(long orderId);

	ResponseWrapper getOrdersBySeller(Long sellerId, String status, int offset, int maxResults);

	ResponseWrapper updateOrder(Order order, HttpServletRequest request);

	ResponseWrapper updateCourierDetails(Order order, HttpServletRequest request);
	
	ResponseWrapper updateOrderReturnDetails(Order order, HttpServletRequest request);

	ResponseWrapper updateReturnCourierDetails(Order order, HttpServletRequest request);

	ResponseWrapper searchOrders(String keyword, HttpServletRequest request);

	List<OrderItem> getOrderItems(Long orderId);

}
