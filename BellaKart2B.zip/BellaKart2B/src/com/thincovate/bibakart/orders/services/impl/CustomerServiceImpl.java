package com.thincovate.bibakart.orders.services.impl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.thincovate.bibakart.entitymodels.CustomerDetails;
import com.thincovate.bibakart.orders.dao.CustomerDAO;
import com.thincovate.bibakart.orders.services.CustomerService;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerDAO customerDAO;

	@Override
	public boolean isCustomerExists(long customerId) {
		try {
			CustomerDetails customer = customerDAO.findOne(customerId);
			if (customer != null)
				return true;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return false;
	}

}
