package com.thincovate.bibakart.orders.services.impl;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.thincovate.bibakart.catalog.dao.SellerProductsDAO;
import com.thincovate.bibakart.common.model.OrderResponseWrapper;
import com.thincovate.bibakart.common.model.ResponseWrapper;
import com.thincovate.bibakart.common.utils.BibakartConstants;
import com.thincovate.bibakart.common.utils.DateUtils;
import com.thincovate.bibakart.common.utils.Responses;
import com.thincovate.bibakart.configs.services.ConfigsServicesI;
import com.thincovate.bibakart.entitymodels.Addresses;
import com.thincovate.bibakart.entitymodels.CustomerDetails;
import com.thincovate.bibakart.entitymodels.OrderItems;
import com.thincovate.bibakart.entitymodels.OrdersDetails;
import com.thincovate.bibakart.entitymodels.OrdersMaster;
import com.thincovate.bibakart.entitymodels.SellerMaster;
import com.thincovate.bibakart.entitymodels.SellerProducts;
import com.thincovate.bibakart.orders.dao.AddressDAO;
import com.thincovate.bibakart.orders.dao.CustomerDAO;
import com.thincovate.bibakart.orders.dao.OrderItemsDAO;
import com.thincovate.bibakart.orders.dao.OrdersDetailsDAO;
import com.thincovate.bibakart.orders.dao.OrdersMasterDAO;
import com.thincovate.bibakart.orders.model.Order;
import com.thincovate.bibakart.orders.model.OrderItem;
import com.thincovate.bibakart.orders.services.CustomerService;
import com.thincovate.bibakart.orders.services.OrdersService;
import com.thincovate.bibakart.payments.model.Payment;
import com.thincovate.bibakart.payments.services.PaymentsService;
import com.thincovate.bibakart.registration.dao.SellerMasterDAO;
import com.thincovate.bibakart.registration.services.SellerMasterService;
import com.thincovate.bibakart.sessionmgnt.model.Seller;
import com.thincovate.bibakart.sessionmgnt.services.impl.User;

@Service
@Transactional
public class OrdersServiceImpl implements OrdersService {

	@Autowired
	private OrdersMasterDAO ordersMasterDAO;

	@Autowired
	private OrderItemsDAO orderItemsDAO;

	@Autowired
	private OrdersDetailsDAO ordersDetailsDAO;

	@Autowired
	private AddressDAO addressDAO;

	@Autowired
	private CustomerDAO customerDAO;

	@Autowired
	private SellerMasterDAO sellerMasterDAO;

	@Autowired
	private SellerProductsDAO sellerProductsDAO;

	@Autowired
	private CustomerService customerService;
	
	@Autowired
	private ConfigsServicesI configService;

	@Autowired
	private SellerMasterService sellerMasterService;
	
	@Autowired
	private PaymentsService paymentsService;

	static Logger log = Logger.getLogger(OrdersServiceImpl.class);

	@Override
	public ResponseWrapper saveOrder(Order order, HttpServletRequest request) {
		OrderResponseWrapper response = new OrderResponseWrapper();
		// HttpSession session= request.getSession();
		try {
			OrdersMaster om = new OrdersMaster();
			if (customerService.isCustomerExists(order.getCustomerId())) { // check for customer account
				List<CustomerDetails> customers = customerDAO.findAllByColumn("customerId", order.getCustomerId());
				om.setCustomerDetails(customers.get(0));
			} else {
				response.setCode(Responses.FAILURE_CODE);
				response.setStatus(Responses.FAILURE_STATUS);
				response.setMessage("Customer Details not found for the given id");
				log.info("Customer Details not found for the given id-" + order.getCustomerId());
				return response;
			}
			if (sellerMasterService.isSellerExists(order.getSellerId())) { //check for seller
				List<SellerMaster> sellers = sellerMasterDAO.findAllByColumn("sellerId", order.getSellerId());
				om.setSellerMaster(sellers.get(0));
			} else {
				response.setCode(Responses.FAILURE_CODE);
				response.setStatus(Responses.FAILURE_STATUS);
				response.setMessage("Seller Details not found for the given id");
				log.info("Seller Details not found for the given id" + order.getSellerId());
				return response;
			}
			String createdBy = getCurrentUserName(request);
			om.setCartValue(order.getCartValue());
			om.setPaymentType(order.getPaymentType());
			om.setAddress(addressDAO.findOne(order.getShippingAddressId()));
			if(order.getPaymentType().equalsIgnoreCase("COD")){
				om.setPaymentStatus(BibakartConstants.PAYMENT_STATUS_PENDING); // TODO
				om.setTransactionId(BibakartConstants.STATUS_NA); // TODO
			}else{
				om.setPaymentStatus(BibakartConstants.PAYMENT_STATUS_COMPLETED); // TODO
				om.setTransactionId(order.getTransactionId()); // TODO
			}				

			om.setTotalTaxedApplied(order.getTotalTaxedApplied());
			om.setTotalOrderAmount(order.getTotalOrderAmount());

			om.setStatus(BibakartConstants.STATUS_NEW);
			om.setCratedDt(DateUtils.getCurrentDate());
			om.setCreatedBy(createdBy);
			ordersMasterDAO.save(om); // save order

			for (OrderItem item : order.getOrderItems()) {
				OrderItems i = new OrderItems();
				SellerProducts sp = sellerProductsDAO.findOne(item.getSellerProductId());
				i.setOrdersMaster(om);
				i.setSellerProducts(sp);
				sp.setUnits(sp.getUnits()-item.getUnits());
				i.setTaxesApplied(item.getTaxesApplied());
				i.setShippingCharges(sp.getShippingCharges());
				i.setPromoCode(item.getPromoCode());
				i.setDiscount(item.getDiscount());
				i.setEffectiveProductCost(item.getEffectiveProductCost());
				i.setCreatedBy(createdBy);
				i.setCreatedDate(DateUtils.getCurrentDate());
				i.setUnits(item.getUnits());
				i.setPriceAtSale(item.getPriceAtSale());
				orderItemsDAO.save(i);
				
			}
			response.setCode(Responses.SUCCESS_CODE);
			response.setStatus(Responses.SUCCESS_STATUS);
			response.setMessage(Responses.SUCCESS_MSG);
			return response;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			response.setCode(Responses.FAILURE_CODE);
			response.setStatus(Responses.FAILURE_STATUS);
			response.setMessage("Some problem occured at server...");
			log.info("Some problem occured at server...");
			return response;
		}

	}

	@Override
	public ResponseWrapper getAllOrders(String status, int offset, int maxResults) {
		OrderResponseWrapper response = new OrderResponseWrapper();
		try {
			List<OrdersMaster> ordersList = null;
			status = (status == null ? "all" : status);
			log.info("Status :" + status);
			if (status.equalsIgnoreCase("all")) {
				ordersList = ordersMasterDAO.findAllByLimit(offset, maxResults);
				response.setTotalOrders(ordersMasterDAO.getCount(""));
			} else {
				ordersList = ordersMasterDAO.findAllByLimit("status", status, offset, maxResults);
				response.setTotalOrders(ordersMasterDAO.getCount(" where status ='" + status + "'"));
			}
			List<Order> orders = getOrderList(ordersList);
			response.setCode(Responses.SUCCESS_CODE);
			response.setStatus(Responses.SUCCESS_STATUS);
			response.setMessage(Responses.SUCCESS_MSG);
			response.setOrders(orders);

		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			response.setCode(Responses.FAILURE_CODE);
			response.setStatus(Responses.FAILURE_STATUS);
			response.setMessage("Some problem occured at server...");
		}
		return response;
	}

	private static List<Order> getOrderList(List<OrdersMaster> ordersList) {
		List<Order> orders = new ArrayList<Order>();
		try {
			for (OrdersMaster o : ordersList) {
				Order order = new Order();
				order.setOrderId(o.getOrderId());
				order.setCustomerId(o.getCustomerDetails().getCustomerId());
				order.setCustomerName(o.getCustomerDetails().getCustomerName());
				order.setSellerId(o.getSellerMaster().getSellerId());
				order.setSellerName(o.getSellerMaster().getPrimaryContactName());
				order.setCartValue(o.getCartValue());
				order.setTotalTaxedApplied(o.getTotalTaxedApplied());
				order.setTotalOrderAmount(o.getTotalOrderAmount());
				order.setShippingAddress(getAddress(o.getAddress()));
				order.setPaymentType(o.getPaymentType());
				order.setPaymentStatus(o.getPaymentStatus());
				order.setTransactionId(o.getTransactionId());
				order.setStatus(o.getStatus());
				order.setReason(o.getReason());
				order.setComments(o.getComments());
				order.setCourierName(o.getCourierName()==null?BibakartConstants.STATUS_NA :o.getCourierName() );
				order.setTrackingId(o.getTrackingId() == null ? BibakartConstants.STATUS_NA : o.getTrackingId() );
				order.setCreatedDate(DateUtils.format(o.getCratedDt()));
				order.setPickupAddress(o.getSellerMaster().getPickupAddr());
				order.setUpdatedBy(o.getUpdatedBy());
				order.setUpdatedDate(DateUtils.format(o.getUpdatedDate()));
				order.setReturnCourierName(o.getReturnCourierName()== null?BibakartConstants.STATUS_NA :o.getReturnCourierName());
				order.setReturnTrackingId(o.getReturnTrackingId() == null ? BibakartConstants.STATUS_NA :o.getReturnTrackingId());
				order.setReturnStatus(o.getReturnStatus());
				order.setTrackingUrl(o.getTrackingUrl());
				order.setShippingLableStatus(o.getShippingLableStatus());
				order.setManifestStatus(o.getManifestStatus());
				SellerMaster sm = o.getSellerMaster();
				Seller seller = new Seller();
				seller.setSellerId(sm.getSellerId().toString());
				seller.setStoreDisplayName(sm.getStoreDisplayName());
				seller.setPickupAddr(sm.getPickupAddr());
				seller.setPickupPin(sm.getPickupPin());
				seller.setMobile(sm.getMobile().toString());
				order.setSeller(seller);
				List<OrderItem> orderItems = new ArrayList<OrderItem>();
				for (OrderItems i : o.getOrderItemses()) {
					OrderItem item = new OrderItem();
					item.setDiscount(i.getDiscount());
					item.setEffectiveProductCost(i.getEffectiveProductCost());
					item.setPriceAtSale(i.getPriceAtSale());
					item.setPromoCode(i.getPromoCode()==null ? BibakartConstants.STATUS_NA : i.getPromoCode());
					item.setSellerProductId(i.getSellerProducts().getSellerProductId());
					item.setSkuId(i.getSellerProducts().getSkuId());
					item.setTitle(i.getSellerProducts().getProducts().getProductTitle());
					item.setShippingCharges(i.getShippingCharges());
					item.setTaxesApplied(i.getTaxesApplied());
					item.setUnits(i.getUnits());
					item.setProductTitle(i.getSellerProducts().getProducts().getProductTitle());
					item.setProductId(i.getSellerProducts().getProducts().getProductId());
					orderItems.add(item);
				}
				order.setOrderItems(orderItems);
				orders.add(order);
			}
			return orders;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
		}
		return null;
	}

	private static String getAddress(Addresses addresses) {
		String address = addresses.getLine1() + "," + "\n" + addresses.getLine2() + "," + "\n" + addresses.getLocality()
				+ "," + addresses.getCity() + "," + "\n" + addresses.getState() + "," + addresses.getCountry() + ","
				+ "\n" + addresses.getZipcode();
		return address;
	}

	@Override
	public ResponseWrapper getOrdersBySeller(Long sellerId, String status, int offset, int maxResults) {
		OrderResponseWrapper response = new OrderResponseWrapper();
		try {
			List<OrdersMaster> ordersList = null;
			status = (status == null ? "all" : status);
			if (status.equalsIgnoreCase("all")) {
				ordersList = ordersMasterDAO.findAllByColumn("sellerMaster", sellerId, offset, maxResults);
				response.setTotalOrders(ordersMasterDAO.getCount(" where sellerMaster='" + sellerId + "'"));
			} else if(status.equalsIgnoreCase("to_ship") || status.equalsIgnoreCase("to_ship_need_labels")){
				String query = " sellerMaster ='"+sellerId+"' and status LIKE '%"+status+"%'";
				ordersList = ordersMasterDAO.findAllByString(query, offset, maxResults);
				response.setTotalOrders(ordersMasterDAO	.getCount(" where "+query));
			}else {
				ordersList = ordersMasterDAO.findAllByColumn("sellerMaster", sellerId, "status", status, offset,maxResults);
				response.setTotalOrders(ordersMasterDAO	.getCount(" where sellerMaster='" + sellerId + "' and status ='" + status + "'"));
			}
			List<Order> orders = getOrderList(ordersList);
			response.setCode(Responses.SUCCESS_CODE);
			response.setStatus(Responses.SUCCESS_STATUS);
			response.setMessage(Responses.SUCCESS_MSG);
			response.setOrders(orders);
			return response;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			response.setCode(Responses.FAILURE_CODE);
			response.setStatus(Responses.FAILURE_STATUS);
			response.setMessage("Some problem occured at server...");
		}
		return response;
	}

	private static String getCurrentUserName(HttpServletRequest request) {
		String userName = null;
		try {
			HttpSession session = request.getSession();
			Seller seller = (Seller) session.getAttribute("seller");
			if (seller != null)
				return seller.getStoreDisplayName();
			else {
				User user = (User) session.getAttribute("user");
				if (user != null)
					return user.getUserName();
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return userName;
	}

	@Override
	public ResponseWrapper updateOrder(Order order, HttpServletRequest request) {
		OrderResponseWrapper response = new OrderResponseWrapper();
		try {
			OrdersMaster om = ordersMasterDAO.findOne(order.getOrderId()); // check for order
			if (om != null) {
				if (order.getStatus().equalsIgnoreCase(BibakartConstants.STATUS_CANCELLED)
						|| order.getStatus().equalsIgnoreCase(BibakartConstants.STATUS_RETURNED)) { // if status is cancelled
					om.setStatus(order.getStatus());
					om.setModifyBy(getCurrentUserName(request));
					om.setModifyDt(DateUtils.getCurrentDate());
					om.setReason(order.getReason());
					om.setComments(order.getComments());
					om.setReturnStatus(BibakartConstants.STATUS_IN_TRANSIT);
				} else if (order.getStatus().equalsIgnoreCase(BibakartConstants.STATUS_DELIVERED)){
					om.setStatus(order.getStatus());
					om.setModifyBy(getCurrentUserName(request));
					om.setModifyDt(DateUtils.getCurrentDate());
					Payment payment = new Payment();
					payment.setChargesApplicable(om.getTotalTaxedApplied());
					payment.setOrderValue(om.getTotalOrderAmount());
					payment.setOrderId(om.getOrderId());
					payment.setSellerId(om.getSellerMaster().getSellerId());
					payment.setRemittanceDate((configService.getValueByKey(BibakartConstants.NEXT_REMITTANCE_DATE)));
					payment.setStatus(BibakartConstants.PAYMENT_STATUS_PENDING);
					payment.setCreatedBy(getCurrentUserName(request));
					payment.setCreatedDate(DateUtils.getCurrentDate().toString());
					paymentsService.savePayment(payment);
				}else {
					om.setStatus(order.getStatus());
					om.setModifyBy(getCurrentUserName(request));
					om.setModifyDt(DateUtils.getCurrentDate());
				}
			}
			response.setCode(Responses.SUCCESS_CODE);
			response.setStatus(Responses.SUCCESS_STATUS);
			response.setMessage(Responses.SUCCESS_MSG);
			return response;

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			response.setCode(Responses.FAILURE_CODE);
			response.setStatus(Responses.FAILURE_STATUS);
			response.setMessage("Some problem occured at server...");
		}
		return response;
	}

	@Override
	public ResponseWrapper updateCourierDetails(Order order, HttpServletRequest request) {
		ResponseWrapper response = new ResponseWrapper();
		try {
			log.info("Courier" + order.getCourierName());
			OrdersMaster om = ordersMasterDAO.findOne(order.getOrderId());
			if (om != null) {
				om.setCourierName(order.getCourierName());
				om.setTrackingId(order.getTrackingId());
				response.setCode(Responses.SUCCESS_CODE);
				response.setStatus(Responses.SUCCESS_STATUS);
				response.setMessage(Responses.SUCCESS_MSG);
			} else {
				response.setCode(Responses.FAILURE_CODE);
				response.setStatus(Responses.FAILURE_STATUS);
				response.setMessage(Responses.SUCCESS_MSG);
			}

			return response;
		} catch (Exception e) {
			e.printStackTrace();
			response.setCode(Responses.FAILURE_CODE);
			response.setStatus(Responses.FAILURE_STATUS);
			response.setMessage("Some problem occured at server...");
		}
		return response;
	}

	@Override
	public ResponseWrapper searchOrders(String keyword,HttpServletRequest request) {
		OrderResponseWrapper response = new OrderResponseWrapper();
		try {
			List<OrdersDetails> orders = new ArrayList<OrdersDetails>();
			HttpSession session = request.getSession();
			Seller seller = (Seller)session.getAttribute("seller");
			if(seller!=null)
				 orders = ordersDetailsDAO.searchOrders(keyword,seller.getSellerId());
			else
				 orders = ordersDetailsDAO.search(keyword);
			List<Order> ordersList = getOrdersList(orders);
			response.setCode(Responses.SUCCESS_CODE);
			response.setStatus(Responses.SUCCESS_STATUS);
			response.setMessage(Responses.SUCCESS_MSG);
			response.setOrders(ordersList);

		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			response.setCode(Responses.FAILURE_CODE);
			response.setStatus(Responses.FAILURE_STATUS);
			response.setMessage("Some problem occured at server...");
		}
		return response;
	}

	private  List<Order> getOrdersList(List<OrdersDetails> ordersDetails){
		List<Order>  orders = new ArrayList<Order>();
		for(OrdersDetails or : ordersDetails){
			Order o = new Order();
			o.setCartValue(or.getCartValue());
			o.setComments(or.getComments());
			o.setCourierName(or.getCourierName()==null?BibakartConstants.STATUS_NA :or.getCourierName());
			o.setTrackingId(or.getTrackingId()==null?BibakartConstants.STATUS_NA :or.getTrackingId());
			o.setCreatedBy(or.getCreatedBy());
			o.setCreatedDate(DateUtils.format(or.getCratedDt()));
			o.setCustomerId(Long.parseLong(or.getCustomerId()));
			o.setCustomerName(customerDAO.findOne(Long.parseLong(or.getCustomerId())).getCustomerName());
			o.setModifiedBy(or.getModifyBy());
			o.setModifiedDate(DateUtils.format(or.getModifyDt()));
			o.setOrderId(Long.parseLong(or.getOrderId()));
			o.setPaymentStatus(or.getPaymentStatus());
			o.setPaymentType(or.getPaymentType());
			o.setReason(or.getReason());
			o.setReturnStatus(or.getReturnStatus());
			o.setReturnCourierName(or.getReturnCourierName()==null?BibakartConstants.STATUS_NA :or.getReturnCourierName());
			o.setReturnTrackingId(or.getReturnTrackingId()==null?BibakartConstants.STATUS_NA :or.getReturnTrackingId() );
			OrdersMaster om = ordersMasterDAO.findOne(Long.parseLong(or.getOrderId()));
			SellerMaster sm = om.getSellerMaster();
			Seller seller = new Seller();
			seller.setSellerId(sm.getSellerId().toString());
			seller.setStoreDisplayName(sm.getStoreDisplayName());
			seller.setPickupAddr(sm.getPickupAddr());
			seller.setPickupPin(sm.getPickupPin());
			seller.setMobile(sm.getMobile().toString());
			o.setPickupAddress(sm.getPickupAddr());
			o.setSeller(seller);
			o.setSellerId(Long.parseLong(or.getSellerId()));
			o.setShippingAddress(getAddress(om.getAddress()));
			o.setStatus(or.getStatus());
			o.setTotalOrderAmount(or.getTotalOrderAmount());
			o.setTotalTaxedApplied(or.getTaxesApplied());
			o.setTrackingUrl(or.getTrackingUrl());
			o.setTransactionId(or.getTransactionId());
			o.setUpdatedBy(or.getUpdatedBy());
			o.setUpdatedDate(DateUtils.format(or.getUpdatedDate()));
			o.setShippingLableStatus(or.getShippingLableStatus());
			o.setManifestStatus(or.getManifestStatus());
			List<OrderItem> orderItems = new ArrayList<OrderItem>();
			for (OrderItems i : om.getOrderItemses()) {
				OrderItem item = new OrderItem();
				item.setDiscount(i.getDiscount());
				item.setEffectiveProductCost(i.getEffectiveProductCost());
				item.setPriceAtSale(i.getPriceAtSale());
				item.setPromoCode(i.getPromoCode());
				item.setSellerProductId(i.getSellerProducts().getSellerProductId());
				item.setSkuId(i.getSellerProducts().getSkuId());
				item.setTitle(i.getSellerProducts().getProducts().getProductTitle());
				item.setShippingCharges(i.getShippingCharges());
				item.setTaxesApplied(i.getTaxesApplied());
				item.setUnits(i.getUnits());
				item.setProductTitle(i.getSellerProducts().getProducts().getProductTitle());
				item.setProductId(i.getSellerProducts().getProducts().getProductId());
				orderItems.add(item);
			}
			o.setOrderItems(orderItems);
			orders.add(o);
		}
		return orders;
	}

	@Override
	public ResponseWrapper updateReturnCourierDetails(Order order, HttpServletRequest request) {
		ResponseWrapper response = new ResponseWrapper();
		try {
			OrdersMaster om = ordersMasterDAO.findOne(order.getOrderId());
			if (om != null) {
				om.setReturnCourierName(order.getReturnCourierName());
				om.setReturnTrackingId(order.getReturnTrackingId());
				response.setCode(Responses.SUCCESS_CODE);
				response.setStatus(Responses.SUCCESS_STATUS);
				response.setMessage(Responses.SUCCESS_MSG);
			} else {
				response.setCode(Responses.FAILURE_CODE);
				response.setStatus(Responses.FAILURE_STATUS);
				response.setMessage(Responses.SUCCESS_MSG);
			}
			return response;
		} catch (Exception e) {
			e.printStackTrace();
			response.setCode(Responses.FAILURE_CODE);
			response.setStatus(Responses.FAILURE_STATUS);
			response.setMessage("Some problem occured at server...");
		}
		return response;
	}

	@Override
	public ResponseWrapper updateOrderReturnDetails(Order order, HttpServletRequest request) {
		OrderResponseWrapper response = new OrderResponseWrapper();
		try {
			OrdersMaster om = ordersMasterDAO.findOne(order.getOrderId()); // check for order
			if (om != null) {
				if (order.getStatus().equalsIgnoreCase(BibakartConstants.STATUS_CANCELLED)
						|| order.getStatus().equalsIgnoreCase(BibakartConstants.STATUS_RETURNED)) { // if status is cancelled
					om.setReturnStatus(order.getReturnStatus());
					om.setModifyBy(getCurrentUserName(request));
					om.setModifyDt(DateUtils.getCurrentDate());
					if(order.getReason()!=null)
						om.setReason(order.getReason());
					if(order.getComments()!=null)
						om.setComments(order.getComments());
				} else {
					om.setReturnStatus(order.getReturnStatus());
					om.setModifyBy(getCurrentUserName(request));
					om.setModifyDt(DateUtils.getCurrentDate());
				}
			}
			response.setCode(Responses.SUCCESS_CODE);
			response.setStatus(Responses.SUCCESS_STATUS);
			response.setMessage(Responses.SUCCESS_MSG);
			return response;

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			response.setCode(Responses.FAILURE_CODE);
			response.setStatus(Responses.FAILURE_STATUS);
			response.setMessage("Some problem occured at server...");
		}
		return response;
	}

	@Override
	public Order getOrder(long orderId) {
		Order order =null;
		try {
			List<OrdersMaster> ordersList = null;
			ordersList = ordersMasterDAO.findAllByColumn("orderId", orderId);
			List<Order> orders = getOrderList(ordersList);
			order = orders.get(0);
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
		}
		return order;
	}
	
	@Override
	public List<OrderItem> getOrderItems(Long orderId) {
		List<OrderItem> items = new ArrayList<OrderItem>();
		try {
			List<OrdersMaster> ordersList = null;
			ordersList = ordersMasterDAO.findAllByColumn("orderId", orderId);
			for(OrdersMaster om : ordersList){
				for (OrderItems i : om.getOrderItemses()) {
					OrderItem item = new OrderItem();
					item.setItemId(i.getOrderItemsId());
					item.setProductTitle(i.getSellerProducts().getProducts().getProductTitle());
					item.setProductId(i.getSellerProducts().getSellerProductId());
					item.setSkuId(i.getSellerProducts().getSkuId());
					items.add(item);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
			return items;
	}
}
