package com.thincovate.bibakart.payments.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.thincovate.bibakart.common.model.OrderResponseWrapper;
import com.thincovate.bibakart.common.model.ResponseWrapper;
import com.thincovate.bibakart.common.utils.Responses;
import com.thincovate.bibakart.orders.model.Order;
import com.thincovate.bibakart.payments.dao.PaymentsDAO;
import com.thincovate.bibakart.payments.model.Payment;
import com.thincovate.bibakart.payments.model.SellerPayments;
import com.thincovate.bibakart.payments.services.PaymentsService;

@RestController
public class PaymentsController {
	private static Logger log = Logger.getLogger(PaymentsController.class);
	
	@Autowired
	private PaymentsService paymentService;
	
	@Autowired
	private PaymentsDAO p;
	
	/** save Payment
	 * @param payment
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/payment", method = RequestMethod.POST)
	public ResponseWrapper savePayment(@RequestBody Payment payment, HttpServletRequest request) {
		ResponseWrapper response = null;
		log.info("save Payment - starts");
		if(paymentService.savePayment(payment))
			response = new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS, Responses.SUCCESS_MSG);
		log.info("save Payment - ends");
		return response;
	}

	/** returns all payments
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/payments", method = RequestMethod.GET)
	public ResponseWrapper getAllPayments(HttpServletRequest request) {
		ResponseWrapper response = null;
		
		String offset = request.getParameter("offset");
		String maxResults = request.getParameter("maxResults");
		offset = (String) (offset == null ? 0 : offset);  // set offset 
		maxResults = (String) (maxResults == null ? 50 : maxResults); // set maxResults
		log.info("Get all Payments with offset = "+offset+" MaxResults ="+maxResults+" - starts");
		response = paymentService.getPayments(request.getParameter("status"),Integer.parseInt(offset), Integer.parseInt(maxResults));
		log.info("Get all Payments with offset = "+offset+" MaxResults ="+maxResults+" - ends");
		return response;
	}
	
	@RequestMapping(value = "/payments/{paymentId}", method = RequestMethod.GET)
	public ResponseWrapper getPaymentDetails(@PathVariable String paymentId) {
		ResponseWrapper response = null;
		log.info("Get  Payment Details of "+paymentId+" - starts");
		response = paymentService.getPayment(paymentId);
		log.info("Get  Payment Details of "+paymentId+" - ends");
		return response;
	}
	/** returns all payments by Seller
	 * @param sellerId
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "sellers/{sellerId}/payments", method = RequestMethod.GET)
	public ResponseWrapper getAllPaymentsBySeller(@PathVariable String sellerId,HttpServletRequest request) {
		ResponseWrapper response = null;
		String offset = request.getParameter("offset");
		String maxResults = request.getParameter("maxResults");
		offset = (String) (offset == null ? 0 : offset);  // set offset 
		maxResults = (String) (maxResults == null ? 50 : maxResults); // set maxResults
		log.info("Get all Payments with offset = "+offset+" MaxResults ="+maxResults+" - starts");
		response = paymentService.getPaymentsBySeller(sellerId,request.getParameter("status"),Integer.parseInt(offset), Integer.parseInt(maxResults));
		log.info("Get all Payments with offset = "+offset+" MaxResults ="+maxResults+" - ends");
		return response;
	}
	/** returns 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "payments/period", method = RequestMethod.GET)
	public ResponseWrapper getAllPaymentsByPeriod(HttpServletRequest request) {
	
		ResponseWrapper response = null;
		String offset = request.getParameter("offset");
		String maxResults = request.getParameter("maxResults");
		String startDate = request.getParameter("startDate");
		String endDate = request.getParameter("endDate");
		offset = (String) (offset == null ? 0 : offset);  // set offset 
		maxResults = (String) (maxResults == null ? 50 : maxResults); // set maxResults
		log.info("Get all Payments with offset = "+offset+" MaxResults ="+maxResults+" - starts");
		//response =paymentService.getPayments(request,startDate, endDate, Integer.parseInt(offset), Integer.parseInt(maxResults));
		response =paymentService.getPayments(request,startDate, endDate);
		
		log.info("Get all Payments with offset = "+offset+" MaxResults ="+maxResults+" - ends");
		return response;
		
	}	
	/** returns all summarized payments for each sellerInteger.parseInt(offset), Integer.parseInt(maxResults)
	 * @return
	 */
	@RequestMapping(value = "sellers/payments/{type}", method = RequestMethod.GET)
	public ResponseWrapper getSellerPayments(@PathVariable String type,HttpServletRequest request){
		ResponseWrapper response = null;
		String offset = request.getParameter("offset");
		String maxResults = request.getParameter("maxResults");
		offset = (String) (offset == null ? 0 : offset);  // set offset 
		maxResults = (String) (maxResults == null ? 50 : maxResults); // set maxResults
		log.info("Get all Seller Payments with offset = "+offset+" MaxResults ="+maxResults+" - starts");
		response =paymentService.getSellerPayments(type,Integer.parseInt(offset), Integer.parseInt(maxResults));
		log.info("Get all Seller Payments Paymenys - end");
		return response;
	}
	@RequestMapping(value = "payment", method = RequestMethod.PUT)
	public ResponseWrapper updatePayment(@RequestBody SellerPayments sellerPayments,HttpServletRequest request){
		ResponseWrapper response = null;
	/*	String sellerId =request.getParameter("sellerId");
		String refernceNo =request.getParameter("refernceNo");
		String bankName =request.getParameter("bankName");
		String remittanceDate =request.getParameter("remittanceDate");
		SellerPayments sellerPayments = new SellerPayments();
		sellerPayments.setSellerId(Long.parseLong(sellerId));
		sellerPayments.setReferenceNo(refernceNo);
		sellerPayments.setBankName(bankName);
		sellerPayments.setRemittanceDate(remittanceDate);*/
		log.info("Update Payment of ID  Starts");
		response =paymentService.updatePaymet(sellerPayments);
		log.info("Update Payment ends");
		return response;
	}
}
