package com.thincovate.bibakart.payments.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.thincovate.bibakart.dao.AbstractHibernateDAO;
import com.thincovate.bibakart.entitymodels.Payments;
import com.thincovate.bibakart.payments.model.SellerPayments;

@Repository
public class PaymentsDAO extends AbstractHibernateDAO<Payments> {

	public PaymentsDAO() {
		setClazz(Payments.class);
	}

	/*
	 * public List<String> findIds(String column){ Query q =
	 * getCurrentSession().createQuery("select "+column+" from " +
	 * Payments.class)); return q.list(); }
	 */
	@SuppressWarnings("unchecked")
	public List<Integer> getOrders(String referenceNo) {
		String query = "select order_id from payments_master where reference_no = '" + referenceNo + "'";
		return getCurrentSession().createSQLQuery(query).list();
	}
	@SuppressWarnings("unchecked")
	public int updatePayments(SellerPayments sellerPayment) {
		String query = "update payments_master set reference_no ='"+sellerPayment.getReferenceNo()+"' , bank_name='"+sellerPayment.getBankName()+"', status = 'completed' where remittance_date='"+sellerPayment.getRemittanceDate()+"' and seller_id = "+sellerPayment.getSellerId();
		return getCurrentSession().createSQLQuery(query).executeUpdate();
	}
}
