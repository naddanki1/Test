package com.thincovate.bibakart.payments.dao;

import org.springframework.stereotype.Repository;

import com.thincovate.bibakart.dao.AbstractHibernateDAO;
import com.thincovate.bibakart.payments.model.PaymentDetails;

@Repository
public class PaymentsViewDAO extends AbstractHibernateDAO<PaymentDetails> {

	public PaymentsViewDAO() {
		setClazz(PaymentDetails.class);
	}
}
