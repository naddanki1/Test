package com.thincovate.bibakart.payments.model;

import java.util.List;

import com.thincovate.bibakart.orders.model.Order;
import com.thincovate.bibakart.orders.model.OrderItem;

public class Payment {

	private Integer paymentId;
	private Long sellerId;
	private Long OrderId;
	private String businessName;
	private String storeDisplayName;
	private double cartValue;
	private double totalTaxedApplied;
	private double totalOrderAmount;
	private Double orderValue;
	private Double chargesApplicable;
	private String remittanceDate;
	private String bankName;
	private String referenceNo;
	private String status;
	private Double payableAmount;
	private String orderCreatedDate;
	private String createdDate;
	private String modifiedDate;
	private String createdBy;
	private String modifiedBy;
	private List<OrderItem> items;
	private Order order;

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getOrderCreatedDate() {
		return orderCreatedDate;
	}

	public void setOrderCreatedDate(String orderCreatedDate) {
		this.orderCreatedDate = orderCreatedDate;
	}

	public List<OrderItem> getItems() {
		return items;
	}

	public void setItems(List<OrderItem> items) {
		this.items = items;
	}

	public Double getPayableAmount() {
		return payableAmount;
	}

	public void setPayableAmount(Double payableAmount) {
		this.payableAmount = payableAmount;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public Long getOrderId() {
		return OrderId;
	}

	public void setOrderId(Long orderId) {
		OrderId = orderId;
	}

	public Integer getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(Integer paymentId) {
		this.paymentId = paymentId;
	}

	public Long getSellerId() {
		return sellerId;
	}

	public void setSellerId(Long sellerId) {
		this.sellerId = sellerId;
	}

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public String getStoreDisplayName() {
		return storeDisplayName;
	}

	public void setStoreDisplayName(String storeDisplayName) {
		this.storeDisplayName = storeDisplayName;
	}

	public double getCartValue() {
		return cartValue;
	}

	public void setCartValue(double cartValue) {
		this.cartValue = cartValue;
	}

	public double getTotalTaxedApplied() {
		return totalTaxedApplied;
	}

	public void setTotalTaxedApplied(double totalTaxedApplied) {
		this.totalTaxedApplied = totalTaxedApplied;
	}

	public double getTotalOrderAmount() {
		return totalOrderAmount;
	}

	public void setTotalOrderAmount(double totalOrderAmount) {
		this.totalOrderAmount = totalOrderAmount;
	}

	public Double getOrderValue() {
		return orderValue;
	}

	public void setOrderValue(Double orderValue) {
		this.orderValue = orderValue;
	}

	public Double getChargesApplicable() {
		return chargesApplicable;
	}

	public void setChargesApplicable(Double chargesApplicable) {
		this.chargesApplicable = chargesApplicable;
	}

	public String getRemittanceDate() {
		return remittanceDate;
	}

	public void setRemittanceDate(String remittanceDate) {
		this.remittanceDate = remittanceDate;
	}

	public String getReferenceNo() {
		return referenceNo;
	}

	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

}
