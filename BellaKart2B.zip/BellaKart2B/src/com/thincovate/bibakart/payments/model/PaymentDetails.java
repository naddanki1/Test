package com.thincovate.bibakart.payments.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "payments_details")
public class PaymentDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "payment_id")
	private Integer paymentId;

	@Column(name = "order_value")
	private Double orderValue;

	@Column(name = "charges_applicable")
	private Double chargesApplicable;

	@Column(name = "remittance_date")
	private Date remittanceDate;

	@Column(name = "reference_no")
	private String referenceNo;

	@Column(name = "status")
	private String status;

	@Column(name = "seller_id")
	private String sellerId;

	@Column(name = "store_display_name")
	private String storeDisplayName;

	public Integer getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(Integer paymentId) {
		this.paymentId = paymentId;
	}

	public Double getOrderValue() {
		return orderValue;
	}

	public void setOrderValue(Double orderValue) {
		this.orderValue = orderValue;
	}

	public Double getChargesApplicable() {
		return chargesApplicable;
	}

	public void setChargesApplicable(Double chargesApplicable) {
		this.chargesApplicable = chargesApplicable;
	}

	public Date getRemittanceDate() {
		return remittanceDate;
	}

	public void setRemittanceDate(Date remittanceDate) {
		this.remittanceDate = remittanceDate;
	}

	public String getReferenceNo() {
		return referenceNo;
	}

	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSellerId() {
		return sellerId;
	}

	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}

	public String getStoreDisplayName() {
		return storeDisplayName;
	}

	public void setStoreDisplayName(String storeDisplayName) {
		this.storeDisplayName = storeDisplayName;
	}

}
