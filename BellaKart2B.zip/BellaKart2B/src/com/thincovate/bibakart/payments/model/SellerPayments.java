package com.thincovate.bibakart.payments.model;

import java.util.List;

import com.thincovate.bibakart.orders.model.Order;

public class SellerPayments {

	private Long sellerId;
	private String storeDisplayName;
	private double totalAmount;
	private double deductions;
	private double payableAmount;
	private String remittanceDate;
	private String referenceNo;
	private String bankName;
	private List<Order> order;

	public String getReferenceNo() {
		return referenceNo;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}

	public String getRemittanceDate() {
		return remittanceDate;
	}

	public void setRemittanceDate(String remittanceDate) {
		this.remittanceDate = remittanceDate;
	}

	public Long getSellerId() {
		return sellerId;
	}

	public void setSellerId(Long sellerId) {
		this.sellerId = sellerId;
	}

	public String getStoreDisplayName() {
		return storeDisplayName;
	}

	public void setStoreDisplayName(String storeDisplayName) {
		this.storeDisplayName = storeDisplayName;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public double getDeductions() {
		return deductions;
	}

	public void setDeductions(double deductions) {
		this.deductions = deductions;
	}

	public double getPayableAmount() {
		return payableAmount;
	}

	public void setPayableAmount(double payableAmount) {
		this.payableAmount = payableAmount;
	}

	public List<Order> getOrder() {
		return order;
	}

	public void setOrder(List<Order> order) {
		this.order = order;
	}

}
