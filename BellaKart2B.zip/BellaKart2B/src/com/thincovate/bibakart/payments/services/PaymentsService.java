package com.thincovate.bibakart.payments.services;

import javax.servlet.http.HttpServletRequest;

import com.thincovate.bibakart.common.model.ResponseWrapper;
import com.thincovate.bibakart.payments.model.Payment;
import com.thincovate.bibakart.payments.model.SellerPayments;

public interface PaymentsService {

	boolean savePayment(Payment payment);

	ResponseWrapper getPayments(String status, int offset, int maxResults);
	
	ResponseWrapper getPaymentsBySeller(String sellerId,String status, int offset, int maxResults);
	
	ResponseWrapper getPayments(HttpServletRequest request,String startDate, String endDate,int offset, int maxResults);

	ResponseWrapper getSellerPayments(String type,int offset, int maxResults);
	
	ResponseWrapper getPayment(String paymentId);

	ResponseWrapper getPayments(HttpServletRequest request, String startDate, String endDate);
	

	ResponseWrapper updatePaymet(SellerPayments sellerPayment);
	
}
