package com.thincovate.bibakart.payments.services.impl;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.thincovate.bibakart.common.model.PaymentResponseWrapper;
import com.thincovate.bibakart.common.model.ResponseWrapper;
import com.thincovate.bibakart.common.utils.BibakartConstants;
import com.thincovate.bibakart.common.utils.DateUtils;
import com.thincovate.bibakart.common.utils.Responses;
import com.thincovate.bibakart.configs.services.ConfigsServicesI;
import com.thincovate.bibakart.entitymodels.OrdersMaster;
import com.thincovate.bibakart.entitymodels.Payments;
import com.thincovate.bibakart.entitymodels.SellerMaster;
import com.thincovate.bibakart.orders.dao.OrderItemsDAO;
import com.thincovate.bibakart.orders.dao.OrdersMasterDAO;
import com.thincovate.bibakart.orders.model.Order;
import com.thincovate.bibakart.orders.services.OrdersService;
import com.thincovate.bibakart.payments.dao.PaymentsDAO;
import com.thincovate.bibakart.payments.dao.PaymentsViewDAO;
import com.thincovate.bibakart.payments.model.Payment;
import com.thincovate.bibakart.payments.model.SellerPayments;
import com.thincovate.bibakart.payments.services.PaymentsService;
import com.thincovate.bibakart.registration.dao.SellerMasterDAO;
import com.thincovate.bibakart.sessionmgnt.model.Seller;

@Service
@Transactional
public class PaymentsServiceImpl implements PaymentsService {

	private static Logger log = Logger.getLogger(PaymentsServiceImpl.class);
	@Autowired
	private PaymentsDAO paymentsDAO;

	@Autowired
	private SellerMasterDAO sellerMasterDAO;

	@Autowired
	private OrdersMasterDAO ordersMasterDAO;

	@Autowired
	private OrderItemsDAO orderItemsDAO;

	@Autowired
	private OrdersService ordersService;

	@Autowired
	private ConfigsServicesI configService;
	
	@Autowired
	private PaymentsViewDAO paymentsViewDAO;

	private static String query_payments_remittance_pending ="SELECT p.seller_id,p.store_display_name, SUM(p.payable_amount) AS total_amount, p.reference_no,p.remittance_date FROM ( SELECT pm.seller_id,s.store_display_name,pm.payable_amount, pm.reference_no, pm.remittance_date,pm.status FROM payments_master pm INNER JOIN seller_master s ON pm.seller_id = s.seller_id AND pm.status='pending') p GROUP BY p.seller_id, p.remittance_date";
	private static String query_payments_remittance_next ="SELECT p.seller_id,p.store_display_name, SUM(p.payable_amount) AS total_amount, p.reference_no,p.remittance_date FROM ( SELECT pm.seller_id,s.store_display_name,pm.payable_amount, pm.reference_no, pm.remittance_date,pm.status FROM payments_master pm INNER JOIN seller_master s ON pm.seller_id = s.seller_id AND pm.status='completed') p GROUP BY p.seller_id, p.remittance_date";
	private static String query_payments_by_remittance ="SELECT p.seller_id,p.store_display_name, SUM(p.payable_amount) AS total_amount, p.reference_no,p.remittance_date FROM ( SELECT pm.seller_id,s.store_display_name,pm.payable_amount, pm.reference_no, pm.remittance_date,pm.status FROM payments_master pm INNER JOIN seller_master s ON pm.seller_id = s.seller_id AND pm.status= ? and pm.remittance_date = ?) p GROUP BY p.seller_id";
	@Override
	public boolean savePayment(Payment payment) {
		try {
			Payments p = new Payments();
			p.setChargesApplicable(payment.getChargesApplicable());
			p.setOrderValue(payment.getOrderValue());
			p.setRemittanceDate(DateUtils.parseDate(payment.getRemittanceDate()));
			p.setStatus(payment.getStatus());
			p.setReferenceNo(payment.getReferenceNo());
			p.setCreatedBy(payment.getCreatedBy());
			p.setCreatedDate(DateUtils.getCurrentDate());
			OrdersMaster order = ordersMasterDAO.findOne(payment.getOrderId());
			if (order != null)
				p.setOrdersMaster(order);
			SellerMaster seller = sellerMasterDAO.findOne(payment.getSellerId());
			if (seller != null)
				p.setSellerMaster(seller);
			paymentsDAO.save(p);
			return true;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
		}
		return false;

	}

	@Override
	public ResponseWrapper getPayments(String status, int offset, int maxResults) {
		PaymentResponseWrapper response = new PaymentResponseWrapper();
	/*	try {
			List<Payment> payments = null;
			List<Payments> paymentList = null;
			List<SellerPayments> sellerPayments = new ArrayList<SellerPayments>();
			log.info("Status :" + status);
			if (status.equalsIgnoreCase("all")) {
				paymentList = paymentsDAO.findAllByLimit(offset, maxResults);
				response.setTotalPayments(paymentsDAO.getCount(""));
				payments = getPaymentModelList(paymentList);
				response.setPayments(payments);
			} else {
				String q = query_payments_remittance_pending;
				List<Object[]> objectList = paymentsDAO.findReqColumn(q, offset, maxResults);
				for(Object[] object : objectList){
					SellerPayments sellerPayment = new SellerPayments();
						sellerPayment.setSellerId(Long.parseLong(object[0].toString()));
						sellerPayment.setStoreDisplayName(object[1].toString());
						sellerPayment.setTotalAmount(Double.parseDouble(object[2].toString()));
						sellerPayment.setReferenceNo(object[3]==null?"":object[3].toString());
						sellerPayment.setRemittanceDate(object[4].toString());
					sellerPayments.add(sellerPayment);
				}
				response.setSellerPayments(sellerPayments);
				response.setTotalPayments(paymentsDAO.getCount(" where status ='" + status + "'"));
			}

			if (payments != null) {
				response.setCode(Responses.SUCCESS_CODE);
				response.setStatus(Responses.SUCCESS_STATUS);
				response.setMessage(Responses.SUCCESS_MSG);
			}
			return response;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		response = new PaymentResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.FAILURE_MSG,
				null);*/
		return response;
	}

	public List<Payment> getPaymentModelList(List<Payments> paymentList) {

		List<Payment> payments = new ArrayList<Payment>();
		try {
			for (Payments p : paymentList) {
				Payment payment = new Payment();
				SellerMaster seller = p.getSellerMaster();
				OrdersMaster order = p.getOrdersMaster();

				payment.setItems(ordersService.getOrderItems(order.getOrderId()));
				payment.setCartValue(order.getCartValue());
				payment.setChargesApplicable(p.getChargesApplicable());
				payment.setOrderId(order.getOrderId());
				payment.setOrderValue(p.getOrderValue());
				payment.setPaymentId(p.getPaymentId());
				payment.setReferenceNo(p.getReferenceNo());
				payment.setRemittanceDate(DateUtils.format(p.getRemittanceDate()));
				payment.setSellerId(seller.getSellerId());
				payment.setStatus(p.getStatus());
				payment.setTotalOrderAmount(order.getTotalOrderAmount());
				payment.setTotalTaxedApplied(order.getTotalTaxedApplied());
				payment.setPayableAmount(order.getTotalOrderAmount()); // TODO
				payment.setCreatedDate(DateUtils.format(p.getCreatedDate()));
				payment.setOrderCreatedDate(DateUtils.format(order.getCratedDt()));
				payment.setCreatedBy(p.getCreatedBy());
				payment.setModifiedBy(p.getModifiedBy());
				payment.setModifiedDate(p.getModifiedDate() == null ? "" : p.getModifiedDate().toString());
				payments.add(payment);
			}
			return payments;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public ResponseWrapper getPaymentsBySeller(String sellerId, String status, int offset, int maxResults) {
		PaymentResponseWrapper response = new PaymentResponseWrapper();
		try {
			List<Payment> payments = null;
			List<Payments> paymentList = null;
			status = (status == null ? "all" : status);
			if (status.equalsIgnoreCase("all")) {
				paymentList = paymentsDAO.findAllByColumn("sellerMaster", sellerId, offset, maxResults);
				log.info(paymentsDAO.getCount(" where sellerMaster='" + sellerId + "'"));
				response.setTotalPayments(paymentsDAO.getCount(" where sellerMaster='" + sellerId + "'"));
			} else {
				paymentList = paymentsDAO.findAllByColumn("sellerMaster", sellerId, "status", status, offset,maxResults);
				log.info(paymentsDAO.getCount(" where sellerMaster='" + sellerId + "' and status ='" + status + "'"));
				response.setTotalPayments(paymentsDAO.getCount(" where sellerMaster='" + sellerId + "' and status ='" + status + "'"));
			}
			payments = getPaymentModelList(paymentList);
			if (payments != null) {
				response.setCode(Responses.SUCCESS_CODE);
				response.setStatus(Responses.SUCCESS_STATUS);
				response.setMessage(Responses.SUCCESS_MSG);
				response.setPayments(payments);
			}

			return response;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		response = new PaymentResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.FAILURE_MSG,
				null);
		return response;
	}

	@Override
	public ResponseWrapper getPayments(HttpServletRequest request,String startDate, String endDate, int offset, int maxResults) {
		PaymentResponseWrapper response = new PaymentResponseWrapper();
		try {
			List<Payment> payments = null;
			List<Payments> paymentList = null;
			String query = "";
			HttpSession session = request.getSession();
			Seller seller = (Seller)session.getAttribute("seller");
			if(seller!=null){
				query = " sellerMaster = "+seller.getSellerId()+" and remittanceDate >= '" + startDate + "' and remittanceDate <= '" + endDate + "'";
			}else{
				query = "remittanceDate >= '" + startDate + "' and remittanceDate <= '" + endDate + "'";
			}
			paymentList = paymentsDAO.findAllByString(query, offset, maxResults);
			
			payments = getPaymentModelList(paymentList);
			log.info("size" + payments.size());
			if (payments != null)
				response = new PaymentResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_MSG,
						Responses.SUCCESS_STATUS, payments);
			response.setTotalPayments(paymentsDAO.getCount(" where "+query));
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			response = new PaymentResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.FAILURE_MSG);
		}

		return response;
	}
	@Override
	public ResponseWrapper getPayments(HttpServletRequest request,String startDate, String endDate) {
		PaymentResponseWrapper response = new PaymentResponseWrapper();
		try {
			List<Payment> payments = null;
			List<Payments> paymentList = null;
			String query = "";
			HttpSession session = request.getSession();
			Seller seller = (Seller)session.getAttribute("seller");
			if(seller!=null){
				query = " sellerMaster = "+seller.getSellerId()+" and remittanceDate >= '" + startDate + "' and remittanceDate <= '" + endDate + "'";
			}else{
				query = "remittanceDate >= '" + startDate + "' and remittanceDate <= '" + endDate + "'";
			}
			paymentList = paymentsDAO.findAllByString(query);
			
			payments = getPaymentModelList(paymentList);
			log.info("size" + payments.size());
			if (payments != null)
				response = new PaymentResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_MSG,
						Responses.SUCCESS_STATUS, payments);
			response.setTotalPayments(paymentsDAO.getCount(" where "+query));
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			response = new PaymentResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.FAILURE_MSG);
		}

		return response;
	}

	@Override
	public ResponseWrapper getSellerPayments(String type, int offset, int maxResults) {
		PaymentResponseWrapper response = new PaymentResponseWrapper();
		try {
			List<SellerPayments> sellerPayments = new ArrayList<SellerPayments>();
			String nextRemmitanceDate = configService.getValueByKey(BibakartConstants.NEXT_REMITTANCE_DATE);
			String lastRemittanceDate = configService.getValueByKey(BibakartConstants.LAST_REMITTANCE_DATE);
			String query = "";
			String query_for_count = "";
			 nextRemmitanceDate = DateUtils.formatDate(DateUtils.parseDate(nextRemmitanceDate));
			 lastRemittanceDate = DateUtils.formatDate(DateUtils.parseDate(lastRemittanceDate));
			 List<Object[]> objectList = null;
			if (type.equalsIgnoreCase("current")) {
				query = "select p.seller_id,p.store_display_name, SUM(p.payable_amount) AS total_amount,p.reference_no,p.remittance_date,p.bank_name FROM ( SELECT pm.seller_id,s.store_display_name,pm.payable_amount, pm.reference_no, pm.remittance_date,pm.status,pm.bank_name FROM payments_master pm INNER JOIN seller_master s ON pm.seller_id = s.seller_id AND pm.status= 'pending' and pm.remittance_date = '"+nextRemmitanceDate+"') p GROUP BY p.seller_id";
				query_for_count = "select count(*) as total from (SELECT  p.seller_id,p.store_display_name, SUM(p.payable_amount) AS total_amount, p.reference_no,p.remittance_date FROM ( SELECT pm.seller_id,s.store_display_name,pm.payable_amount, pm.reference_no, pm.remittance_date,pm.status FROM payments_master pm INNER JOIN seller_master s ON pm.seller_id = s.seller_id AND pm.status= 'pending' and pm.remittance_date = '"+nextRemmitanceDate+"') p GROUP BY p.seller_id) m";

			} else if (type.equalsIgnoreCase("completed")) {
				query = "select p.seller_id,p.store_display_name, SUM(p.payable_amount) AS total_amount, p.reference_no,p.remittance_date,p.bank_name FROM ( SELECT pm.seller_id,s.store_display_name,pm.payable_amount, pm.reference_no, pm.remittance_date,pm.status,pm.bank_name FROM payments_master pm INNER JOIN seller_master s ON pm.seller_id = s.seller_id AND pm.status= 'completed' and pm.remittance_date = '"+lastRemittanceDate+"') p GROUP BY p.seller_id";
				query_for_count = "select count(*) as total from (SELECT  p.seller_id,p.store_display_name, SUM(p.payable_amount) AS total_amount, p.reference_no,p.remittance_date FROM ( SELECT pm.seller_id,s.store_display_name,pm.payable_amount, pm.reference_no, pm.remittance_date,pm.status FROM payments_master pm INNER JOIN seller_master s ON pm.seller_id = s.seller_id AND pm.status= 'completed' and pm.remittance_date = '"+lastRemittanceDate+"') p GROUP BY p.seller_id) m";objectList = paymentsDAO.findReqColumn(query, offset, maxResults);
			}
			objectList = paymentsDAO.findReqColumn(query,  offset, maxResults);
				for(Object[] object : objectList){
					SellerPayments sellerPayment = new SellerPayments();
					List<Order> orders = new ArrayList<Order>();
					List<Integer> ordersList = paymentsDAO.getOrders(object[3]==null?"":object[3].toString());
					log.info("dfs0"+ordersList.size());
					for(Integer order : ordersList){
						Order o = new Order();
						o.setOrderId(order==null?0:Long.parseLong(order.toString()));
						orders.add(o);
					}
						sellerPayment.setSellerId(Long.parseLong(object[0].toString()));
						sellerPayment.setStoreDisplayName(object[1].toString());
						sellerPayment.setTotalAmount(Double.parseDouble(object[2].toString()));
						sellerPayment.setReferenceNo(object[3]==null?"":object[3].toString());
						sellerPayment.setRemittanceDate(object[4].toString());
						sellerPayment.setBankName(object[5]==null?"":object[5].toString());
						sellerPayment.setOrder(orders);
						sellerPayments.add(sellerPayment);
				}
				response.setSellerPayments(sellerPayments);
				
				log.info(query_for_count);
				response.setTotalPayments(Integer.parseInt(paymentsDAO.getTotalCount(query_for_count)));
		
			response.setCode(Responses.SUCCESS_CODE);
			response.setStatus(Responses.SUCCESS_STATUS);
			response.setMessage(Responses.SUCCESS_MSG);
			response.setSellerPayments(sellerPayments);

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			response.setCode(Responses.FAILURE_CODE);
			response.setStatus(Responses.FAILURE_STATUS);
			response.setMessage(Responses.FAILURE_MSG);
		}
		return response;
	}

	@Override
	public ResponseWrapper getPayment(String paymentId) {
		PaymentResponseWrapper response = new PaymentResponseWrapper();
		try {
			List<Payment> payments = null;
			List<Payments> paymentList = null;
			paymentList = paymentsDAO.findAllByColumn("paymentId", paymentId);
			payments = getPaymentModelList(paymentList);
			if (payments != null) {
				response.setCode(Responses.SUCCESS_CODE);
				response.setStatus(Responses.SUCCESS_STATUS);
				response.setMessage(Responses.SUCCESS_MSG);
				response.setPayments(payments);
			}
			return response;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		response = new PaymentResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.FAILURE_MSG,	null);
		return response;
	}

	@Override
	public ResponseWrapper updatePaymet(SellerPayments sellerPayment) {
		PaymentResponseWrapper response = new PaymentResponseWrapper();
		try {
			 int rows=paymentsDAO.updatePayments(sellerPayment);
			 log.info("effected rows"+rows);
				response.setCode(Responses.SUCCESS_CODE);
				response.setStatus(Responses.SUCCESS_STATUS);
				response.setMessage(Responses.SUCCESS_MSG);
			
			return response;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		response = new PaymentResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.FAILURE_MSG,	null);
		return response;
	}
}
