package com.thincovate.bibakart.registration.controller;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.thincovate.bibakart.admin.services.CategoriesService;
import com.thincovate.bibakart.common.model.CategoryResponseWrapper;
import com.thincovate.bibakart.common.model.NotificationModel;
import com.thincovate.bibakart.common.model.ResponseWrapper;
import com.thincovate.bibakart.common.notifications.SMSManager;
import com.thincovate.bibakart.common.services.UtilService;
import com.thincovate.bibakart.common.utils.BibakartConstants;
import com.thincovate.bibakart.common.utils.CommonUtils;
import com.thincovate.bibakart.common.utils.DateUtils;
import com.thincovate.bibakart.common.utils.PathConstants;
import com.thincovate.bibakart.common.utils.Responses;
import com.thincovate.bibakart.common.utils.SessionProperties;
import com.thincovate.bibakart.entitymodels.BankDetails;
import com.thincovate.bibakart.entitymodels.Categories;
import com.thincovate.bibakart.entitymodels.CategoriesNew;
import com.thincovate.bibakart.entitymodels.ProfileVerification;
import com.thincovate.bibakart.entitymodels.ProspectiveSellers;
import com.thincovate.bibakart.entitymodels.SellerDocs;
import com.thincovate.bibakart.entitymodels.SellerMaster;
import com.thincovate.bibakart.registration.dao.CategoriesNewDAO;
import com.thincovate.bibakart.registration.dao.SellerDocsDAO;
import com.thincovate.bibakart.registration.dao.SellerMasterDAO;
import com.thincovate.bibakart.registration.services.BankDetailsService;
import com.thincovate.bibakart.registration.services.ProfileVerificationService;
import com.thincovate.bibakart.registration.services.ProspectiveSellersService;
import com.thincovate.bibakart.registration.services.SellerMasterService;

@Controller
@RequestMapping("/")
public class RegistrationController {

	@Autowired
	ProspectiveSellersService prospectiveSellerService;

	@Autowired
	ProfileVerificationService profileVerifyService;

	@Autowired
	SellerMasterService sellerMasterService;

	@Autowired
	private CategoriesService categoryService;

	@Autowired
	private BankDetailsService bankDetailsService;

/*	@Autowired
	private SellerDocsService sellerDocsService;*/
	
	@Autowired
	private SellerMasterDAO sellerMasterDAO;
	
	@Autowired
	private SellerDocsDAO sellerDocsDAO;
	
	@Autowired
	private CategoriesNewDAO categoriesNewDAO;
	

	@Autowired
	UtilService utilService;

	static Logger log = Logger.getLogger(RegistrationController.class);

	@RequestMapping("/verify")
	public @ResponseBody ResponseWrapper verify(@RequestParam String type,@RequestParam String value){
		
		if(type.equalsIgnoreCase("email"))
			return prospectiveSellerService.verifyEmail(value);
		else if(type.equalsIgnoreCase("mobile"))
			return prospectiveSellerService.verifyMobile(value);
		else
			return new ResponseWrapper(Responses.CUSTOM_CODE, Responses.ERROR_STATUS, Responses.ERROR_MSG);
	}

	
	@RequestMapping(value = PathConstants.LOGIN, method = RequestMethod.POST)
	public @ResponseBody ResponseWrapper saveProspectSeller(@Valid @RequestBody ProspectiveSellers ps, BindingResult result, HttpServletRequest request) {

		log.info("In saveProspectSeller:");
		ResponseWrapper returnModel = null;
		List<String> errors = new ArrayList<String>();
		
		if (result.hasFieldErrors()) {
			log.info("*****Invalid Data*****");
			for (FieldError e : result.getFieldErrors()) {
				log.error(Responses.FIELD_NAME + e.getField() + Responses.FIELD_ERROR + e.getDefaultMessage());
				errors.add(Responses.FIELD_NAME + e.getField() + Responses.FIELD_ERROR + e.getDefaultMessage());
			}
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.ERROR_STATUS, Responses.ERROR_MSG, errors);
		}

		if (errors.isEmpty()) {
			boolean flag = prospectiveSellerService.isProspSellerExists(ps);
			if (!flag) {
				ProspectiveSellers psObj = prospectiveSellerService.checkDetails(ps, CommonUtils.getIpAddress(request),	"guest");

				if (psObj.getStatus().equals(BibakartConstants.PS_EMAILVERIFY)) {
					String emailVerifycode = profileVerifyService.getEmailVerifyCode(request,ps.getEmailAddr(), psObj);
					log.info(emailVerifycode);
					// send Verification Link to user
					utilService.sendEmail(emailVerifycode, ps.getEmailAddr(), request);
					
					returnModel = new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS,	"check your inbox for further Registration process steps");
				} else {
					// email verification failed
					returnModel = new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS,	"Registration Processs already started for this User!!");
				}

			} else {
				returnModel = new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS,	"Registration Processs already started for this User!!");
			}
		} else {
			returnModel = new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
		return returnModel;
	}
	
	@RequestMapping(value ="emailVerify")
	public ModelAndView goVerify(@RequestParam String token ,HttpServletRequest request, HttpSession session) {
		ArrayList<String> errors = new ArrayList<String>();
		ArrayList<String> success = new ArrayList<String>();
		ArrayList<String> warnings = new ArrayList<String>();
		ArrayList<String> messages = new ArrayList<String>();
		ArrayList<String> mailMessages = new ArrayList<String>();
		String redirectPath = null;
		try {
			/*log.info(id);
			id = CommonUtils.decryptText(id);
			log.info(id);*/
			
			ProfileVerification pv = profileVerifyService.findOneByColumn("emailVerificationCode", token);
			if(pv !=null){
			pv.setEmailVerificationStatus((byte) 1);
			profileVerifyService.saveOrupdate(pv);

			String emailAddress = pv.getProspectiveSellers().getEmailAddr();
			
			List<ProspectiveSellers> list = prospectiveSellerService.findAllByColumn("emailAddr", emailAddress);
			
			session.setAttribute(SessionProperties.EMAIL_ADDR, list.get(0).getEmailAddr());
			session.setAttribute(SessionProperties.MOBILE_NO, list.get(0).getMobile());
			
			if (list.size() > 0) {
				if (list.get(0).getStatus().equals(BibakartConstants.PS_EMAILVERIFY)
						|| list.get(0).getStatus().equals(BibakartConstants.MOBILE_VERIFY_PENDING)) {

					String random = CommonUtils.generateRandomString(5, CommonUtils.Mode.NUMERIC);
					// send OTP to user
					SMSManager.getInstance().sendSMS(pv.getProspectiveSellers().getMobile().toString(), random, false);
					// mv.setMobileNo(list.get(0).getMobile());
					pv.setMobileVerificationStatus((byte) 0);
					pv.setMobileVerificationCode(random);
					profileVerifyService.saveOrupdate(pv);
		
					session.setAttribute(SessionProperties.MOBILECONFIRMCODE, random);

					prospectiveSellerService.updateStatus(BibakartConstants.MOBILE_VERIFY_PENDING,
							list.get(0).getEmailAddr(), "" + list.get(0).getMobile());
					session.setAttribute(SessionProperties.MOBILECONFIRMPOPUP, "active");
					redirectPath = PathConstants.GO_REG1;
				} else {
					session.setAttribute(SessionProperties.EMAIL_ADDR, list.get(0).getEmailAddr());
					session.setAttribute(SessionProperties.MOBILE_NO, list.get(0).getMobile());
					messages.add("Your Email Address & Mobile Number is Already Verified.");
					log.info("Your Email Address & Mobile Number is Already Verified.");
					// TODO set path using goststus
		/*			String st =goStatus(list.get(0).getStatus();
					if(st.equals(PathConstants.REGISTER_CATEGORY_DETAILS)|| st.equals(PathConstants.REGISTER_BUSINESS_DETAILS))*/
					redirectPath = "redirect:"+goStatus(list.get(0).getStatus());
				}

			}
			}
		} catch (NumberFormatException e) {
			// TODO
			e.printStackTrace();
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
		} finally {
			NotificationModel nm = new NotificationModel(errors, success, warnings, messages, mailMessages);
			session.setAttribute("messages", nm);
			errors = null;
			success = null;
			warnings = null;
			messages = null;
			mailMessages = null;
		}
		return new ModelAndView(redirectPath);

	}

	@RequestMapping("/resendOTP")
	public @ResponseBody ResponseWrapper resendOTP(HttpSession session){
		try{
		List<ProspectiveSellers> list = prospectiveSellerService.findAllByColumn("mobile",session.getAttribute(SessionProperties.MOBILE_NO).toString());
		if (list.size() > 0) {
			if (list.get(0).getStatus().equals(BibakartConstants.PS_EMAILVERIFY)
					|| list.get(0).getStatus().equals(BibakartConstants.MOBILE_VERIFY_PENDING)) {
				ProfileVerification pv =list.get(0).getProfileVerification();
				String random = CommonUtils.generateRandomString(5, CommonUtils.Mode.NUMERIC);
				// send OTP to user
				SMSManager.getInstance().sendSMS(pv.getProspectiveSellers().getMobile().toString(), random, false);
				// mv.setMobileNo(list.get(0).getMobile());
				pv.setMobileVerificationStatus((byte) 0);
				pv.setMobileVerificationCode(random);
				profileVerifyService.saveOrupdate(pv);
	
				session.setAttribute(SessionProperties.MOBILECONFIRMCODE, random);

				prospectiveSellerService.updateStatus(BibakartConstants.MOBILE_VERIFY_PENDING,
						list.get(0).getEmailAddr(), "" + list.get(0).getMobile());
				session.setAttribute(SessionProperties.MOBILECONFIRMPOPUP, "active");
				return new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS, Responses.SUCCESS_MSG);
			} else {
				session.setAttribute(SessionProperties.EMAIL_ADDR, list.get(0).getEmailAddr());
				session.setAttribute(SessionProperties.MOBILE_NO, list.get(0).getMobile());
				
				return new ResponseWrapper(Responses.FAILURE_CODE,Responses.FAILURE_STATUS,Responses.ERROR_MSG);
			}

		}
		}catch(Exception e){
			// TODO
			e.printStackTrace();
		}
		return new ResponseWrapper(Responses.FAILURE_CODE,Responses.FAILURE_STATUS,Responses.ERROR_MSG);
	}

	@RequestMapping("/getLink")
	public @ResponseBody ResponseWrapper getLink(HttpServletRequest request, HttpSession session,@RequestParam String emailAddr) {
		try {
			ProspectiveSellers ps = prospectiveSellerService.findAllByColumn("emailAddr", emailAddr).get(0);
			if (ps != null) {
				ProfileVerification pv = ps.getProfileVerification();
				String random = CommonUtils.generateRandomString(25, CommonUtils.Mode.ALPHANUMERIC);
				pv.setEmailVerificationCode(random);
				pv.setEmailVerificationStatus((byte) 0);
				pv.setProfileVerificationStatus((byte) 0);
				pv.setCreatedBy("Guest");
				pv.setCreatedDate(DateUtils.getCurrentDate());
				pv.setProspectiveSellers(ps);
				profileVerifyService.saveOrupdate(pv);
				String code = pv.getEmailVerificationCode();
				String link="?token=" +code;
				//String link = "vc=" + code + "&id=" + id;
				utilService.sendEmail(link, ps.getEmailAddr(), request);
				return new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS,"check your inbox for further Registration process steps");
			}

		} catch (Exception e) {
			// TODO
			e.printStackTrace();

		}
		return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
	}
	
	@RequestMapping(value = PathConstants.REGISTER_CONTACT_DETAILS)
	public ModelAndView goReg1(HttpSession session,HttpServletRequest request, ModelMap model) {
		ModelAndView mvc = null;
		boolean sessionFlag =CommonUtils.checkStatus(session, request); // true if session available
		boolean sellerFlag = CommonUtils.checkStatus(session); // true if seller object not found in session
		if (sessionFlag && sellerFlag) {
		mvc = new ModelAndView(PathConstants.GO_REG1);
		SellerMaster sm = new SellerMaster();
		sm.setEmailAddr((String) session.getAttribute(SessionProperties.EMAIL_ADDR));
		mvc.addObject("sm", sm);
		model.addAttribute("formData", sm);
		}else if(!sellerFlag){
			mvc = new ModelAndView("redirect:/vendor/profile");
		}else{
			mvc = new ModelAndView("login");
		}
		return mvc;
	}

	@RequestMapping(value = PathConstants.MOBILE_VERIFY, method = RequestMethod.GET)
	public @ResponseBody ResponseWrapper goconfirmSubmit(HttpSession session, HttpServletRequest request) {

		String mobileCode = request.getParameter("confirmCode");
		List<ProspectiveSellers> psList = prospectiveSellerService.findAllByColumn("mobile",session.getAttribute(SessionProperties.MOBILE_NO).toString());

		if (psList.size() > 0) {
			ProspectiveSellers ps = psList.get(0);
			List<ProfileVerification> mvList = profileVerifyService.findAllByColumn("prospect_id",	new Integer(ps.getProspectId()).toString());
			if (mvList.size() > 0) {
				ProfileVerification mvold = mvList.get(0);
				if (mobileCode.equals(mvold.getMobileVerificationCode())) {
					mvold.setMobileVerificationStatus((byte) 1);
					mvold.setProfileVerificationStatus(1);
					profileVerifyService.saveOrupdate(mvold);
					prospectiveSellerService.updateStatus(BibakartConstants.PS_MOBILE_VERIFICATION,
							(String) session.getAttribute(SessionProperties.EMAIL_ADDR), "" + ps.getMobile());
					session.removeAttribute(SessionProperties.MOBILECONFIRMPOPUP);
					return new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS, Responses.SUCCESS_MSG);
					// return result;
				}
				else
					return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, "OTP mismatched, enter correct OTP");

			} else {

				return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, "fail");
			}
		} else {
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, "fail");
		}

	}

	@RequestMapping(value = PathConstants.REGISTER_CONTACT_DETAILS, method = RequestMethod.POST)
	public @ResponseBody ResponseWrapper submitRegister1(@RequestBody SellerMaster sm, HttpSession session, Model model,
			HttpServletRequest request) {
		//ResponseWrapper response = null;
		ProspectiveSellers ps = new ProspectiveSellers();
		try {
			ps= prospectiveSellerService.findAllByColumn("emailAddr", sm.getEmailAddr()).get(0);
			
			List<SellerMaster> list = sellerMasterService.findAllByColumn("emailAddr", sm.getEmailAddr(),"mobile",sm.getMobile().toString(), "or");
			if(list.size()>0){
				return new ResponseWrapper(Responses.FAILURE_CODE, goStatus(ps.getStatus()), "You have already submitted your contact details");
			}else{
			sm.setCreatedBy(sm.getEmailAddr());
			sm.setPwd(sm.getPwd());
			sm.setPickupAddr(sm.getPickupAddr());
			sm.setPickupPin(sm.getPickupPin());
			sm.setPrimaryContactName(sm.getPrimaryContactName());
			sm.setCreatedDate(DateUtils.getCurrentDate());
			sm.setSellerSt(BibakartConstants.NEW);
			sm.setStoreDisplayName(BibakartConstants.PENDING);
			sm.setStoreStatus(BibakartConstants.PENDING);
			sm.setContactDetailsVerified(0);
			sellerMasterService.save(sm);
			setLoginSessionValues(sm, session);
		

			// check if a record is present in prospective sellers with either

			boolean flag = prospectiveSellerService.isProspSellerExists(ps);
			if (flag) {

				prospectiveSellerService.updateStatus(BibakartConstants.PS_CONTACT_DETAILS, sm.getEmailAddr(),	sm.getMobile().toString());
			} else {
				prospectiveSellerService.checkDetails(ps, CommonUtils.getIpAddress(request), "guest");
				prospectiveSellerService.updateStatus(BibakartConstants.PS_MOBILE_VERIFICATION, sm.getEmailAddr(), sm.getMobile().toString());
			}
			return new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS, Responses.SUCCESS_MSG);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, goStatus(ps.getStatus()), Responses.ERROR_MSG);

		}

	}

	@RequestMapping(value = PathConstants.REGISTER_CATEGORY_DETAILS)
	public ModelAndView goReg2(HttpSession session, HttpServletRequest request, ModelMap model) {
		ModelAndView mvc = null;
		boolean sessionFlag =CommonUtils.checkStatus(session, request); // true if session available
		boolean sellerFlag = CommonUtils.checkStatus(session); // true if seller object not found in session
		if (sessionFlag && sellerFlag) {
			mvc = new ModelAndView(PathConstants.GO_REG2);
			CategoryResponseWrapper formData = (CategoryResponseWrapper) categoryService.getAllCategoriesInTreeStructure();
			model.addAttribute("catList", formData.getCategories());
		} else if(!sellerFlag){
			mvc = new ModelAndView("redirect:/vendor/profile");
		}else{
			mvc = new ModelAndView("login");
		}
		return mvc;


	}

	@RequestMapping(value = PathConstants.SUBMIT_CATEGORY, method = RequestMethod.POST)
	public @ResponseBody ResponseWrapper  submitCategory(HttpSession session, Model model, HttpServletRequest request) {
		try {
			String selctedCategories = (String) request.getParameter("categories");
			
			//String selctedCategories = categories;
			log.info("Selected Categories :" + selctedCategories);
			String[] arr = selctedCategories.split(",");
			log.info("Selected Categories :" + arr);
			Set<Categories> set = new HashSet<Categories>();

			for (String categoryName : arr) {
				log.info(categoryName);
				//Categories category = categoryService.findById(new Long(categoryId));
				Categories category = categoryService.findOneByColumn("categoryName", categoryName); 
			if(category!=null)
				set.add(category);
			}
			SellerMaster sm = sellerMasterService.findOneByColumn("emailAddr", (String)session.getAttribute(SessionProperties.EMAIL_ADDR));
			sm.setCategorieses(set);
			sellerMasterService.saveOrupdate(sm);

			prospectiveSellerService.updateStatus(BibakartConstants.PS_CATEGORY_DETAILS,(String) session.getAttribute(SessionProperties.EMAIL_ADDR),
					"" + session.getAttribute(SessionProperties.MOBILE_NO));
			return new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS, Responses.SUCCESS_MSG);
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS,Responses.ERROR_MSG);
		}
	}




	@RequestMapping(value = PathConstants.REGISTER_BUSINESS_DETAILS)
	public ModelAndView goReg3(HttpSession session, HttpServletRequest request) {
		ModelAndView mvc = null;
		boolean sessionFlag =CommonUtils.checkStatus(session, request); // true if session available
		boolean sellerFlag = CommonUtils.checkStatus(session); // true if seller object not found in session
		if (sessionFlag && sellerFlag) {
			mvc = new ModelAndView(PathConstants.REGISTER_BUSINESS_DETAILS);
			SellerDocs formData = new SellerDocs();
			List<BankDetails> listBank = bankDetailsService.findAll();
			mvc.addObject("listBank", listBank);
			mvc.addObject("formData", formData);
		} else if(!sellerFlag){
			mvc = new ModelAndView("redirect:/vendor/profile");
		}else{
			mvc = new ModelAndView("login");
		}
		return mvc;
	}

	@RequestMapping(value = PathConstants.SUBMIT_REGISTRATION)
	public @ResponseBody ResponseWrapper submitRegistration(@RequestBody SellerDocs sd, HttpSession session, Model model, HttpServletRequest request) {
		log.info(sd.toString());

		try{
		SellerMaster sm1 = sellerMasterService.findOneByColumn("emailAddr", (String)session.getAttribute(SessionProperties.EMAIL_ADDR));
		Iterator<SellerDocs> iterator=	sm1.getSellerDocs().iterator();
		SellerDocs sellerDocs =null;
		boolean flag= true;
		while(iterator.hasNext() && flag){
			flag=false;
			sellerDocs =iterator.next();
		}
		if(flag){
			sellerDocs= new SellerDocs();
			sellerDocs.setSellerMaster(sm1);
		}
		sellerDocs.setCreatedBy(SessionProperties.EMAIL_ADDR);
		sellerDocs.setCreatedDate(DateUtils.getCurrentDate());
		sellerDocs.setAccName(sd.getAccName());
		sellerDocs.setAccNo(sd.getAccNo());
		sellerDocs.setBankNm(sd.getBankNm());
		sellerDocs.setBusinessNm(sd.getBusinessNm());
		sellerDocs.setPanNo(sd.getPanNo());
		sellerDocs.setTanNo(sd.getTanNo());
		sellerDocs.setTinNo(sd.getTinNo());
		sellerDocs.setCommodities(sd.getCommodities());
		sellerDocs.setIfsc(sd.getIfsc());
		sellerDocs.setCity(sd.getCity());
		sellerDocs.setTinVerified(0L);
		sellerDocs.setTanVerified(0L);
		sellerDocs.setPanVerified(0L);
		sellerDocs.setAccVerified(0L);
		sellerDocs.setAddressProofVerified("0");
		sellerDocs.setIdProofVerified("0");
		
		
		sellerDocsDAO.saveOrupdate(sellerDocs);
		sm1.setStoreDisplayName(sd.getStoreDisplayName().replaceAll("\\s+", " "));
		sm1.setDescription(sd.getStoreDesc());
		sm1.setBusinessName(sd.getBusinessNm());
		sellerMasterService.saveOrupdate(sm1);

		prospectiveSellerService.updateStatus(BibakartConstants.PS_FINISH,(String) session.getAttribute(SessionProperties.EMAIL_ADDR),"" + session.getAttribute(SessionProperties.MOBILE_NO));
		List<SellerMaster> list = sellerMasterService.findAllByColumn("emailAddr",
				(String) session.getAttribute(SessionProperties.EMAIL_ADDR), "mobile",
				"" + session.getAttribute(SessionProperties.MOBILE_NO), "and");
		if (list.size() > 0) {
			SellerMaster sm = list.get(0);
			sm.setStoreDisplayName(sd.getStoreDisplayName());
			sellerMasterService.saveOrupdate(sm);
			setLoginSessionValues(sm, session);
		}

		return new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS, Responses.SUCCESS_MSG);
		}catch(Exception e){
			e.printStackTrace();
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
		}
	}

	private void setLoginSessionValues(SellerMaster sellerMaster, HttpSession session) {

		session.setMaxInactiveInterval(100000);
		session.setAttribute(SessionProperties.SELLER_ID, sellerMaster.getSellerId());
		session.setAttribute(SessionProperties.SELLER_STATUS, sellerMaster.getSellerStatus());
		session.setAttribute(SessionProperties.SELLER_STORE_NAME, sellerMaster.getStoreDisplayName());

		session.setAttribute(SessionProperties.EMAIL_ADDR, sellerMaster.getEmailAddr());
		session.setAttribute(SessionProperties.MOBILE_NO, sellerMaster.getMobile());
		session.setAttribute(SessionProperties.LOGIN_NAME, sellerMaster.getStoreDisplayName());

	}

	private String goStatus(String psStatus) {
		if (psStatus.equals(BibakartConstants.PS_EMAILVERIFY)
				|| psStatus.equals(BibakartConstants.MOBILE_VERIFY_PENDING)
				|| psStatus.equals(BibakartConstants.PS_MOBILE_VERIFICATION)) {

			return  PathConstants.REGISTER_CONTACT_DETAILS;
		}

		else if (psStatus.equals(BibakartConstants.PS_CONTACT_DETAILS)) {

			return  PathConstants.REGISTER_CATEGORY_DETAILS;
		}

		else if (psStatus.equals(BibakartConstants.PS_CATEGORY_DETAILS)) {
			return  PathConstants.REGISTER_BUSINESS_DETAILS;

		}

		else if (psStatus.equals(BibakartConstants.PS_BUSINESS_DETAILS)	|| psStatus.equals(BibakartConstants.PS_FINISH)) {

			return  PathConstants.CATALOG;
		}

		return "error";
	}
	
	@RequestMapping("/verifyStore")
	public @ResponseBody ResponseWrapper verifyStoreName(@RequestParam String storeDisplayName){
		try{
	
		List<SellerMaster> list= sellerMasterDAO.findByValue(storeDisplayName);
		if(list.isEmpty())
			return new ResponseWrapper(Responses.SUCCESS_CODE,Responses.SUCCESS_STATUS,Responses.SUCCESS_MSG);
		}catch(Exception e){
			// TODO 
			e.printStackTrace();
		}
		return new ResponseWrapper(Responses.FAILURE_CODE,Responses.FAILURE_STATUS,Responses.ERROR_MSG);
	}

	@RequestMapping(value="/newCat" , method=RequestMethod.POST)
	@Transactional
	public @ResponseBody ResponseWrapper addNewCategory(@RequestBody String name, HttpSession session) {
		try {
			Long id = (Long) session.getAttribute("sellerID");
			if (name != null && name.length() > 0) {
				Categories category = categoryService.findOneByColumn("categoryName", name);
				if (category == null) {
					CategoriesNew categoryN = categoriesNewDAO.findOneByColumn("categoryName", name);
					if (categoryN != null && categoryN.getCreatedBy().equals(id.toString()))
						return new ResponseWrapper(Responses.CUSTOM_CODE2, Responses.FAILURE_STATUS,"This Category already requested by this Merchant");
					else {
						CategoriesNew newCat = new CategoriesNew();
						newCat.setCategoryName(name);
						newCat.setStatus("pending");
						newCat.setCreatedDate(DateUtils.getCurrentDate());
						newCat.setCreatedBy(id.toString());
						categoriesNewDAO.save(newCat);
						return new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS,Responses.SUCCESS_MSG);
					}
				} else
					return new ResponseWrapper(Responses.CUSTOM_CODE, Responses.FAILURE_STATUS,"Category already existed");
			}
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
		}
		return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, Responses.ERROR_MSG);
	}
	
}
