package com.thincovate.bibakart.registration.dao;

import org.springframework.stereotype.Repository;

import com.thincovate.bibakart.dao.AbstractHibernateDAO;
import com.thincovate.bibakart.entitymodels.BankDetails;

@Repository
public class BankDetailsDAO extends AbstractHibernateDAO<BankDetails> {

	public BankDetailsDAO() {
		setClazz(BankDetails.class);
	}
}
