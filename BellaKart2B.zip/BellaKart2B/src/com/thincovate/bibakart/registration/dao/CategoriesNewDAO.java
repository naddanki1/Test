package com.thincovate.bibakart.registration.dao;

import org.springframework.stereotype.Repository;

import com.thincovate.bibakart.dao.AbstractHibernateDAO;
import com.thincovate.bibakart.entitymodels.CategoriesNew;

@Repository
public class CategoriesNewDAO extends AbstractHibernateDAO<CategoriesNew> {

	public CategoriesNewDAO() {
		setClazz(CategoriesNew.class);
	}
}
