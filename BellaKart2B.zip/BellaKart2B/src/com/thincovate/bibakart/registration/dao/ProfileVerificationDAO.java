package com.thincovate.bibakart.registration.dao;

import java.util.List;

import com.thincovate.bibakart.entitymodels.ProfileVerification;

public interface ProfileVerificationDAO {

	ProfileVerification findOne(long id);
	
	ProfileVerification findById(long id);

	void saveOrupdate(ProfileVerification ev);

	ProfileVerification findOneByColumn(String string, String parameter);

	void save(ProfileVerification ev);

	List<ProfileVerification> findAllByColumn(String string, String emailAddress);
}
