package com.thincovate.bibakart.registration.dao;

import org.springframework.stereotype.Repository;

import com.thincovate.bibakart.dao.AbstractHibernateDAO;
import com.thincovate.bibakart.entitymodels.SellerDocs;

@Repository
public class SellerDocsDAO extends AbstractHibernateDAO<SellerDocs> {

	public SellerDocsDAO() {
		setClazz(SellerDocs.class);
	}

}
