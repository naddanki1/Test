package com.thincovate.bibakart.registration.dao;

import org.springframework.stereotype.Repository;

import com.thincovate.bibakart.dao.AbstractHibernateDAO;
import com.thincovate.bibakart.entitymodels.SellerMaster;

@Repository
public class SellerMasterDAO extends AbstractHibernateDAO<SellerMaster> {

	public SellerMasterDAO() {
		setClazz(SellerMaster.class);
	}

}
