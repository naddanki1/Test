package com.thincovate.bibakart.registration.dao.impl;

import org.hibernate.Hibernate;
import org.springframework.stereotype.Repository;

import com.thincovate.bibakart.dao.AbstractHibernateDAO;
import com.thincovate.bibakart.entitymodels.ProfileVerification;
import com.thincovate.bibakart.registration.dao.ProfileVerificationDAO;

@Repository("profileVerificationDAO")
public class ProfileVerificationDAOImpl extends AbstractHibernateDAO<ProfileVerification>
		implements ProfileVerificationDAO {

	public ProfileVerificationDAOImpl() {
		setClazz(ProfileVerification.class);
	}

	
	@Override
	public ProfileVerification findById(long id) {
		ProfileVerification pv = findOne(id);
		if (pv != null) {
			Hibernate.initialize(pv.getProspectiveSellers());
		}
		return pv;
	}

}
