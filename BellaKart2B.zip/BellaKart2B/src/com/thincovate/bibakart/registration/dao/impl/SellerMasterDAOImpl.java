/*package com.thincovate.bibakart.registration.dao.impl;

import org.springframework.stereotype.Repository;

import com.thincovate.bibakart.dao.AbstractHibernateDAO;
import com.thincovate.bibakart.entitymodels.SellerMaster;
import com.thincovate.bibakart.registration.dao.SellerMasterDAO;

@Repository("SellerMasterDAO")
public class SellerMasterDAOImpl extends AbstractHibernateDAO<SellerMaster> implements SellerMasterDAO {
	public SellerMasterDAOImpl() {
		setClazz(SellerMaster.class);
	}
}*/
