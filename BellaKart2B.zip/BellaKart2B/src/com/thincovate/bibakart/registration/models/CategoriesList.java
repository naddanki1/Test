package com.thincovate.bibakart.registration.models;

import java.util.List;

import com.thincovate.bibakart.entitymodels.Categories;

public class CategoriesList {
	//@NotEmpty
	private List<Categories> categories;

	public List<Categories>  getCategories() {
		return categories;
	}

	public void setCategories(List<Categories>  categories) {
		this.categories = categories;
	}


}
