package com.thincovate.bibakart.registration.services;

import java.util.List;

import com.thincovate.bibakart.entitymodels.BankDetails;


public interface BankDetailsService {

	List<BankDetails> findAll();

}

