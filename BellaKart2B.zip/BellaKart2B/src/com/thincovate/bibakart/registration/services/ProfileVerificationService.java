package com.thincovate.bibakart.registration.services;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.thincovate.bibakart.entitymodels.ProfileVerification;
import com.thincovate.bibakart.entitymodels.ProspectiveSellers;

public interface ProfileVerificationService {

	void save(ProfileVerification pv);

	List<ProfileVerification> findAllByColumn(String string, String emailAddress);

	ProfileVerification findOne(long id);
	
	ProfileVerification findById(long id);

	void saveOrupdate(ProfileVerification ev);

	ProfileVerification findOneByColumn(String string, String parameter);
	
	public String getEmailVerifyCode(HttpServletRequest request,String emailAddress, ProspectiveSellers ps);

}
