package com.thincovate.bibakart.registration.services;

import java.util.List;

import com.thincovate.bibakart.common.model.ResponseWrapper;
import com.thincovate.bibakart.entitymodels.ProspectiveSellers;


public interface ProspectiveSellersService {

	ProspectiveSellers checkDetails(ProspectiveSellers ps,String ipAddr,String loginName);

	public void updateStatus(String status,String emailAddr,String mobileNo);

	boolean isProspSellerExists(ProspectiveSellers ps);

	List<ProspectiveSellers> findAllByColumn(String string, String emailAddress);
	
	ProspectiveSellers findOneByColumn(String string, String emailAddress);
	
	void save(ProspectiveSellers ps);

	ResponseWrapper verifyEmail(String email);

	ResponseWrapper verifyMobile(String mobile);
	
}
