package com.thincovate.bibakart.registration.services;

import com.thincovate.bibakart.entitymodels.SellerDocs;

public interface SellerDocsService {

	void save(SellerDocs sd);

}
