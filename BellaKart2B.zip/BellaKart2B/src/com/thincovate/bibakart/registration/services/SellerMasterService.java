package com.thincovate.bibakart.registration.services;

import java.util.List;

import com.thincovate.bibakart.entitymodels.SellerMaster;

public interface SellerMasterService {

	void save(SellerMaster sm);

	List<SellerMaster> findAllByColumn(String string, String username);

	List<SellerMaster> findAllByColumn(String string, String attribute, String string2, String string3, String string4);

	void saveOrupdate(SellerMaster sm);

	SellerMaster findOne(long attribute);

	SellerMaster findOneByColumn(String string, String emailId);

	boolean isSellerExists(long sellerId);
}
