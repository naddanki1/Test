package com.thincovate.bibakart.registration.services.impl;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.thincovate.bibakart.dao.AbstractHibernateDAO;
import com.thincovate.bibakart.entitymodels.BankDetails;
import com.thincovate.bibakart.registration.services.BankDetailsService;


@Service
@Transactional
public class BankDetailsServiceImpl extends AbstractHibernateDAO<BankDetails> implements BankDetailsService{

	public BankDetailsServiceImpl()
	{
		setClazz(BankDetails.class);
	}
}

