package com.thincovate.bibakart.registration.services.impl;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.thincovate.bibakart.common.utils.CommonUtils;
import com.thincovate.bibakart.common.utils.DateUtils;
import com.thincovate.bibakart.entitymodels.ProfileVerification;
import com.thincovate.bibakart.entitymodels.ProspectiveSellers;
import com.thincovate.bibakart.registration.dao.ProfileVerificationDAO;
import com.thincovate.bibakart.registration.services.ProfileVerificationService;

@Service
@Transactional
public class ProfileVerificationServiceImpl implements ProfileVerificationService {

	@Autowired
	ProfileVerificationDAO profileVerificationDAO;

	static Logger log = Logger.getLogger(ProfileVerificationServiceImpl.class);

	public String getEmailVerifyCode(HttpServletRequest request, String emailAddress, ProspectiveSellers ps) {
		String random = null;
		ProfileVerification pv = null;
		List<ProfileVerification> listpv = null;
		String code = null;
		try {
			random = CommonUtils.generateRandomString(25, CommonUtils.Mode.ALPHANUMERIC);
			String serverurl = request.getRequestURL().toString().substring(0,request.getRequestURL().toString().lastIndexOf("/"));
			
			String textmsg = serverurl + "/emailVerify?token=" +random;	

			pv = new ProfileVerification();
			pv.setEmailVerificationCode(random);
			pv.setEmailVerificationStatus((byte) 0);
			pv.setProfileVerificationStatus((byte) 0);
			pv.setCreatedBy("Guest");
			pv.setCreatedDate(DateUtils.getCurrentDate());
			pv.setProspectiveSellers(ps);
			pv.setEmailVerificationLink(textmsg);
			// pv.setProspectId(ps.getProspectId());
			save(pv);
			log.info("Save Successful for profile_verification");
			listpv = findAllByColumn("prospect_id", new Integer(ps.getProspectId()).toString());

			code = listpv.get(0).getEmailVerificationCode();

			return "?token=" +code;

		} catch (Exception e) {

			e.printStackTrace();
		} finally {
			random = null;
			pv = null;
			listpv = null;
			code = null;
		}
		return null;
	}

	@Override
	public void save(ProfileVerification pv) {
		profileVerificationDAO.save(pv);

	}

	@Override
	public List<ProfileVerification> findAllByColumn(String string, String emailAddress) {
		List<ProfileVerification> listPV = profileVerificationDAO.findAllByColumn(string, emailAddress);
		return listPV;
	}

	@Override
	public ProfileVerification findOne(long id) {
		return profileVerificationDAO.findOne(id);
	}

	@Override
	public ProfileVerification findById(long id) {
		return profileVerificationDAO.findById(id);
	}

	@Override
	public void saveOrupdate(ProfileVerification ev) {
		profileVerificationDAO.saveOrupdate(ev);

	}

	@Override
	public ProfileVerification findOneByColumn(String string, String parameter) {
		return profileVerificationDAO.findOneByColumn(string, parameter);
	}

}
