package com.thincovate.bibakart.registration.services.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.thincovate.bibakart.common.model.ResponseWrapper;
import com.thincovate.bibakart.common.utils.BibakartConstants;
import com.thincovate.bibakart.common.utils.DateUtils;
import com.thincovate.bibakart.common.utils.Responses;
import com.thincovate.bibakart.dao.AbstractHibernateDAO;
import com.thincovate.bibakart.entitymodels.ProspectiveSellers;
import com.thincovate.bibakart.entitymodels.SellerMaster;
import com.thincovate.bibakart.registration.services.ProspectiveSellersService;
import com.thincovate.bibakart.registration.services.SellerMasterService;

@Service
@Transactional
public class ProspectiveSellersServiceImpl extends AbstractHibernateDAO<ProspectiveSellers> implements ProspectiveSellersService {

	@Autowired
	SellerMasterService sellerMasterService;
	
	static Logger log = Logger.getLogger(ProspectiveSellersServiceImpl.class);
	
	public ProspectiveSellersServiceImpl() {
		setClazz(ProspectiveSellers.class);
	}

	@Override
	public ProspectiveSellers checkDetails(ProspectiveSellers ps, String ipAddr, String loginName) {

		List<ProspectiveSellers> psList = findAllByColumn("emailAddr", ps.getEmailAddr(), "mobile",	ps.getMobile().toString(), "and");

		if (psList.size() > 0) {
			ProspectiveSellers psNew = psList.get(0);
			return psNew;
		} else {
			ps.setIpAddress(ipAddr);
			ps.setStatus(BibakartConstants.PS_EMAILVERIFY);
			ps.setCreatedBy(loginName);
			ps.setCreatedDate(DateUtils.getCurrentDate());
			save(ps);
			List<ProspectiveSellers> listpv = findAllByColumn("emailAddr", ps.getEmailAddr());
			log.info("Save Successful for prospective_seller");
			return listpv.get(0);
		}
	}

	@Override
	public void updateStatus(String status, String emailAddress, String mobileNumber) {
		ProspectiveSellers ps = findAllByColumn("emailAddr", emailAddress, "mobile", mobileNumber, "and").get(0);
		ps.setStatus(status);
	}

	@Override
	public boolean isProspSellerExists(ProspectiveSellers ps) {
		List<ProspectiveSellers> list = findAllByColumn("emailAddr", ps.getEmailAddr(), "mobile", ps.getMobile().toString(), "or");
		if (list.size() > 0) {
			return true;
		} else {
			return false;
		}
	}
	
	@Override
	public ResponseWrapper verifyEmail(String email){
		
		List<SellerMaster> sellerList = sellerMasterService.findAllByColumn("emailAddr", email);
		if (sellerList.size() > 0)
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, "Email id already registered");
		else {
			List<ProspectiveSellers> list = findAllByColumn("emailAddr", email);
			if (list.size() > 0)
				return new ResponseWrapper(Responses.CUSTOM_CODE, Responses.FAILURE_STATUS,	"Confirmation Link already sent to this email address");
			else
				return new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS, Responses.SUCCESS_MSG);
		
	}
	}
	@Override
	public ResponseWrapper verifyMobile(String mobile){
		
		List<SellerMaster> sellerList= sellerMasterService.findAllByColumn("mobile", mobile);
		if(sellerList.size()> 0)
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, "Mobile Number already registered");
		else{
		List<ProspectiveSellers> list=findAllByColumn("mobile", mobile);
		if(list.size() >0)
			return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, "Mobile Number alredy used for another account");
		else 
			return new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_STATUS, Responses.SUCCESS_MSG);
		}
	}

}
