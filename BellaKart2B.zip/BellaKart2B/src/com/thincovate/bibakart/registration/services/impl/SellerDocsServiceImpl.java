package com.thincovate.bibakart.registration.services.impl;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.thincovate.bibakart.dao.AbstractHibernateDAO;
import com.thincovate.bibakart.entitymodels.SellerDocs;
import com.thincovate.bibakart.registration.services.SellerDocsService;



@Service
@Transactional
public class SellerDocsServiceImpl extends AbstractHibernateDAO<SellerDocs> implements SellerDocsService {

	public SellerDocsServiceImpl()
	{
		setClazz(SellerDocs.class);
	}
}
