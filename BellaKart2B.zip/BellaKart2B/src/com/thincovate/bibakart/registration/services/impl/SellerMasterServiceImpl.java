package com.thincovate.bibakart.registration.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.thincovate.bibakart.entitymodels.SellerMaster;
import com.thincovate.bibakart.registration.dao.SellerMasterDAO;
import com.thincovate.bibakart.registration.services.SellerMasterService;




@Service
@Transactional
public class SellerMasterServiceImpl implements SellerMasterService{

	@Autowired
    SellerMasterDAO sellerMasterDAO;
	
	@Override
	public void save(SellerMaster sm) {
		sellerMasterDAO.save(sm);
		
	}

	@Override
	public List<SellerMaster> findAllByColumn(String string, String username) {
		return sellerMasterDAO.findAllByColumn(string, username);
	}

	@Override
	public List<SellerMaster> findAllByColumn(String string, String attribute, String string2, String string3,
			String string4) {
		return sellerMasterDAO.findAllByColumn(string, attribute, string2, string3, string4);
	}

	@Override
	public void saveOrupdate(SellerMaster sm) {
		sellerMasterDAO.saveOrupdate(sm);
		
	}

	@Override
	public SellerMaster findOne(long attribute) {
		return sellerMasterDAO.findOne(attribute);
	}

	@Override
	public SellerMaster findOneByColumn(String string, String emailId) {
		return sellerMasterDAO.findOneByColumn(string, emailId);
	}

	@Override
	public boolean isSellerExists(long sellerId) {
		try {
			SellerMaster seller = sellerMasterDAO.findOne(sellerId);
			if (seller != null)
				return true;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return false;
	}

	
}
