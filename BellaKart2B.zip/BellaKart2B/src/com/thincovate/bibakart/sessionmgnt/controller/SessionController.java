package com.thincovate.bibakart.sessionmgnt.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.thincovate.bibakart.common.model.ResponseWrapper;
import com.thincovate.bibakart.sessionmgnt.services.SessionMngtService;
import com.thincovate.bibakart.sessionmgnt.services.impl.User;

@Controller
@RequestMapping("/")
public class SessionController {

	static Logger log = Logger.getLogger(SessionController.class);

	@Autowired
	private SessionMngtService sessionMngtService;

	@RequestMapping(value = "test")
	public ResponseWrapper test() {
		return sessionMngtService.save();
	}

	@RequestMapping(value = "usrinfo")
	public User test2(@RequestParam(value = "id") String loginid) {

		return sessionMngtService.findById(loginid);
	}

	@RequestMapping(value = "authusr", method = RequestMethod.GET)
	public @ResponseBody ResponseWrapper autherizeUser(@RequestParam(value = "userId") String userId,	@RequestParam(value = "password") String password, 
																					HttpServletRequest request,	HttpServletResponse response) {

		return sessionMngtService.authorizeUser(userId, password, request, response);
	}

	@RequestMapping(value = "logoutusr", method = RequestMethod.GET)
	public String logout(@RequestParam(value = "loginId") String loginId, RedirectAttributes redirectAttributes,
																		HttpServletRequest request, HttpServletResponse hresponse) {

		
		try {
			if (sessionMngtService.isValidSession(request)) {

				if (sessionMngtService.logoutUser(loginId, sessionMngtService.getToken(request), request, hresponse)) {

					redirectAttributes.addFlashAttribute("message", "Successfully Logged out");
					log.info("Successfully Logged out");
					return "redirect:/reg_1";

				} else {
					return "error";
				}
			} else {
				redirectAttributes.addFlashAttribute("message", "Invalid Session");
				return "redirect:/reg_1";
			}
		} catch (Exception e) {

			e.printStackTrace();
			redirectAttributes.addFlashAttribute("message", "Problem Occured while processing");
			return "redirect:/reg_1";
		}

	}

	@RequestMapping(value = "authvdr", method = RequestMethod.GET)
	public @ResponseBody ResponseWrapper autherizeVendor(@RequestParam(value = "email") String email,@RequestParam(value = "password") String password, 
																								HttpServletRequest request,	HttpServletResponse response) {

		return sessionMngtService.authorizeVendor(email, password, request, response);

	}

	@RequestMapping(value = "logoutvdr", method = RequestMethod.GET)
	public String logoutVendor(@RequestParam(value = "email") String email, RedirectAttributes redirectAttributes,
																HttpServletRequest request, HttpServletResponse hresponse) {
		try {
			if (sessionMngtService.isValidSession(request)) {
				if (sessionMngtService.logoutVendor(email, sessionMngtService.getToken(request), request, hresponse)) {
					redirectAttributes.addFlashAttribute("message", "Successfully Logged out");
					return "redirect:/reg_1";
				} else {
					return "error";
				}
			} else {
				return "redirect:/reg_1";
			}
		} catch (Exception e) {
			e.printStackTrace();
			return "redirect:/reg_1";
		}

	}

}
