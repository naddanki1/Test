package com.thincovate.bibakart.sessionmgnt.dao;

import org.springframework.stereotype.Repository;

import com.thincovate.bibakart.dao.AbstractHibernateDAO;
import com.thincovate.bibakart.entitymodels.RoleModuleMatrix;

@Repository
public class RoleModuleMatrixDAO extends AbstractHibernateDAO<RoleModuleMatrix>{
	
	public RoleModuleMatrixDAO() {
		setClazz(RoleModuleMatrix.class);
	}

}
