package com.thincovate.bibakart.sessionmgnt.dao;

import org.springframework.stereotype.Repository;

import com.thincovate.bibakart.dao.AbstractHibernateDAO;
import com.thincovate.bibakart.entitymodels.SellerSessions;

@Repository
public class SellerSessionsDAO extends AbstractHibernateDAO<SellerSessions> {

	public SellerSessionsDAO() {
		setClazz(SellerSessions.class);
	}
}
