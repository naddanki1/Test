package com.thincovate.bibakart.sessionmgnt.dao;

import org.springframework.stereotype.Repository;

import com.thincovate.bibakart.dao.AbstractHibernateDAO;
import com.thincovate.bibakart.entitymodels.UserEntity;

@Repository
public class UserEntityDAO extends AbstractHibernateDAO<UserEntity> {

	public UserEntityDAO() {
		setClazz(UserEntity.class);
	}
}
