package com.thincovate.bibakart.sessionmgnt.dao;

import org.springframework.stereotype.Repository;

import com.thincovate.bibakart.dao.AbstractHibernateDAO;
import com.thincovate.bibakart.entitymodels.UserRoleMatrix;

@Repository
public class UserRoleMatrixDAO extends AbstractHibernateDAO<UserRoleMatrix> {

	public UserRoleMatrixDAO() {
		setClazz(UserRoleMatrix.class);
	}
}
