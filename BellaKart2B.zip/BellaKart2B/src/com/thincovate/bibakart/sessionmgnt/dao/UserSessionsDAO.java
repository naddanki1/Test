/**
 * 
 */
package com.thincovate.bibakart.sessionmgnt.dao;

import org.springframework.stereotype.Repository;

import com.thincovate.bibakart.dao.AbstractHibernateDAO;
import com.thincovate.bibakart.entitymodels.UserSessions;

/**
 * @author Venkat
 *
 */
@Repository
public class UserSessionsDAO extends AbstractHibernateDAO<UserSessions> {

	public UserSessionsDAO() {
		setClazz(UserSessions.class);
	}
}
