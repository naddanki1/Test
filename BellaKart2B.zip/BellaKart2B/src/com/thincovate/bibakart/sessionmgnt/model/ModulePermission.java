package com.thincovate.bibakart.sessionmgnt.model;

public class ModulePermission {

	private String moduleName;
	private String permission;

	public ModulePermission() {

	}

	public ModulePermission(String moduleName, String permission) {
		super();
		this.moduleName = moduleName;
		this.permission = permission;
	}

	public String getModuleName() {
		return moduleName;
	}

	protected void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public String getPermission() {
		return permission;
	}

	protected void setPermission(String permission) {
		this.permission = permission;
	}

}
