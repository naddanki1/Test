/**
 * 
 */
package com.thincovate.bibakart.sessionmgnt.model;

/**
 * @author Venkat
 *
 */
public class Seller {

	private String sellerId;
	private String businessName;
	private String storeDisplayName;
	private String description;
	private String pickupAddr;
	private int pickupPin;
	private String primaryContactName;
	private String emailAddr;
	private String pwd;
	private String mobile;
	private String sellerStatus;
	private String storeStatus;
	private String sessionToken;
	private String regStatus;

	public Seller() {
	}

	public Seller(String sellerId, String businessName, String storeDisplayName, String description, String pickupAddr,
			int pickupPin, String primaryContactName, String emailAddr, String pwd, String mobile, String sellerStatus,
			String storeStatus, String sessionToken,String regStatus) {
		super();
		this.sellerId = sellerId;
		this.businessName = businessName;
		this.storeDisplayName = storeDisplayName;
		this.description = description;
		this.pickupAddr = pickupAddr;
		this.pickupPin = pickupPin;
		this.primaryContactName = primaryContactName;
		this.emailAddr = emailAddr;
		this.pwd = pwd;
		this.mobile = mobile;
		this.sellerStatus = sellerStatus;
		this.storeStatus = storeStatus;
		this.sessionToken = sessionToken;
		this.regStatus=regStatus;
	}
	public String getSessionToken() {
		return sessionToken;
	}

	public void setSessionToken(String sessionToken) {
		this.sessionToken = sessionToken;
	}

	public String getRegStatus() {
		return regStatus;
	}

	public void setRegStatus(String regStatus) {
		this.regStatus = regStatus;
	}

	public String getSellerId() {
		return sellerId;
	}

	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public String getStoreDisplayName() {
		return storeDisplayName;
	}

	public void setStoreDisplayName(String storeDisplayName) {
		this.storeDisplayName = storeDisplayName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPickupAddr() {
		return pickupAddr;
	}

	public void setPickupAddr(String pickupAddr) {
		this.pickupAddr = pickupAddr;
	}

	public int getPickupPin() {
		return pickupPin;
	}

	public void setPickupPin(int pickupPin) {
		this.pickupPin = pickupPin;
	}

	public String getPrimaryContactName() {
		return primaryContactName;
	}

	public void setPrimaryContactName(String primaryContactName) {
		this.primaryContactName = primaryContactName;
	}

	public String getEmailAddr() {
		return emailAddr;
	}

	public void setEmailAddr(String emailAddr) {
		this.emailAddr = emailAddr;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getSellerStatus() {
		return sellerStatus;
	}

	public void setSellerStatus(String sellerStatus) {
		this.sellerStatus = sellerStatus;
	}

	public String getStoreStatus() {
		return storeStatus;
	}

	public void setStoreStatus(String storeStatus) {
		this.storeStatus = storeStatus;
	}

}
