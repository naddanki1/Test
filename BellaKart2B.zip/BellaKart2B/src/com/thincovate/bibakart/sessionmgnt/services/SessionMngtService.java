package com.thincovate.bibakart.sessionmgnt.services;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.thincovate.bibakart.common.model.ResponseWrapper;
import com.thincovate.bibakart.sessionmgnt.services.impl.User;

public interface SessionMngtService {

	ResponseWrapper save();

	User findById(String loginId);

	ResponseWrapper authorizeUser(String userId, String password, HttpServletRequest request,HttpServletResponse response);

	Boolean logoutUser(String loginId, String token, HttpServletRequest request, HttpServletResponse hresponse);

	ResponseWrapper authorizeVendor(String userId, String password, HttpServletRequest request,	HttpServletResponse hresponse);

	Boolean logoutVendor(String loginId,String token, HttpServletRequest request,	HttpServletResponse hresponse);

	Boolean isValidSession(HttpServletRequest request);

	String getToken(HttpServletRequest request);

	Boolean hasRole(HttpServletRequest request, String role);

	Boolean isValidSession(HttpServletRequest request, boolean matchUser, String incomingUser,String type);

	ResponseWrapper forgotPassword(String email, HttpServletRequest request);

	Boolean resetPwd(String email, String pass);

	Boolean isVendorExists(String email);

	Boolean checkCode(String code, HttpServletRequest request,RedirectAttributes redirectAttributes);


}
