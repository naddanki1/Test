package com.thincovate.bibakart.sessionmgnt.services.impl;

import java.util.ArrayList;
import java.util.List;

import com.thincovate.bibakart.sessionmgnt.model.ModulePermission;

public class Role {

	private String role;
	private List<ModulePermission> modulePermissions = new ArrayList<ModulePermission>();

	public Role() {

	}

	public String getRole() {
		return role;
	}

	protected void setRole(String role) {
		this.role = role;
	}

	public List<ModulePermission> getModulePermissions() {
		return modulePermissions;
	}

	protected void setModulePermissions(List<ModulePermission> modulePermissions) {
		this.modulePermissions = modulePermissions;
	}

}
