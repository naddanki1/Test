package com.thincovate.bibakart.sessionmgnt.services.impl;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.thincovate.bibakart.auth.dao.VerificationDAO;
import com.thincovate.bibakart.common.PropertyReader;
import com.thincovate.bibakart.common.model.AuthResponseWrapper;
import com.thincovate.bibakart.common.model.ResponseWrapper;
import com.thincovate.bibakart.common.services.UtilService;
import com.thincovate.bibakart.common.utils.BibakartRoles;
import com.thincovate.bibakart.common.utils.CommonUtils;
import com.thincovate.bibakart.common.utils.CommonUtils.Mode;
import com.thincovate.bibakart.common.utils.DateUtils;
import com.thincovate.bibakart.common.utils.Responses;
import com.thincovate.bibakart.common.utils.SessionProperties;
import com.thincovate.bibakart.entitymodels.ProspectiveSellers;
import com.thincovate.bibakart.entitymodels.RoleModuleMatrix;
import com.thincovate.bibakart.entitymodels.Roles;
import com.thincovate.bibakart.entitymodels.SellerMaster;
import com.thincovate.bibakart.entitymodels.SellerSessions;
import com.thincovate.bibakart.entitymodels.UserEntity;
import com.thincovate.bibakart.entitymodels.UserRoleMatrix;
import com.thincovate.bibakart.entitymodels.UserSessions;
import com.thincovate.bibakart.entitymodels.Verification;
import com.thincovate.bibakart.registration.dao.SellerMasterDAO;
import com.thincovate.bibakart.registration.services.ProspectiveSellersService;
import com.thincovate.bibakart.sessionmgnt.dao.RoleModuleMatrixDAO;
import com.thincovate.bibakart.sessionmgnt.dao.RolesDAO;
import com.thincovate.bibakart.sessionmgnt.dao.SellerSessionsDAO;
import com.thincovate.bibakart.sessionmgnt.dao.UserEntityDAO;
import com.thincovate.bibakart.sessionmgnt.dao.UserRoleMatrixDAO;
import com.thincovate.bibakart.sessionmgnt.dao.UserSessionsDAO;
import com.thincovate.bibakart.sessionmgnt.model.ModulePermission;
import com.thincovate.bibakart.sessionmgnt.model.Seller;
import com.thincovate.bibakart.sessionmgnt.services.SessionMngtService;


public class SessionMgntServiceImpl implements SessionMngtService {

	@Autowired
	private UserEntityDAO usersDAO;

	@Autowired
	private RolesDAO rolesDAO;

	@Autowired
	private UserRoleMatrixDAO userRoleMatrixDAO;

	@Autowired
	private RoleModuleMatrixDAO roleModuleMatrixDAO;

	@Autowired
	private SellerSessionsDAO sellerSessionsDAO;

	@Autowired
	private SellerMasterDAO sellerMasterDAO;
	
	@Autowired
	private UserSessionsDAO userSessionsDAO;
	
	@Autowired
	private VerificationDAO verificationDAO;

	@Autowired
	private UtilService utilService;
	
	@Autowired
	private ProspectiveSellersService prospectiveSellersService;

	static Logger log = Logger.getLogger(SessionMgntServiceImpl.class);

	@Override
	@Transactional
	public ResponseWrapper save() {
		UserEntity users = new UserEntity();
		users.setName("user_test");
		users.setLoginId("testid2");
		users.setPassword("testpass");

		usersDAO.save(users);

		Roles roles = new Roles();
		roles.setRoleName("TestPM");
		roles.setStatus("active");
		rolesDAO.save(roles);

		RoleModuleMatrix rm = new RoleModuleMatrix();
		rm.setRoles(roles);
		rm.setCol01("R");
		rm.setCol02("W");
		rm.setCol03("NA");
		roleModuleMatrixDAO.save(rm);

		UserRoleMatrix um = new UserRoleMatrix();
		um.setId(users.getUserId());
		um.setRoles(roles);
		um.setUsers(users);
		userRoleMatrixDAO.save(um);
		return new ResponseWrapper(Responses.SUCCESS_CODE, Responses.SUCCESS_MSG);
	}

	@Override
	public User findById(String loginId) {

		try {
			UserEntity userEntity = usersDAO.findOneByColumn("loginId", loginId);

			List<UserRoleMatrix> userRoleMatrixs = userRoleMatrixDAO.findAllByColumn("users", userEntity.getUserId());

			User user = new User();
			user.setLoginId(loginId);
			user.setUserName(userEntity.getName());
			user.setPassword(userEntity.getPassword());

			List<Role> roles = new ArrayList<Role>();

			for (UserRoleMatrix userRoleMatrix : userRoleMatrixs) {
				Role role = new Role();
				role.setRole(userRoleMatrix.getRoles().getRoleName());
				List<ModulePermission> modulePermissions = new ArrayList<ModulePermission>();

				RoleModuleMatrix roleModuleMatrix = roleModuleMatrixDAO.findOne(userRoleMatrix.getRoles().getRoleId());

				ModulePermission permission = new ModulePermission("Catalog", roleModuleMatrix.getCol01());
				ModulePermission permission2 = new ModulePermission("Downloads", roleModuleMatrix.getCol02());
				ModulePermission permission3 = new ModulePermission("Profile Managment", roleModuleMatrix.getCol03());
				modulePermissions.add(permission);
				modulePermissions.add(permission2);
				modulePermissions.add(permission3);
				role.setModulePermissions(modulePermissions);
				roles.add(role);
			}
			user.setRoles(roles);

			return user;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return null;
		}

	}

	@Override
	public ResponseWrapper authorizeUser(String userId, String password, HttpServletRequest request,HttpServletResponse hresponse) {

		String ipAddr = CommonUtils.getIpAddress(request);
		String macAddr = CommonUtils.getMACAddress(ipAddr);
		AuthResponseWrapper response = new AuthResponseWrapper();
		try {
			UserEntity userEntity = usersDAO.findOneByColumn("loginId", userId);
			// checking is account exist or not
			if (userEntity == null) {
				response.setStatus("Login Failed");
				response.setMessage("No Account found");
				return response;
			} 
			if(isValidSession(request, true, userEntity.getLoginId(), BibakartRoles.USER)){
				response.setStatus("Success");
				response.setMessage("Already Logged In. Redirecting..");
				return response;
			}else{
				if (!userEntity.getPassword().equals(password)) { // check passwords
					response.setStatus("Login Failed");
					response.setMessage("Password didnot match");
					return response;
				}
				// fresh session
				// generate a session token and assign it to user
				String token = generateSessionToken(ipAddr, macAddr, userId);
				
				// create User Model object
				User user = new User();
				user.setUserId(userEntity.getUserId().toString());
				user.setLoginId(userId);
				user.setUserName(userEntity.getName());
				user.setPassword(userEntity.getPassword());
				user.setSessionToken(token);
				
				// creating session
				createSession(request, hresponse, user);
				
				// Session table entry
				UserSessions session = new UserSessions();
				session.setIpAddress(ipAddr);
				session.setMacAddress(macAddr);
				session.setSessionToken(token);
				session.setLoggedInTime(DateUtils.getCurrentDate());
				session.setUsers(userEntity);
				userSessionsDAO.save(session);
				
				List<UserRoleMatrix> userRoleMatrixs = userRoleMatrixDAO.findAllByColumn("users", userEntity.getUserId());
				List<Role> roles = new ArrayList<Role>();

				for (UserRoleMatrix userRoleMatrix : userRoleMatrixs) {
					Role role = new Role();
					role.setRole(userRoleMatrix.getRoles().getRoleName());
					List<ModulePermission> modulePermissions = new ArrayList<ModulePermission>();

					// get role permissions for each module from matrix table
					RoleModuleMatrix roleModuleMatrix = roleModuleMatrixDAO.findOne(userRoleMatrix.getRoles().getRoleId());

					ModulePermission permission = new ModulePermission("Catalog", roleModuleMatrix.getCol01());
					ModulePermission permission2 = new ModulePermission("Downloads", roleModuleMatrix.getCol02());
					ModulePermission permission3 = new ModulePermission("Profile Managment", roleModuleMatrix.getCol03());
					modulePermissions.add(permission);
					modulePermissions.add(permission2);
					modulePermissions.add(permission3);
					role.setModulePermissions(modulePermissions);
					roles.add(role);
				}
				user.setRoles(roles);

			
				// prepare responsewrapper
				response.setStatus("Success");
				response.setMessage("Loged in Successfully");
				response.setUser(user);

				return response;
				
			}
			
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			response.setStatus("Fail");
			response.setMessage("Exception occured while processing");
			return response;

		}
	}



	@Override
	@Transactional
	public Boolean logoutUser(String loginId, String token, HttpServletRequest request,	HttpServletResponse hresponse) {

		ResponseWrapper response = new ResponseWrapper();
		try {
			UserEntity userEntity = usersDAO.findOneByColumn("loginId", loginId);
			if (userEntity == null)
				return false;
				//return new ResponseWrapper(Responses.FAILURE_CODE, Responses.FAILURE_STATUS, "User doesn't exist");

			List<UserSessions> userSessions = userSessionsDAO.findAllByColumn("user_id",userEntity.getUserId().toString());
			
			if (userSessions == null || userSessions.isEmpty()) {
				response.setCode(Responses.FAILURE_CODE);
				response.setStatus(Responses.ERROR_STATUS);
				response.setMessage("User not logged in");
				//return response;
				return false;
			} else {
				
				UserSessions sessions = userSessions.get(0);
				for (UserSessions userSession : userSessions) {

					if (userSession.getLoggedOutTime() == null) {
						userSession.setLoggedOutTime(DateUtils.getCurrentDate());
						userSessionsDAO.saveOrupdate(sessions);
						log.info("Log out Time :"+userSession.getLoggedOutTime());
						
						response.setCode(Responses.SUCCESS_CODE);
						response.setStatus(Responses.SUCCESS_STATUS);
						response.setMessage("user logged out successfully");
						destroySession(request, hresponse);
						//return response;
						return true;
					}
				}
				// TODO close session
			}
			response.setCode(Responses.FAILURE_CODE);
			response.setStatus(Responses.ERROR_STATUS);
			response.setMessage("User already logged out");
			//return response;
			return false;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			response.setStatus("Fail");
			response.setMessage("Exception occured while processing");
			//return response;
			return false;

		}
	}

	@Override
	public ResponseWrapper authorizeVendor(String email, String password, HttpServletRequest request,HttpServletResponse hresponse) {

		String ipAddr = CommonUtils.getIpAddress(request);
		String macAddr = CommonUtils.getMACAddress(ipAddr);

		AuthResponseWrapper response = new AuthResponseWrapper();
		try {

			SellerMaster sellerMaster = sellerMasterDAO.findOneByColumn("emailAddr", email,"mobile",email,"or");
			

			// checking is account exist or not
			if (sellerMaster == null) {
				response.setStatus("Login Failed");
				response.setMessage("No Account found with given credentials");
				return response;
			}
	
			// pull out sessiokn and check for incoming users session.
			if(isValidSession(request, true, email,BibakartRoles.VENDOR)){
				// check the user object to match if the session is of incoming user
				response.setStatus("Success");
				response.setMessage("Already Logged In. Redirecting..");
				return response;
			}else {
				// continue logging in.
				if (!sellerMaster.getPwd().equals(password)) {
					response.setStatus("Login Failed");
					response.setMessage("wrong Password");
					return response;
				}
				
				// fresh session
				// generate a session token and assign it to user
				String token = generateSessionToken(ipAddr, macAddr, email);

				// save session details in sellersession table
				SellerSessions session = new SellerSessions();
				session.setIpAddress(ipAddr);
				session.setMacAddress(macAddr);
				session.setSellerMaster(sellerMaster);
				session.setSessionToken(token);
				session.setLoggedInTime(DateUtils.getCurrentDate());

				sellerSessionsDAO.save(session);

				// prepare responsewrapper
				response.setStatus("Success");
				response.setMessage("Loged in Successfully");
				
				ProspectiveSellers ps=prospectiveSellersService.findOneByColumn("emailAddr", sellerMaster.getEmailAddr());
				// create seller object
				Seller seller = new Seller(sellerMaster.getSellerId().toString(), sellerMaster.getBusinessName(),
						sellerMaster.getStoreDisplayName(), sellerMaster.getDescription(), sellerMaster.getPickupAddr(),
						sellerMaster.getPickupPin(), sellerMaster.getPrimaryContactName(), sellerMaster.getEmailAddr(),
						sellerMaster.getPwd(), sellerMaster.getMobile().toString(), sellerMaster.getSellerStatus(),
						sellerMaster.getStoreStatus(), token,ps.getStatus());
				
				// creating session
				createSession(request, hresponse, seller);

	
				if(!ps.getStatus().equalsIgnoreCase("finish")){
					response.setMessage(CommonUtils.goStatus(ps.getStatus()));			
				}else if(!seller.getSellerStatus().equalsIgnoreCase("approved")){
					response.setMessage("vendor/profile");
				}else{
					response.setMessage(null);
				}
				setLoginSessionValues(sellerMaster, request.getSession()); // setSession Properties
				return response;			
			}
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			response.setStatus("Fail");
			response.setMessage("Exception occured while processing");
			return response;
		}
	}

	@Override
	public Boolean logoutVendor(String email, String token, HttpServletRequest request, HttpServletResponse hresponse) {

		ResponseWrapper response = new ResponseWrapper();
		try {

			SellerMaster sellerMaster = sellerMasterDAO.findOneByColumn("emailAddr", email);

			if (sellerMaster == null )
				return false;
			// return new ResponseWrapper(Responses.FAILURE_CODE,
			// Responses.FAILURE_STATUS, "User doesn't exist");

			List<SellerSessions> sellerSessions = sellerSessionsDAO.findAllByColumn("seller_id",sellerMaster.getSellerId());

			if (sellerSessions == null || sellerSessions.isEmpty()) {

				response.setCode(Responses.FAILURE_CODE);
				response.setStatus(Responses.ERROR_STATUS);
				response.setMessage("User not logged in");
				return false;
				// return response;
			} else {
				for (SellerSessions sellerSession : sellerSessions) {

					if (sellerSession.getLoggedOutTime() == null && sellerSession.getSessionToken().equalsIgnoreCase(URLDecoder.decode(token, "UTF-8"))) {
		
							sellerSession.setLoggedOutTime(DateUtils.getCurrentDate());
							sellerSessionsDAO.saveOrupdate(sellerSession);
							response.setCode(Responses.SUCCESS_CODE);
							response.setStatus(Responses.SUCCESS_STATUS);
							response.setMessage("user logged out successfully");
							destroySession(request, hresponse);
							return true;
							// return response;
					
					}
				}
			}
			response.setCode(Responses.FAILURE_CODE);
			response.setStatus(Responses.ERROR_STATUS);
			response.setMessage("User already logged out");
			return false;
			// return response;
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			response.setStatus("Fail");
			response.setMessage("Exception occured while processing");
			return false;
			// return response;

		}
	}

	//set session attributes for vendor	
	private void createSession(HttpServletRequest request, HttpServletResponse response, Seller seller) {

		Cookie token = null;
		try {
			token = new Cookie("token", URLEncoder.encode(seller.getSessionToken(), "UTF-8"));
			response.addCookie(token);
			
			HttpSession session = request.getSession();
			session.setAttribute("seller", seller);	
			session.setAttribute("userName", seller.getEmailAddr());// save seller object in session							
			session.setAttribute("hasUserLoggedIn", true);			// set Logged in status
			session.setAttribute("roles", BibakartRoles.VENDOR);  	// set Roles
			session.setMaxInactiveInterval(60*30);

			
			log.info("roels :"+session.getAttribute("roles"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	// set session attributes for Users
	private void createSession(HttpServletRequest request, HttpServletResponse response, User user) {

		Cookie token = null;
		try {
			token = new Cookie("token", URLEncoder.encode(user.getSessionToken(), "UTF-8"));
			response.addCookie(token);
			
			HttpSession session = request.getSession();
			session.setAttribute("user", user);			 // save seller object in session	
			session.setAttribute("userName", user.getLoginId());
			session.setAttribute("hasUserLoggedIn", true);	 // set Logged in status
			session.setMaxInactiveInterval(60*30);
			StringBuilder sb= new StringBuilder();
			sb.append(BibakartRoles.USER);
			for(Role r:user.getRoles()){
				sb.append(","+r.getRole());
			}
			log.info("user roes :"+sb.toString());
			session.setAttribute("roles", sb.toString());  		// set Roles
			log.info("roles :"+session.getAttribute("roles"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private void destroySession(HttpServletRequest request, HttpServletResponse response) {

		try {
			Cookie token = null;
			token = new Cookie("token", URLEncoder.encode("", "UTF-8"));
			token.setMaxAge(0);
			HttpSession session = request.getSession();
			response.addCookie(token);
			session.invalidate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public Boolean isValidSession(HttpServletRequest request) {
		
		String stoken = null;
		Boolean isTokenValid = false;
		try {
			
			HttpSession session = request.getSession();
			Object status = session.getAttribute("hasUserLoggedIn");
			if (status != null) {
				Cookie[] cookies = request.getCookies();
				for (Cookie cookie : cookies) {
					if (cookie.getName().equals("token")) {
						stoken = cookie.getValue();
						if (hasRole(request, BibakartRoles.VENDOR))
							isTokenValid = validateVendorToken(stoken);
						else 
							isTokenValid = validateUserToken(stoken);

						log.info("Token Valid :" + isTokenValid);
					}
				}
				return isTokenValid && (Boolean) status;
			} else {
				log.info("Login Valid :" + status);
				return false;
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}

	}
	
	@Override
	public Boolean isValidSession(HttpServletRequest request, boolean matchUser, String incomingUser, String type) {

		String stoken = null;
		boolean isTokenValid = false;
		boolean isSessionValid = false;
		try {
			HttpSession session = request.getSession();
			Object status = session.getAttribute("hasUserLoggedIn");
			if (status != null) {
				Cookie[] cookies = request.getCookies();
				for (Cookie cookie : cookies) {
					if (cookie.getName().equals("token")) {
						stoken = cookie.getValue();
						if (hasRole(request, BibakartRoles.VENDOR))
							isTokenValid = validateVendorToken(stoken);
						else
							isTokenValid = validateUserToken(stoken);
						
						log.info("Token Valid :" + isTokenValid);
					}
				}
				isSessionValid = isTokenValid && (boolean) status;
				// return isSessionValid;
			} else {
				log.info("Login Valid :" + status);
				// return isSessionValid;
			}

			// checking incoming user for final and actual match
			if (matchUser) {
				if (type.equalsIgnoreCase(BibakartRoles.VENDOR)) {
					Seller seller = (Seller) session.getAttribute("seller");
					if (seller != null && seller.getEmailAddr().equalsIgnoreCase(incomingUser))
						return isSessionValid && true;
					
				} else if (type.equalsIgnoreCase(BibakartRoles.USER)) {
					User user = (User) session.getAttribute("user");
					if (user != null && user.getLoginId().equalsIgnoreCase(incomingUser))
						return isSessionValid && true;
					
				}
				return isSessionValid && false;
			} else
				return isSessionValid;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}

	}

	// checkes if there is any active session with given Token
	private Boolean validateVendorToken(String token) {

		try {
			List<SellerSessions> sellerSessions = sellerSessionsDAO.findAllByColumn("session_token",URLDecoder.decode(token, "UTF-8"));
			for (SellerSessions sellerSession : sellerSessions) {
				
				if (sellerSession.getLoggedOutTime() == null) {
					if (sellerSession.getSessionToken().equalsIgnoreCase(URLDecoder.decode(token, "UTF-8"))) {
						return true;
					}
				}
			}
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}
		return false;
	}
	
	// checkes if there is any active session with given Token
	private Boolean validateUserToken(String token) {
		
		try {
			List<UserSessions> userSessions = userSessionsDAO.findAllByColumn("session_token", URLDecoder.decode(token, "UTF-8"));
			for (UserSessions userSession : userSessions) {
				
				if (userSession.getLoggedOutTime() == null) {
					if (userSession.getSessionToken().equalsIgnoreCase(URLDecoder.decode(token, "UTF-8"))) {
						return true;
					}
				}
			}
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}
		return false;
	}

	private String generateSessionToken(String ipAddr, String macAddr, String userId) {
		StringBuilder tokenBuilder = new StringBuilder();
		tokenBuilder.append(userId).append(ipAddr).append(macAddr).append(DateUtils.getCurrentStringTime());
		System.out.println("Session Token generated for User " + userId + " is " + tokenBuilder.toString());

		// encrypting token
		return CommonUtils.encryptText(tokenBuilder.toString());
	}

	@Override
	public String getToken(HttpServletRequest request) {

		try {
			HttpSession session = request.getSession();
			Object status = session.getAttribute("hasUserLoggedIn");
			if (status != null) {
				log.info("Login Valid :" + (Boolean) status);
				Cookie[] cookies = request.getCookies();
				for (Cookie cookie : cookies) {
					if (cookie.getName().equals("token")) {
						return cookie.getValue();
					}
				}

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}
		return "";

	}
	
	@Override
	public Boolean hasRole(HttpServletRequest request, String urole) {

		try {
			HttpSession session = request.getSession();
			String allRoles = (String) session.getAttribute("roles");
			log.info("roles :" + allRoles);
			return allRoles.contains(urole);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.info("User Dont have the permission to access the requested page");
		}
		return false;
	}
	
	
	@Override
	public ResponseWrapper forgotPassword(String email,HttpServletRequest request){
		
		AuthResponseWrapper response = new AuthResponseWrapper();
		try {
			SellerMaster sellerMaster = sellerMasterDAO.findOneByColumn("emailAddr", email);
			if(sellerMaster==null)
			return new AuthResponseWrapper(Responses.FAILURE_CODE, "Sorry, No account found with the given Email address", Responses.ERROR_STATUS);
			else{
		
				String random = CommonUtils.generateRandomString(25, Mode.ALPHANUMERIC);
						
				// save random generated code in verification_codes table
				Verification verification = new Verification();
				verification.setCode(random);
				verification.setUid(sellerMaster.getEmailAddr());
				verification.setStatus(0);
				verification.setCreatedDt(DateUtils.getCurrentDate());
				verificationDAO.save(verification);

				utilService.sendEmail(sellerMaster.getBusinessName(),email, PropertyReader.getInstance().getProperty("mail.email.lostpwd_subject"), random,request);
				response.setCode(Responses.SUCCESS_CODE);
				response.setStatus(Responses.SUCCESS_STATUS);
				response.setMessage("Please check your Inbox for Reset password Link ");
				return response;
			}
		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			response.setStatus("Fail");
			response.setMessage("Exception occured while processing");
			return response;
		}
	}
	@Override
	public Boolean isVendorExists(String email){
		try {
			SellerMaster sellerMaster = sellerMasterDAO.findOneByColumn("emailAddr", email);
			if(sellerMaster==null)
				return false;
			else {
				return true;
			}
				
		}catch (Exception e) {
			// TODO: handle exception
			return false;
		}
		
	}
	
	@Override
	public Boolean checkCode(String code,HttpServletRequest request,RedirectAttributes redirectAttributes){
		
		try {
			Verification verification = verificationDAO.findOneByColumn("code", code);
				if(verification != null){
					HttpSession session = request.getSession();
					session.setAttribute("userName", verification.getUid());
			if (verification.getStatus() == 0) {
				if(DateUtils.getHrDiff(verification.getCreatedDt()) <= 24){
					verification.setStatus(1);
					verification.setModifyDt(DateUtils.getCurrentDate());
					verificationDAO.saveOrupdate(verification);
				
					return true;
					
				}else {
					redirectAttributes.addFlashAttribute("pwdmsg", "Link Expired, Please Try again resetting password");
					return false;
				}
					
			} else{
				redirectAttributes.addFlashAttribute("pwdmsg", "Link Already Used");
				return false;
			}
			}else {
				redirectAttributes.addFlashAttribute("pwdmsg", "Problem with the link,please try again resetting your Password");
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
			return false;
		}

	}

	@Override
	public Boolean resetPwd(String email, String pass) {

		try {
			SellerMaster sellerMaster = sellerMasterDAO.findOneByColumn("emailAddr", email);
			if (sellerMaster == null)
				return false;
			else {
				sellerMaster.setPwd(pass);
				sellerMasterDAO.saveOrupdate(sellerMaster);
				return true;
			}

		} catch (Exception e) {
			// TODO
			e.printStackTrace();
			return false;
		}

}
	private void setLoginSessionValues(SellerMaster sellerMaster, HttpSession session) {

		session.setMaxInactiveInterval(100000);
		session.setAttribute(SessionProperties.SELLER_ID, sellerMaster.getSellerId());
		session.setAttribute(SessionProperties.SELLER_STATUS, sellerMaster.getSellerStatus());
		session.setAttribute(SessionProperties.SELLER_STORE_NAME, sellerMaster.getStoreDisplayName());

		session.setAttribute(SessionProperties.EMAIL_ADDR, sellerMaster.getEmailAddr());
		session.setAttribute(SessionProperties.MOBILE_NO, sellerMaster.getMobile());
		session.setAttribute(SessionProperties.LOGIN_NAME, sellerMaster.getStoreDisplayName());

	}
	

}
