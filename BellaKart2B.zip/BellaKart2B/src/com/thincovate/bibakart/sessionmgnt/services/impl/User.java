package com.thincovate.bibakart.sessionmgnt.services.impl;

import java.util.ArrayList;
import java.util.List;

public class User {
	private String userId;
	private String loginId;
	private String userName;
	private String password;
	private String sessionToken;
	private String role;
	private List<Role> roles = new ArrayList<Role>();

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public User() {
	}

	public String getUserName() {
		return userName;
	}

	protected void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	protected void setPassword(String password) {
		this.password = password;
	}

	public String getLoginId() {
		return loginId;
	}

	protected void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public List<Role> getRoles() {
		return roles;
	}

	protected void setRoles(List<Role> roles) {
		this.roles = roles;
	}

	/**
	 * @return the sessionToken
	 */
	public String getSessionToken() {
		return sessionToken;
	}

	/**
	 * @param sessionToken
	 *            the sessionToken to set
	 */
	public void setSessionToken(String sessionToken) {
		this.sessionToken = sessionToken;
	}

}
