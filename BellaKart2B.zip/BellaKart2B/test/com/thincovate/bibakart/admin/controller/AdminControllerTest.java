package com.thincovate.bibakart.admin.controller;

import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import javax.annotation.Resource;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.thincovate.bibakart.admin.model.Brand;
import com.thincovate.bibakart.admin.model.Category;
import com.thincovate.bibakart.admin.model.LgFee;
import com.thincovate.bibakart.common.utils.IntegrationTestUtils;
import com.thincovate.bibakart.common.utils.Responses;
import com.thincovate.bibakart.common.utils.TestUtil;
import com.thincovate.bibakart.config.AppConfig;
import com.thincovate.bibakart.config.AppInitializer;
import com.thincovate.bibakart.config.Config;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { Config.class, AppInitializer.class, AppConfig.class })
@WebAppConfiguration
public class AdminControllerTest {

	@Resource
	private WebApplicationContext webApplicationContext;

	private MockMvc mockMvc;

	@Before
	public void setUp() {
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
	}

	@Test
	public void getSellerProductsUsingApprovalStatus() throws Exception {
		MvcResult mvcResult = mockMvc
				.perform(get("/admin/sellerproducts").param("status", "New")
						.contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8))
				.andExpect(content().contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8)).andExpect(status().isOk())
				.andReturn();
		System.out.println("Result is :" + mvcResult.getResponse().getContentAsString());
		assertTrue(mvcResult.getResponse().getContentAsString().contains(Responses.SUCCESS_MSG));
	}

		@Test
	public void updateSellerProductApprovalStatus() throws Exception {
		Long id = TestUtil.getRandomId();
		MvcResult result = mockMvc.perform(put("/admin/sellerproducts").param("sellerProductId", "" + id).param("status", "Pending")
						.contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8))
				.andExpect(content().contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8)).andReturn();

		System.out.println("Response: " + result.getResponse().getContentAsString());
		assertTrue(result.getResponse().getContentAsString().contains("Seller Product Details Updated Successfully"));
	}
	
	@Test
	public void saveCategory() throws Exception {

		Category category = TestUtil.createCategory();
		MvcResult result = mockMvc.perform(post("/admin/categories").contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8)
				.content(IntegrationTestUtils.convertObjectToJsonBytes(category))).andReturn();
		System.out.println("Response: " + result.getResponse().getContentAsString());
		assertTrue(result.getResponse().getContentAsString().contains("Category Added Successfully"));
	}
	@Test
	public void saveCategoryWithMisingFields() throws Exception {
		Category category = TestUtil.createCategoryWithMissingFields();
		MvcResult result = mockMvc.perform(post("/admin/categories").contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8)
				.content(IntegrationTestUtils.convertObjectToJsonBytes(category))).andReturn();
		System.out.println("Response: " + result.getResponse().getContentAsString());
		assertTrue(result.getResponse().getContentAsString()
				.contains("Field Name :categoryName, Error :categoty Name can't be Empty"));
	}
	@Test
	public void getAllCategories() throws Exception {
		MvcResult result = mockMvc.perform(get("/admin/categories"))
				.andExpect(content().contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8)).andExpect(status().isOk())
				.andExpect(jsonPath("$.categories", not(empty()))).andReturn();
		System.out.println("Response: " + result.getResponse().getContentAsString());
		assertTrue(result.getResponse().getContentAsString().contains(Responses.SUCCESS_MSG));
	}
	
	@Test
	public void saveBrand() throws Exception {

		Brand brand = TestUtil.createBrand();
		MvcResult result = mockMvc.perform(post("/admin/brands").contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8)
				.content(IntegrationTestUtils.convertObjectToJsonBytes(brand))).andReturn();
		System.out.println("Response: " + result.getResponse().getContentAsString());
		assertTrue(result.getResponse().getContentAsString().contains("Brand Added Successfully"));
	}

	@Test
	public void saveBrandWithMisingFields() throws Exception {
		Brand brand = TestUtil.createBrandWithMissingFields();
		MvcResult result = mockMvc.perform(post("/admin/brands").contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8)
				.content(IntegrationTestUtils.convertObjectToJsonBytes(brand))).andReturn();
		System.out.println("Response: " + result.getResponse().getContentAsString());
		assertTrue(result.getResponse().getContentAsString()
				.contains("Field Name :brandName, Error :Brand Name can't be Empty"));
	}
	@Test
	public void getAllBrands() throws Exception {
		MvcResult result = mockMvc.perform(get("/admin/brands"))
				.andExpect(content().contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8)).andExpect(status().isOk())
				.andExpect(jsonPath("$.brands", not(empty()))).andReturn();
		System.out.println("Response: " + result.getResponse().getContentAsString());
		assertTrue(result.getResponse().getContentAsString().contains(Responses.SUCCESS_MSG));
	}
	
	@Test
	public void saveLogisticFee() throws Exception {
		LgFee logisticFees = TestUtil.createLogisticFee();
		MvcResult result = mockMvc.perform(post("/admin/logisticfee").contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8)
				.content(IntegrationTestUtils.convertObjectToJsonBytes(logisticFees))).andReturn();
		System.out.println("Response: " + result.getResponse().getContentAsString());
		assertTrue(result.getResponse().getContentAsString().contains(Responses.SUCCESS_MSG));
	}
	@Test
	public void saveLogisticFeeWithMissingFields() throws Exception {
		LgFee logisticFees = TestUtil.createLogisticFeeWithMissingFields();
		MvcResult result = mockMvc.perform(post("/admin/logisticfee").contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8)
				.content(IntegrationTestUtils.convertObjectToJsonBytes(logisticFees))).andReturn();
		System.out.println("Response: " + result.getResponse().getContentAsString());
		assertTrue(result.getResponse().getContentAsString().contains("Field Name :lowerLimit, Error :Limit should be entered"));
	}
	@Test
	public void updateMkChargesUsingAvailableId() throws Exception {
		Long id = TestUtil.getRandomId();
		Long p = TestUtil.getRandomId();
		Long t = TestUtil.getRandomId();
		MvcResult result = mockMvc
				.perform(put("/admin/mkcharges").param("mkChargesId", "" + id).param("mkPercentage", ""+p)
						.param("taxOnMf", ""+t)
						.contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8))
				.andExpect(content().contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8)).andReturn();
		System.out.println("Response: " + result.getResponse().getContentAsString());
		assertTrue(result.getResponse().getContentAsString().contains(Responses.SUCCESS_MSG));
	}
	@Test
	public void updateMkChargesUsingUnAvailableId() throws Exception {
		Long p = TestUtil.getRandomId();
		Long t = TestUtil.getRandomId();
		MvcResult result = mockMvc
				.perform(put("/admin/mkcharges").param("mkChargesId", "10000").param("mkPercentage", ""+p)
						.param("taxOnMf", ""+t)
						.contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8))
				.andExpect(content().contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8)).andReturn();
		System.out.println("Response: " + result.getResponse().getContentAsString());
		assertTrue(result.getResponse().getContentAsString().contains("Invalid Id"));
	}
}
