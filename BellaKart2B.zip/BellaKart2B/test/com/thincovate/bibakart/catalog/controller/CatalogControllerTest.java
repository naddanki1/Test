/*package com.thincovate.bibakart.catalog.controller;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.thincovate.bibakart.catalog.model.Catalog;
import com.thincovate.bibakart.catalog.model.Product;
import com.thincovate.bibakart.common.utils.IntegrationTestUtils;
import com.thincovate.bibakart.common.utils.Responses;
import com.thincovate.bibakart.common.utils.TestUtil;
import com.thincovate.bibakart.config.AppConfig;
import com.thincovate.bibakart.config.AppInitializer;
import com.thincovate.bibakart.config.Config;

import javax.annotation.Resource;

import static org.junit.Assert.assertTrue;
import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

*//**
 * This test uses the annotation based application context configuration.
 * 
 * @author Rajani Arjula
 *//*
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { Config.class, AppInitializer.class, AppConfig.class })
@WebAppConfiguration
public class CatalogControllerTest {

	@Resource
	private WebApplicationContext webApplicationContext;

	private MockMvc mockMvc;

	@Before
	public void setUp() {
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
	}

	@Test
	public void saveProduct() throws Exception {

		Product product = TestUtil.createProduct();
		MvcResult result = mockMvc.perform(post("/products").contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8)
				.content(IntegrationTestUtils.convertObjectToJsonBytes(product))).andReturn();
		System.out.println("Response: " + result.getResponse().getContentAsString());
		assertTrue(result.getResponse().getContentAsString().contains(Responses.SUCCESS_MSG));

	}

	@Test
	public void saveProductWithMisingFields() throws Exception {
		Product product = TestUtil.createProductWithMisingFields();
		MvcResult result = mockMvc.perform(post("/products").contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8)
				.content(IntegrationTestUtils.convertObjectToJsonBytes(product))).andReturn();
		System.out.println("Response: " + result.getResponse().getContentAsString());
		assertTrue(result.getResponse().getContentAsString()
				.contains("Field Name :productTitle, Error :Title can't be Empty"));
	}

	@Test
	public void getAllProducts() throws Exception {
		MvcResult result = mockMvc.perform(get("/products"))
				.andExpect(content().contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8)).andExpect(status().isOk())
				.andExpect(jsonPath("$.products", not(empty()))).andReturn();
		System.out.println("Response: " + result.getResponse().getContentAsString());
		assertTrue(result.getResponse().getContentAsString().contains(Responses.SUCCESS_MSG));
	}

	@Test
	public void getProductsUsingAvailableId() throws Exception {
		Long id = TestUtil.getRandomId();
		MvcResult result = mockMvc
				.perform(get("/products/{prodcutId}", id).contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8))
				.andExpect(content().contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8)).andExpect(status().isOk())
				.andExpect(jsonPath("$.products", hasSize(1))).andReturn();
		System.out.println("Response: " + result.getResponse().getContentAsString());
		assertTrue(result.getResponse().getContentAsString().contains(Responses.SUCCESS_MSG));
	}

	@Test
	public void getProductsUsingUnAvailableId() throws Exception {

		MvcResult result = mockMvc
				.perform(get("/products/{prodcutId}", 570L).contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8))
				.andReturn();

		System.out.println("Result is :" + result.getResponse().getContentAsString());
		assertTrue(result.getResponse().getContentAsString().contains("No Product Found for the give Id"));
	}

	@Test
	public void updateProductsUsingAvailableId() throws Exception {
		Long id = TestUtil.getRandomId();
		MvcResult result = mockMvc
				.perform(put("/products").param("productId", "" + id).param("status", "false")
						.contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8))
				.andExpect(content().contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8)).andReturn();
		System.out.println("Response: " + result.getResponse().getContentAsString());
		assertTrue(result.getResponse().getContentAsString().contains("Product Details  Updated Successfully"));
	}

	@Test
	public void updateProductsUsingUnAvailableId() throws Exception {

		MvcResult result = mockMvc.perform(put("/products").param("productId", "580").param("status", "false")
				.contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8)).andReturn();
		System.out.println("Response: " + result.getResponse().getContentAsString());
		assertTrue(result.getResponse().getContentAsString().contains("No Product Found for the give Id"));
	}

	@Test
	public void saveSellerProductsUsingSearch() throws Exception {
		Catalog catalog = TestUtil.createSellerProductUsingSearch();
		MvcResult result = mockMvc
				.perform(post("/sellerproducts").contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8)
						.content(IntegrationTestUtils.convertObjectToJsonBytes(catalog)))
				.andExpect(content().contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8)).andExpect(status().isOk())
				.andReturn();
		System.out.println("Response: " + result.getResponse().getContentAsString());
		assertTrue(result.getResponse().getContentAsString().contains(Responses.SUCCESS_MSG));

	}

	@Test
	public void saveSellerProductsOneByOne() throws Exception {
		Catalog catalog = TestUtil.createSellerProductOneByOne();
		MvcResult result = mockMvc
				.perform(post("/sellerproducts").contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8)
						.content(IntegrationTestUtils.convertObjectToJsonBytes(catalog)))
				.andExpect(content().contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8)).andReturn();
		System.out.println("Response: " + result.getResponse().getContentAsString());
		assertTrue(result.getResponse().getContentAsString().contains(Responses.SUCCESS_MSG));
	}

	@Test
	public void saveSellerProductsWithMisingFields() throws Exception {
		Catalog catalog = TestUtil.createCatalogWithMisingFields();
		MvcResult result = mockMvc
				.perform(post("/sellerproducts").contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8)
						.content(IntegrationTestUtils.convertObjectToJsonBytes(catalog)))
				.andExpect(content().contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8)).andExpect(status().isOk())
				.andReturn();
		System.out.println("Response: " + result.getResponse().getContentAsString());
		assertTrue(
				result.getResponse().getContentAsString().contains("Field Name :skuId, Error :SKU id must be entered"));
	}

	@Test
	public void getSellerProducts() throws Exception {
		MvcResult result = mockMvc.perform(get("/sellerproducts"))
				.andExpect(content().contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8)).andExpect(status().isOk())
				.andExpect(jsonPath("$.sellerProducts", not(empty()))).andReturn();
		System.out.println("Response: " + result.getResponse().getContentAsString());
		assertTrue(result.getResponse().getContentAsString().contains(Responses.SUCCESS_MSG));
		;
	}

	@Test
	public void getSellerProductsUsingAvailableId() throws Exception {

		Long id = TestUtil.getRandomId();
		MvcResult result = mockMvc
				.perform(get("/sellerproducts/{sellerProdcutId}", id)
						.contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8))
				.andExpect(content().contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8))
				.andExpect(jsonPath("$.sellerProducts", hasSize(1))).andReturn();
		System.out.println("Response: " + result.getResponse().getContentAsString());
		assertTrue(result.getResponse().getContentAsString().contains(Responses.SUCCESS_MSG));
	}

	@Test
	public void getSellerProductsUsingUnAvailableId() throws Exception {

		MvcResult result = mockMvc.perform(
				get("/sellerproducts/{sellerProdcutId}", 350L).contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8))
				.andReturn();

		System.out.println("Result is :" + result.getResponse().getContentAsString());
		assertTrue(result.getResponse().getContentAsString().contains("No SellerProduct Found for the give Id"));

	}

	@Test
	public void updateSellerProductsUsingAvailableId() throws Exception {
		Long id = TestUtil.getRandomId();
		MvcResult result = mockMvc
				.perform(put("/sellerproducts").param("sellerProductId", "" + id).param("availablestatus", "false")
						.param("units", "666").param("sellingPrice", "9999")
						.contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8))
				.andExpect(content().contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8)).andReturn();
		System.out.println("Response: " + result.getResponse().getContentAsString());
		assertTrue(result.getResponse().getContentAsString().contains("Seller Product Details Updated Successfully"));
	}

	@Test
	public void updateSellerProductsUsingUnAvailableId() throws Exception {

		MvcResult result = mockMvc.perform(put("/sellerproducts").param("sellerProductId", "390")
				.param("availablestatus", "false").param("units", "666").param("sellingPrice", "9999")
				.contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8)).andReturn();

		System.out.println("Response: " + result.getResponse().getContentAsString());

		assertTrue(result.getResponse().getContentAsString().contains("Invalid SellerProductId"));
	}

	@Test
	public void search() throws Exception {

		MvcResult result = mockMvc.perform(get("/search").param("keyword", "e")).andReturn();
		System.out.println("Response: " + result.getResponse().getContentAsString());
		assertTrue(result.getResponse().getContentAsString().contains(Responses.SUCCESS_MSG));
	}

}
*/