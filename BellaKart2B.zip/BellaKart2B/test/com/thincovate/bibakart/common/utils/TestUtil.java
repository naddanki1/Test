package com.thincovate.bibakart.common.utils;

import java.util.Random;

import com.thincovate.bibakart.admin.model.Brand;
import com.thincovate.bibakart.admin.model.Category;
import com.thincovate.bibakart.admin.model.LgFee;
import com.thincovate.bibakart.catalog.model.AttributesModel;
import com.thincovate.bibakart.catalog.model.Catalog;
import com.thincovate.bibakart.catalog.model.Product;
import com.thincovate.bibakart.entitymodels.ProspectiveSellers;

public class TestUtil {

	public static ProspectiveSellers createProspectSeller() {
		ProspectiveSellers dto = new ProspectiveSellers();
		Random rn = new Random();
		dto.setEmailAddr("test" + rn.nextInt() + "@thincovate.com");
		long LOWER_RANGE = 9000000000l; // assign lower range value
		long UPPER_RANGE = 9999999999l; // assign upper range value
		long randomValue = LOWER_RANGE + (long) (rn.nextDouble() * (UPPER_RANGE - LOWER_RANGE));
		long mobile = randomValue;
		dto.setMobile(mobile);
		dto.setStatus("emailVerify");
		return dto;
	}

	public static ProspectiveSellers emptyProspectiveSeller() {
		ProspectiveSellers dto = new ProspectiveSellers();
		return dto;
	}

/*	public static Product createProduct() {
		Product product = new Product();
		Integer brandId = (int) Math.ceil(Math.random() * 10);
		Long categoryId = (long) Math.ceil(Math.random() * 10);
		product.setBrandId(brandId);
		product.setCategoryId(categoryId);
		product.setImageLocation("location");
		product.setProductTitle("Title");
		product.setProductDesc("Descriprion");
		AttributesModel[] attributesModels = new AttributesModel[2];
		attributesModels[0] = new AttributesModel("Attribute1", "value1");
		attributesModels[1] = new AttributesModel("Attribute2", "value2");
		product.setStatus(true);
		product.setAttributesModels(attributesModels);
		return product;
	}*/

	public static Product createProductWithMisingFields() {
		Product product = new Product();
		return product;
	}

	/*public static Catalog createSellerProductUsingSearch() {
		Random r = new Random();
		Catalog catalog = new Catalog();
		catalog.setProductId(new Long(1));
		catalog.setSkuId("" + (long) Math.ceil(Math.random() * 10000));
		catalog.setMrp(new Double(1000.00));
		catalog.setSellingPrice(new Double(900.00));
		catalog.setUnits(new Integer(150));
		catalog.setIsCodAllowed(r.nextBoolean());
		catalog.setHasFreeDelivery(r.nextBoolean());
		catalog.setWeightForFright("" + (int) Math.ceil(Math.random() * 1000));
		catalog.setShippingCharges(Math.ceil(Math.random() * 100));
		catalog.setEstimatedShippingDays((int) (Math.random() * (3 - 0) + 0));
		catalog.setSearchKeywords("jlj,iuo");
		catalog.setWarrantyServiceType("kgd");
		catalog.setWarrantyServiceType("jcoi");
		catalog.setModeOfAddition("klj");
		catalog.setAvailableStatus(new Boolean(true));
		return catalog;
	}

	public static Catalog createSellerProductOneByOne() {
		Catalog catalog = new Catalog();
		Random r = new Random();
		catalog.setBrandID((int) Math.ceil(Math.random() * 10));
		catalog.setCategoryId((long) Math.ceil(Math.random() * 10));
		catalog.setImageLocation("image");
		catalog.setProductTitle("Product Title");
		catalog.setProductDesc("Product Description");
		catalog.setSkuId("" + (long) Math.ceil(Math.random() * 10000));
		catalog.setMrp(new Double(1000.00));
		catalog.setSellingPrice(new Double(900.00));
		catalog.setUnits((int) Math.ceil(Math.random() * 100));
		catalog.setIsCodAllowed(r.nextBoolean());
		catalog.setHasFreeDelivery(r.nextBoolean());
		catalog.setWeightForFright("" + (int) Math.ceil(Math.random() * 1000));
		catalog.setShippingCharges(Math.ceil(Math.random() * 100));
		catalog.setEstimatedShippingDays((int) (Math.random() * (4 - 0) + 0));
		catalog.setSearchKeywords("keyword1,keyword2");
		catalog.setWarrantyServiceType("kgd");
		catalog.setWarrantyServiceType("jcoi");
		catalog.setModeOfAddition("l");
		catalog.setAvailableStatus(new Boolean(true));
		AttributesModel[] attributesModels = new AttributesModel[2];
		attributesModels[0] = new AttributesModel("Attribute3", "value3");
		attributesModels[1] = new AttributesModel("Attribute4", "value4");
		catalog.setAvailableStatus(true);
		catalog.setAttributesModels(attributesModels);
		return catalog;
	}
*/
	public static Catalog createCatalogWithMisingFields() {
		Catalog c = new Catalog();
		return c;
	}

	public static Long getRandomId() {
		Long id = (long) (Math.random() * (15 - 1) + 1);
		return id;
	}

	public static Category createCategory() {
		Category c = new Category();
		c.setCategoryName("Category Name");
		c.setCategoryDesc("Description");
		c.setIsMainCategory("" + (int) (Math.random() * (1 - 0) + 0));
		c.setParentCategoryId("" + (long) (Math.random() * (3 - 2) + 2));
		c.setMkPercentage("" + (float) Math.ceil(Math.random() * 10));
		c.setTaxOnMf("" + (float) Math.ceil(Math.random() * 10));
		c.setStatus("" + (int) (Math.random() * (1 - 0) + 0));
		return c;
	}

	public static Category createCategoryWithMissingFields() {
		Category c = new Category();
		return c;
	}

	public static Brand createBrand() {
		Brand b = new Brand();
		b.setBrandDesc("Description..");
		b.setBrandName("BName");
		b.setStatus("" + (int) (Math.random() * (1 - 0) + 0));
		return b;
	}

	public static Brand createBrandWithMissingFields() {
		Brand b = new Brand();
		return b;
	}

	public static LgFee createLogisticFee() {
		Integer value = (int) Math.ceil((Math.random() * 2000));
		LgFee l = new LgFee();
		l.setLowerLimit("" + value);
		l.setUpperLimit("" + (value + 500));
		l.setFee("" + Math.ceil(Math.random() * 100));
		l.setTaxOnLogisticFee("" + (float) Math.ceil(Math.random() * 10));
		return l;
	}

	public static LgFee createLogisticFeeWithMissingFields() {
		LgFee l = new LgFee();
		return l;
	}
}