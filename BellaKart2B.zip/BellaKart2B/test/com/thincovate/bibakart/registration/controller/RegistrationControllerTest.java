package com.thincovate.bibakart.registration.controller;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;

import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.thincovate.bibakart.common.utils.IntegrationTestUtils;
import com.thincovate.bibakart.common.utils.Responses;
import com.thincovate.bibakart.common.utils.TestUtil;
import com.thincovate.bibakart.config.AppConfig;
import com.thincovate.bibakart.config.AppInitializer;
import com.thincovate.bibakart.config.Config;
import com.thincovate.bibakart.entitymodels.ProspectiveSellers;
import com.thincovate.bibakart.registration.services.ProspectiveSellersService;

import javax.annotation.Resource;

import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import org.springframework.test.web.servlet.MvcResult;

/**
 * This test uses the annotation based application context configuration.
 * 
 * @author Rajani Arjula
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { Config.class, AppInitializer.class, AppConfig.class })
@WebAppConfiguration
public class RegistrationControllerTest {

	@Resource
	private WebApplicationContext webApplicationContext;

	private MockMvc mockMvc;

	@Autowired
	ProspectiveSellersService prospectiveSellerService;

	@Before
	public void setUp() {
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
	}

	@Test
	public void saveProspectiveSeller() throws Exception {
		ProspectiveSellers prospect = TestUtil.createProspectSeller();
		MvcResult result = mockMvc.perform(post("/reg_1").contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8)
				.content(IntegrationTestUtils.convertObjectToJsonBytes(prospect))).andReturn();

		assertTrue(result.getResponse().getContentAsString().contains(Responses.SUCCESS_STATUS));
	}
	
	@Test
	public void saveProspectiveSellerAlreadyExists() throws Exception {
		ProspectiveSellers prospect = TestUtil.createProspectSeller();
		prospectiveSellerService.save(prospect);
		MvcResult result = mockMvc.perform(post("/reg_1").contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8)
				.content(IntegrationTestUtils.convertObjectToJsonBytes(prospect))).andReturn();
		assertTrue(result.getResponse().getContentAsString().contains("Prospective Seller Already Exists!!"));
	}

	@Test
	public void saveProspectiveSellerMissingFlds() throws Exception {
		ProspectiveSellers prospect = TestUtil.emptyProspectiveSeller();
		MvcResult result = mockMvc.perform(post("/reg_1").contentType(IntegrationTestUtils.APPLICATION_JSON_UTF8)
				.content(IntegrationTestUtils.convertObjectToJsonBytes(prospect))).andReturn();

		assertTrue(
				result.getResponse().getContentAsString().contains("Field Name :emailAddr, Error :may not be empty"));
	}

}